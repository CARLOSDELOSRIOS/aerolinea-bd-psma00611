-- PRODUCTO ACADÉMICO COLABORATIVO - ENTREGA FINAL
-- Base de datos para una aerolínea comercial en Estados Unidos
-- Universidad Continental - Escuela de Posgrado - Maestría en Ciencia de Datos
-- Gestión de datos y bases de datos con SQL (PSMA00611)
-- Docentes: Walter Alejandro Silva Sotillo y Max Leoncio Mucha Morales
-- Integrantes: Carlos Veliz de Villa Aguirre, Elias Sifuentes Valles,
-- Carlos De los Rios De la Roca.
-- Video de sustentación: [URL DEL VIDEO]
-- Fuente del modelo: github.com/CARLOSDELOSRIOS/aerolinea-bd-psma00611
-- Revisión de origen: c0aa0394bd39de304d001974caa2c9adf06bab67
--
-- A. CONTINUIDAD DEL MODELO
-- Se conservan los esquemas ref, rh, ops, ven, aud, adm y tst del adelanto,
-- las 41 tablas físicas (39 de dominio/auditoría y 2 de control), sus nombres,
-- atributos, PK, FK, restricciones, índices, funciones, triggers y procedimientos.
-- Se incluyen las 20 consultas Q01-Q20 del catálogo original, como procedimientos
-- rpt.usp_q01 a rpt.usp_q20. Q02 utiliza mínimo 1 vuelo por grupo, adecuado a
-- la muestra reducida. El resto conserva sus parámetros iniciales.
-- La carga de demostración es nueva, pequeña y ejecutable íntegramente en SQL.
-- No reproduce el volumen ni los resultados de la simulación Python del adelanto.
-- Datos sintéticos. Moneda: USD. Corte analítico: 2026-11-01 00:00:00 UTC.
-- Marcas transaccionales en UTC y vuelos en DATETIMEOFFSET con hora local.
--
-- B. REQUISITOS Y RELACIONES
-- Persona puede ser comprador o pasajero. Cliente es afiliación opcional.
-- Compra agrupa tiquetes y registra comprador, canal y vendedor.
-- Ruta define origen/destino. Programacion define horario y vigencia.
-- Programacion_dia registra los días semanales, sin listas en una celda.
-- Vuelo es una operación fechada de una programación.
-- Configuracion_asientos y Asiento_configuracion describen el mapa de cabinas.
-- Vuelo_cabina controla capacidad e inventario por vuelo y clase.
-- Tarifa establece precio por ruta/cabina y vigencia. Tiquete conserva el precio
-- pactado. Pago registra abonos y Reembolso registra devoluciones por pago.
-- Asignacion_tripulacion resuelve la relación N:M entre empleados y vuelos.
-- Localizacion es supertipo de aeropuerto y también representa oficinas/web.
--
-- C. NORMALIZACIÓN E INTEGRIDAD
-- 1FN: pagos, reembolsos, asientos y días se registran en filas separadas.
-- 2FN: el rol en Asignacion_tripulacion depende del vuelo y empleado completos.
-- Los nombres y cargos no se repiten en esa relación, sino en sus entidades.
-- 3FN: se separan Persona/Cliente, Compra/Tiquete, Ruta/Programacion/Vuelo,
-- Cargo/Departamento y Modelo/Configuracion/Avion para evitar dependencias
-- transitivas y anomalías de inserción, actualización y eliminación.
-- Excepciones físicas documentadas: precio y porcentaje históricos, capacidad
-- y contador de inventario por vuelo, cabina redundante para FK compuestas,
-- y columnas derivadas persistidas. No se afirma 3FN estricta de cada columna
-- física: el diseño lógico normalizado incorpora redundancias controladas.
-- Precio y porcentaje se validan al vender y quedan protegidos posteriormente.
-- Plazas_ocupadas se mantiene por trigger y se concilia con tiquetes activos.
-- Los importes derivados son calculados por el motor, no editables manualmente.
-- PK: identidad. FK: referencias existentes. UNIQUE: claves alternativas.
-- CHECK y NOT NULL: dominio y obligatoriedad. Triggers: coherencia entre tablas,
-- estados, fechas, aforo, asientos, tarifas, pagos, reembolsos y asignaciones.
-- Pago total confirmado es requisito de EMITIDO. Un abono parcial conserva
-- el tiquete en RESERVADO. Este comportamiento es el del adelanto original.
-- Cobros y reembolsos se agregan por separado antes de unirse a tiquetes.
-- La ocupación volada cuenta USADO, la vendida incluye plazas retenidas activas.
--
-- D. EJECUCIÓN
-- Conexión a una base de usuario en Azure SQL Database o SQL Server 2022.
-- Requiere permisos equivalentes a propietario para crear objetos, roles,
-- usuarios internos sin login, enmascaramiento y permisos de demostración.
-- No crea bases ni elimina tablas existentes. No modifica el esquema pac.
-- La seguridad recrea un índice recién creado al aplicar enmascaramiento.
-- Deben estar libres los esquemas de destino ref/rh/ops/ven/rpt/adm/aud/tst/stg
-- y los nombres rol_analista/rol_ventas/rol_operaciones/rol_aplicacion.
-- Instalación transaccional. Un fallo revierte la instalación de esta versión.
-- Para repetir reportes se ejecutan únicamente los EXEC de la sección H.
-- Las tablas stg y la aplicación Python no son necesarias para esta carga.
-- Sin credenciales, sin GO y sin comentarios de bloque para el editor del portal.

SET NOCOUNT ON;
SET XACT_ABORT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_PADDING ON;
SET ANSI_WARNINGS ON;
SET ARITHABORT ON;
SET CONCAT_NULL_YIELDS_NULL ON;
SET NUMERIC_ROUNDABORT OFF;
IF DB_NAME() IN (N'master',N'model',N'msdb',N'tempdb')
 THROW 51980,N'La conexión debe apuntar a una base de usuario.',1;
IF EXISTS (SELECT 1 FROM sys.schemas WHERE name IN ('ref','rh','ops','ven','rpt','adm','aud','tst','stg'))
 THROW 51981,N'Existen esquemas del modelo original. No reinstalar ni sobrescribir.',1;
IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name IN ('rol_analista','rol_ventas','rol_operaciones','rol_aplicacion'))
 THROW 51982,N'Existen roles de destino, revisar la base seleccionada.',1;
BEGIN TRY
 BEGIN TRANSACTION;

-- E. 02_esquemas_y_tablas, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 02_esquemas_y_tablas, lote 2
EXEC sys.sp_executesql N'IF SCHEMA_ID(N''adm'') IS NULL EXEC (N''CREATE SCHEMA adm AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''ref'') IS NULL EXEC (N''CREATE SCHEMA ref AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''ops'') IS NULL EXEC (N''CREATE SCHEMA ops AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''rh'')  IS NULL EXEC (N''CREATE SCHEMA rh AUTHORIZATION dbo;'');   
IF SCHEMA_ID(N''ven'') IS NULL EXEC (N''CREATE SCHEMA ven AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''aud'') IS NULL EXEC (N''CREATE SCHEMA aud AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''rpt'') IS NULL EXEC (N''CREATE SCHEMA rpt AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''stg'') IS NULL EXEC (N''CREATE SCHEMA stg AUTHORIZATION dbo;'');  
IF SCHEMA_ID(N''tst'') IS NULL EXEC (N''CREATE SCHEMA tst AUTHORIZATION dbo;'');';

-- E. 02_esquemas_y_tablas, lote 3
EXEC sys.sp_executesql N'IF OBJECT_ID(N''adm.registro_despliegue'', N''U'') IS NULL
CREATE TABLE adm.registro_despliegue (
    id_registro     INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_registro_despliegue PRIMARY KEY,
    script          VARCHAR(80)       NOT NULL,
    descripcion     NVARCHAR(400)     NULL,
    ejecutado_utc   DATETIME2(0)      NOT NULL CONSTRAINT df_registro_despliegue_ejecutado DEFAULT (SYSUTCDATETIME()),
    usuario         NVARCHAR(128)     NOT NULL CONSTRAINT df_registro_despliegue_usuario DEFAULT (SUSER_SNAME()),
    version_motor   NVARCHAR(128)     NOT NULL CONSTRAINT df_registro_despliegue_version DEFAULT (CAST(SERVERPROPERTY(''ProductVersion'') AS NVARCHAR(128)))
);';

-- E. 02_esquemas_y_tablas, lote 4
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ven.seq_numero_tiquete'', N''SO'') IS NULL
    CREATE SEQUENCE ven.seq_numero_tiquete AS BIGINT START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999 NO CYCLE CACHE 50;
IF OBJECT_ID(N''ven.seq_numero_viajero'', N''SO'') IS NULL
    CREATE SEQUENCE ven.seq_numero_viajero AS INT START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 99999999 NO CYCLE CACHE 20;';

-- E. 02_esquemas_y_tablas, lote 5
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ref.pais'', N''U'') IS NULL
CREATE TABLE ref.pais (
    codigo_pais     CHAR(2)        NOT NULL CONSTRAINT pk_pais PRIMARY KEY,   
    nombre          NVARCHAR(60)   NOT NULL
);

IF OBJECT_ID(N''ref.estado_eeuu'', N''U'') IS NULL
CREATE TABLE ref.estado_eeuu (
    codigo_estado   CHAR(2)        NOT NULL CONSTRAINT pk_estado_eeuu PRIMARY KEY,  
    nombre          NVARCHAR(40)   NOT NULL
);

IF OBJECT_ID(N''ref.zona_horaria'', N''U'') IS NULL
CREATE TABLE ref.zona_horaria (
    nombre_windows          VARCHAR(50)   NOT NULL CONSTRAINT pk_zona_horaria PRIMARY KEY,  
    nombre_iana             VARCHAR(50)   NOT NULL,
    descripcion             NVARCHAR(100) NOT NULL,
    observa_horario_verano  BIT           NOT NULL
);

IF OBJECT_ID(N''ref.localizacion'', N''U'') IS NULL
CREATE TABLE ref.localizacion (
    id_localizacion     INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_localizacion PRIMARY KEY,
    codigo_localizacion VARCHAR(12)    NOT NULL,
    tipo_localizacion   CHAR(3)        NOT NULL,           
    nombre              NVARCHAR(100)  NOT NULL,
    ciudad              NVARCHAR(60)   NULL,
    codigo_estado       CHAR(2)        NULL,
    direccion           NVARCHAR(150)  NULL,
    codigo_postal       VARCHAR(10)    NULL,
    zona_horaria        VARCHAR(50)    NULL,
    url                 VARCHAR(200)   NULL,
    vende_tiquetes      BIT            NOT NULL CONSTRAINT df_localizacion_vende DEFAULT (1),
    activa              BIT            NOT NULL CONSTRAINT df_localizacion_activa DEFAULT (1),
    fecha_apertura      DATE           NOT NULL,
    creado_utc          DATETIME2(0)   NOT NULL CONSTRAINT df_localizacion_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ref.aeropuerto'', N''U'') IS NULL
CREATE TABLE ref.aeropuerto (                          
    id_localizacion     INT            NOT NULL CONSTRAINT pk_aeropuerto PRIMARY KEY,
    tipo_localizacion   AS CAST(''AER'' AS CHAR(3)) PERSISTED NOT NULL,  
    codigo_iata         CHAR(3)        NOT NULL,
    codigo_icao         CHAR(4)        NOT NULL,
    latitud             DECIMAL(9,6)   NOT NULL,
    longitud            DECIMAL(9,6)   NOT NULL,
    es_base_operaciones BIT            NOT NULL CONSTRAINT df_aeropuerto_base DEFAULT (0)
);

IF OBJECT_ID(N''ref.cabina'', N''U'') IS NULL
CREATE TABLE ref.cabina (
    codigo_cabina           CHAR(3)        NOT NULL CONSTRAINT pk_cabina PRIMARY KEY,   
    nombre                  NVARCHAR(40)   NOT NULL,
    descripcion             NVARCHAR(200)  NOT NULL,
    piezas_equipaje_bodega  TINYINT        NOT NULL,
    peso_max_equipaje_kg    TINYINT        NOT NULL,
    acceso_sala_vip         BIT            NOT NULL,
    orden_abordaje          TINYINT        NOT NULL
);

IF OBJECT_ID(N''ref.modelo_avion'', N''U'') IS NULL
CREATE TABLE ref.modelo_avion (
    id_modelo               SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_modelo_avion PRIMARY KEY,
    fabricante              NVARCHAR(40)   NOT NULL,
    modelo                  NVARCHAR(40)   NOT NULL,
    alcance_millas          SMALLINT       NOT NULL,
    velocidad_crucero_mph   SMALLINT       NOT NULL
);

IF OBJECT_ID(N''ref.metodo_pago'', N''U'') IS NULL
CREATE TABLE ref.metodo_pago (
    codigo_metodo   VARCHAR(15)    NOT NULL CONSTRAINT pk_metodo_pago PRIMARY KEY,   
    nombre          NVARCHAR(40)   NOT NULL,
    es_tarjeta      BIT            NOT NULL,
    permite_web     BIT            NOT NULL,
    permite_fisico  BIT            NOT NULL
);

IF OBJECT_ID(N''ref.estado_vuelo'', N''U'') IS NULL
CREATE TABLE ref.estado_vuelo (
    codigo_estado       VARCHAR(15)    NOT NULL CONSTRAINT pk_estado_vuelo PRIMARY KEY,
    descripcion         NVARCHAR(100)  NOT NULL,
    es_estado_inicial   BIT            NOT NULL,
    es_final            BIT            NOT NULL
);

IF OBJECT_ID(N''ref.estado_tiquete'', N''U'') IS NULL
CREATE TABLE ref.estado_tiquete (
    codigo_estado       VARCHAR(15)    NOT NULL CONSTRAINT pk_estado_tiquete PRIMARY KEY,
    descripcion         NVARCHAR(100)  NOT NULL,
    es_estado_inicial   BIT            NOT NULL,
    es_final            BIT            NOT NULL,
    ocupa_inventario    BIT            NOT NULL        
);

IF OBJECT_ID(N''ref.estado_pago'', N''U'') IS NULL
CREATE TABLE ref.estado_pago (
    codigo_estado       VARCHAR(15)    NOT NULL CONSTRAINT pk_estado_pago PRIMARY KEY,
    descripcion         NVARCHAR(100)  NOT NULL,
    es_estado_inicial   BIT            NOT NULL,
    es_final            BIT            NOT NULL,
    es_cobro            BIT            NOT NULL        
);

IF OBJECT_ID(N''ref.transicion_vuelo'', N''U'') IS NULL
CREATE TABLE ref.transicion_vuelo (
    estado_origen   VARCHAR(15) NOT NULL,
    estado_destino  VARCHAR(15) NOT NULL,
    CONSTRAINT pk_transicion_vuelo PRIMARY KEY (estado_origen, estado_destino)
);

IF OBJECT_ID(N''ref.transicion_tiquete'', N''U'') IS NULL
CREATE TABLE ref.transicion_tiquete (
    estado_origen   VARCHAR(15) NOT NULL,
    estado_destino  VARCHAR(15) NOT NULL,
    CONSTRAINT pk_transicion_tiquete PRIMARY KEY (estado_origen, estado_destino)
);

IF OBJECT_ID(N''ref.transicion_pago'', N''U'') IS NULL
CREATE TABLE ref.transicion_pago (
    estado_origen   VARCHAR(15) NOT NULL,
    estado_destino  VARCHAR(15) NOT NULL,
    CONSTRAINT pk_transicion_pago PRIMARY KEY (estado_origen, estado_destino)
);

IF OBJECT_ID(N''ref.motivo_cancelacion'', N''U'') IS NULL
CREATE TABLE ref.motivo_cancelacion (
    codigo_motivo   VARCHAR(15)    NOT NULL CONSTRAINT pk_motivo_cancelacion PRIMARY KEY,
    descripcion     NVARCHAR(150)  NOT NULL,
    iniciado_por    VARCHAR(10)    NOT NULL,       
    reembolso_total BIT            NOT NULL
);

IF OBJECT_ID(N''ref.parametro'', N''U'') IS NULL
CREATE TABLE ref.parametro (
    clave           VARCHAR(40)    NOT NULL CONSTRAINT pk_parametro PRIMARY KEY,
    valor           VARCHAR(100)   NOT NULL,
    tipo_dato       VARCHAR(10)    NOT NULL,
    descripcion     NVARCHAR(200)  NOT NULL
);

IF OBJECT_ID(N''ref.mensaje_error'', N''U'') IS NULL
CREATE TABLE ref.mensaje_error (
    numero_error    INT            NOT NULL CONSTRAINT pk_mensaje_error PRIMARY KEY,
    mensaje         NVARCHAR(250)  NOT NULL,
    regla           VARCHAR(10)    NULL           
);';

-- E. 02_esquemas_y_tablas, lote 6
EXEC sys.sp_executesql N'IF OBJECT_ID(N''rh.departamento'', N''U'') IS NULL
CREATE TABLE rh.departamento (
    codigo_departamento VARCHAR(10)   NOT NULL CONSTRAINT pk_departamento PRIMARY KEY,
    nombre              NVARCHAR(60)  NOT NULL
);

IF OBJECT_ID(N''rh.cargo'', N''U'') IS NULL
CREATE TABLE rh.cargo (
    codigo_cargo            VARCHAR(15)   NOT NULL CONSTRAINT pk_cargo PRIMARY KEY,
    nombre                  NVARCHAR(60)  NOT NULL,
    codigo_departamento     VARCHAR(10)   NOT NULL,
    categoria_tripulacion   VARCHAR(7)    NULL          
);

IF OBJECT_ID(N''rh.empleado'', N''U'') IS NULL
CREATE TABLE rh.empleado (
    id_empleado             INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_empleado PRIMARY KEY,
    numero_empleado         CHAR(6)        NOT NULL,
    nombres                 NVARCHAR(60)   NOT NULL,
    apellidos               NVARCHAR(60)   NOT NULL,
    fecha_nacimiento        DATE           NOT NULL,
    email_corporativo       VARCHAR(120)   NOT NULL,
    telefono                VARCHAR(20)    NULL,
    fecha_contratacion      DATE           NOT NULL,
    fecha_terminacion       DATE           NULL,
    codigo_cargo            VARCHAR(15)    NOT NULL,
    id_localizacion_base    INT            NOT NULL,
    id_supervisor           INT            NULL,
    salario_anual_usd       DECIMAL(12,2)  NOT NULL,     
    creado_utc              DATETIME2(0)   NOT NULL CONSTRAINT df_empleado_creado DEFAULT (SYSUTCDATETIME())
);';

-- E. 02_esquemas_y_tablas, lote 7
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ops.configuracion_asientos'', N''U'') IS NULL
CREATE TABLE ops.configuracion_asientos (
    id_configuracion        SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_configuracion_asientos PRIMARY KEY,
    codigo_configuracion    VARCHAR(20)    NOT NULL,
    id_modelo               SMALLINT       NOT NULL,
    descripcion             NVARCHAR(150)  NOT NULL
);

IF OBJECT_ID(N''ops.asiento_configuracion'', N''U'') IS NULL
CREATE TABLE ops.asiento_configuracion (
    id_configuracion        SMALLINT    NOT NULL,
    codigo_asiento          VARCHAR(4)  NOT NULL,       
    fila                    TINYINT     NOT NULL,
    letra                   CHAR(1)     NOT NULL,
    codigo_cabina           CHAR(3)     NOT NULL,
    es_ventana              BIT         NOT NULL,
    es_pasillo              BIT         NOT NULL,
    es_salida_emergencia    BIT         NOT NULL CONSTRAINT df_asiento_salida DEFAULT (0),
    CONSTRAINT pk_asiento_configuracion PRIMARY KEY (id_configuracion, codigo_asiento)
);

IF OBJECT_ID(N''ops.avion'', N''U'') IS NULL
CREATE TABLE ops.avion (
    id_avion                SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_avion PRIMARY KEY,
    matricula               VARCHAR(10)    NOT NULL,     
    numero_serie            VARCHAR(20)    NOT NULL,     
    id_configuracion        SMALLINT       NOT NULL,
    fecha_fabricacion       DATE           NOT NULL,
    fecha_incorporacion     DATE           NOT NULL,
    estado_operativo        VARCHAR(15)    NOT NULL CONSTRAINT df_avion_estado DEFAULT (''ACTIVO''),
    id_aeropuerto_base      INT            NOT NULL,
    creado_utc              DATETIME2(0)   NOT NULL CONSTRAINT df_avion_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ops.ruta'', N''U'') IS NULL
CREATE TABLE ops.ruta (
    id_ruta                 SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_ruta PRIMARY KEY,
    id_aeropuerto_origen    INT            NOT NULL,
    id_aeropuerto_destino   INT            NOT NULL,
    distancia_millas        SMALLINT       NOT NULL,
    activa                  BIT            NOT NULL CONSTRAINT df_ruta_activa DEFAULT (1),
    fecha_inicio_operacion  DATE           NULL,
    creado_utc              DATETIME2(0)   NOT NULL CONSTRAINT df_ruta_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ops.programacion'', N''U'') IS NULL
CREATE TABLE ops.programacion (
    id_programacion         INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_programacion PRIMARY KEY,
    numero_vuelo            SMALLINT       NOT NULL,
    id_ruta                 SMALLINT       NOT NULL,
    hora_salida_local       TIME(0)        NOT NULL,     
    duracion_programada_min SMALLINT       NOT NULL,
    vigente_desde           DATE           NOT NULL,
    vigente_hasta           DATE           NULL,         
    activa                  BIT            NOT NULL CONSTRAINT df_programacion_activa DEFAULT (1),
    creado_utc              DATETIME2(0)   NOT NULL CONSTRAINT df_programacion_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ops.programacion_dia'', N''U'') IS NULL
CREATE TABLE ops.programacion_dia (
    id_programacion         INT            NOT NULL,
    dia_semana              TINYINT        NOT NULL,     
    CONSTRAINT pk_programacion_dia PRIMARY KEY (id_programacion, dia_semana)
);

IF OBJECT_ID(N''ops.vuelo'', N''U'') IS NULL
CREATE TABLE ops.vuelo (
    id_vuelo                INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_vuelo PRIMARY KEY,
    id_programacion         INT                NOT NULL,
    salida_programada       DATETIMEOFFSET(0)  NOT NULL,   
    llegada_programada      DATETIMEOFFSET(0)  NOT NULL,   
    fecha_salida_local      AS CAST(salida_programada AS DATE) PERSISTED,   
    salida_estimada         DATETIMEOFFSET(0)  NULL,       
    salida_real             DATETIMEOFFSET(0)  NULL,
    llegada_real            DATETIMEOFFSET(0)  NULL,
    id_avion                SMALLINT           NULL,       
    codigo_estado           VARCHAR(15)        NOT NULL CONSTRAINT df_vuelo_estado DEFAULT (''PROGRAMADO''),
    puerta_salida           VARCHAR(5)         NULL,
    motivo_cancelacion      NVARCHAR(200)      NULL,
    creado_utc              DATETIME2(0)       NOT NULL CONSTRAINT df_vuelo_creado DEFAULT (SYSUTCDATETIME()),
    version_fila            ROWVERSION         NOT NULL    
);

IF OBJECT_ID(N''ops.vuelo_cabina'', N''U'') IS NULL
CREATE TABLE ops.vuelo_cabina (
    id_vuelo                INT        NOT NULL,
    codigo_cabina           CHAR(3)    NOT NULL,
    capacidad               SMALLINT   NOT NULL,           
    plazas_ocupadas         SMALLINT   NOT NULL CONSTRAINT df_vuelo_cabina_ocupadas DEFAULT (0),  
    CONSTRAINT pk_vuelo_cabina PRIMARY KEY (id_vuelo, codigo_cabina)
);

IF OBJECT_ID(N''ops.asignacion_tripulacion'', N''U'') IS NULL
CREATE TABLE ops.asignacion_tripulacion (
    id_vuelo        INT           NOT NULL,
    id_empleado     INT           NOT NULL,
    rol_vuelo       VARCHAR(15)   NOT NULL,     
    asignado_utc    DATETIME2(0)  NOT NULL CONSTRAINT df_asignacion_asignado DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT pk_asignacion_tripulacion PRIMARY KEY (id_vuelo, id_empleado)
);';

-- E. 02_esquemas_y_tablas, lote 8
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ven.persona'', N''U'') IS NULL
CREATE TABLE ven.persona (
    id_persona                  INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_persona PRIMARY KEY,
    nombres                     NVARCHAR(60)   NOT NULL,
    apellidos                   NVARCHAR(60)   NOT NULL,
    fecha_nacimiento            DATE           NULL,     
    genero                      CHAR(1)        NULL,     
    email_contacto              VARCHAR(120)   NULL,
    telefono                    VARCHAR(20)    NULL,
    codigo_pais_nacionalidad    CHAR(2)        NULL,
    tipo_documento              VARCHAR(10)    NULL,
    numero_documento            VARCHAR(20)    NULL,
    codigo_pais_documento       CHAR(2)        NULL,
    creado_utc                  DATETIME2(0)   NOT NULL CONSTRAINT df_persona_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ven.cliente'', N''U'') IS NULL
CREATE TABLE ven.cliente (                     
    id_persona                  INT            NOT NULL CONSTRAINT pk_cliente PRIMARY KEY,
    numero_viajero              CHAR(10)       NOT NULL,
    email_acceso                VARCHAR(120)   NOT NULL,
    fecha_registro_utc          DATETIME2(0)   NOT NULL CONSTRAINT df_cliente_registro DEFAULT (SYSUTCDATETIME()),
    nivel_lealtad               VARCHAR(10)    NOT NULL CONSTRAINT df_cliente_nivel DEFAULT (''BASICO''),
    acepta_marketing            BIT            NOT NULL CONSTRAINT df_cliente_marketing DEFAULT (0),
    estado_cuenta               VARCHAR(10)    NOT NULL CONSTRAINT df_cliente_estado DEFAULT (''ACTIVA''),
    id_aeropuerto_preferido     INT            NULL
);

IF OBJECT_ID(N''ven.compra'', N''U'') IS NULL
CREATE TABLE ven.compra (
    id_compra               INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_compra PRIMARY KEY,
    codigo_reserva          CHAR(6)        NOT NULL,      
    id_persona_comprador    INT            NOT NULL,
    id_localizacion_venta   INT            NOT NULL,      
    id_empleado_vendedor    INT            NULL,          
    fecha_compra_utc        DATETIME2(0)   NOT NULL CONSTRAINT df_compra_fecha DEFAULT (SYSUTCDATETIME()),
    email_confirmacion      VARCHAR(120)   NULL
);

IF OBJECT_ID(N''ven.tarifa'', N''U'') IS NULL
CREATE TABLE ven.tarifa (
    id_tarifa           INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_tarifa PRIMARY KEY,
    id_ruta             SMALLINT       NOT NULL,
    codigo_cabina       CHAR(3)        NOT NULL,
    precio_base_usd     DECIMAL(10,2)  NOT NULL,
    vigente_desde       DATE           NOT NULL,          
    vigente_hasta       DATE           NULL,
    creado_utc          DATETIME2(0)   NOT NULL CONSTRAINT df_tarifa_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ven.descuento'', N''U'') IS NULL
CREATE TABLE ven.descuento (
    id_descuento                SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_descuento PRIMARY KEY,
    codigo_descuento            VARCHAR(20)    NOT NULL,
    descripcion                 NVARCHAR(150)  NOT NULL,
    porcentaje                  DECIMAL(5,2)   NOT NULL,
    vigente_desde               DATE           NOT NULL,   
    vigente_hasta               DATE           NOT NULL,
    solo_clientes_registrados   BIT            NOT NULL CONSTRAINT df_descuento_registrados DEFAULT (0),
    codigo_cabina               CHAR(3)        NULL,       
    dias_anticipacion_min       SMALLINT       NULL,       
    activo                      BIT            NOT NULL CONSTRAINT df_descuento_activo DEFAULT (1),
    creado_utc                  DATETIME2(0)   NOT NULL CONSTRAINT df_descuento_creado DEFAULT (SYSUTCDATETIME())
);

IF OBJECT_ID(N''ven.politica_cancelacion'', N''U'') IS NULL
CREATE TABLE ven.politica_cancelacion (
    id_politica             SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_politica_cancelacion PRIMARY KEY,
    codigo_cabina           CHAR(3)        NOT NULL,
    horas_antes_min         SMALLINT       NOT NULL,      
    porcentaje_reembolso    DECIMAL(5,2)   NOT NULL
);

IF OBJECT_ID(N''ven.tiquete'', N''U'') IS NULL
CREATE TABLE ven.tiquete (
    id_tiquete                  INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_tiquete PRIMARY KEY,
    numero_tiquete              CHAR(13)       NOT NULL,      
    id_compra                   INT            NOT NULL,
    id_vuelo                    INT            NOT NULL,
    codigo_cabina               CHAR(3)        NOT NULL,
    id_persona_pasajero         INT            NOT NULL,
    codigo_asiento              VARCHAR(4)     NULL,          
    id_tarifa                   INT            NOT NULL,
    precio_base_usd             DECIMAL(10,2)  NOT NULL,      
    id_descuento                SMALLINT       NULL,
    porcentaje_descuento        DECIMAL(5,2)   NOT NULL CONSTRAINT df_tiquete_porcentaje DEFAULT (0),
    monto_descuento_usd         AS CAST(ROUND(precio_base_usd * porcentaje_descuento / 100.0, 2) AS DECIMAL(10,2)) PERSISTED,
    precio_final_usd            AS CAST(precio_base_usd - ROUND(precio_base_usd * porcentaje_descuento / 100.0, 2) AS DECIMAL(10,2)) PERSISTED,
    codigo_estado               VARCHAR(15)    NOT NULL CONSTRAINT df_tiquete_estado DEFAULT (''RESERVADO''),
    fecha_limite_pago_utc       DATETIME2(0)   NOT NULL,
    fecha_emision_utc           DATETIME2(0)   NULL,
    fecha_cancelacion_utc       DATETIME2(0)   NULL,
    codigo_motivo_cancelacion   VARCHAR(15)    NULL,
    creado_utc                  DATETIME2(0)   NOT NULL CONSTRAINT df_tiquete_creado DEFAULT (SYSUTCDATETIME()),
    version_fila                ROWVERSION     NOT NULL
);

IF OBJECT_ID(N''ven.pago'', N''U'') IS NULL
CREATE TABLE ven.pago (
    id_pago                     INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_pago PRIMARY KEY,
    id_tiquete                  INT            NOT NULL,
    codigo_metodo               VARCHAR(15)    NOT NULL,
    id_localizacion_cobro       INT            NOT NULL,
    monto_usd                   DECIMAL(10,2)  NOT NULL,
    codigo_estado               VARCHAR(15)    NOT NULL CONSTRAINT df_pago_estado DEFAULT (''PENDIENTE''),
    fecha_creacion_utc          DATETIME2(0)   NOT NULL CONSTRAINT df_pago_creacion DEFAULT (SYSUTCDATETIME()),
    fecha_resolucion_utc        DATETIME2(0)   NULL,          
    referencia_autorizacion     VARCHAR(30)    NULL,
    ultimos4_tarjeta            CHAR(4)        NULL,          
    marca_tarjeta               VARCHAR(15)    NULL,
    motivo_rechazo              NVARCHAR(100)  NULL
);

IF OBJECT_ID(N''ven.reembolso'', N''U'') IS NULL
CREATE TABLE ven.reembolso (
    id_reembolso            INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_reembolso PRIMARY KEY,
    id_pago                 INT            NOT NULL,
    monto_usd               DECIMAL(10,2)  NOT NULL,
    fecha_reembolso_utc     DATETIME2(0)   NOT NULL CONSTRAINT df_reembolso_fecha DEFAULT (SYSUTCDATETIME()),
    codigo_motivo           VARCHAR(15)    NOT NULL,
    porcentaje_aplicado     DECIMAL(5,2)   NOT NULL,
    regla_aplicada          VARCHAR(20)    NOT NULL,          
    referencia              VARCHAR(30)    NULL
);';

-- E. 02_esquemas_y_tablas, lote 9
EXEC sys.sp_executesql N'IF OBJECT_ID(N''aud.cambio_estado'', N''U'') IS NULL
CREATE TABLE aud.cambio_estado (
    id_cambio           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_cambio_estado PRIMARY KEY,
    entidad             VARCHAR(10)    NOT NULL,      
    id_entidad          INT            NOT NULL,
    estado_anterior     VARCHAR(15)    NULL,          
    estado_nuevo        VARCHAR(15)    NOT NULL,
    registrado_utc      DATETIME2(3)   NOT NULL CONSTRAINT df_cambio_estado_registrado DEFAULT (SYSUTCDATETIME()),
    usuario             NVARCHAR(128)  NOT NULL CONSTRAINT df_cambio_estado_usuario DEFAULT (SUSER_SNAME()),
    aplicacion          NVARCHAR(128)  NULL CONSTRAINT df_cambio_estado_aplicacion DEFAULT (APP_NAME())
);';

-- E. 02_esquemas_y_tablas, lote 10
EXEC sys.sp_executesql N'IF OBJECT_ID(N''tst.resultado_prueba'', N''U'') IS NULL
CREATE TABLE tst.resultado_prueba (
    id_resultado    INT IDENTITY(1,1) NOT NULL CONSTRAINT pk_resultado_prueba PRIMARY KEY,
    id_ejecucion    UNIQUEIDENTIFIER NOT NULL,
    id_prueba       VARCHAR(20)    NOT NULL,
    regla           VARCHAR(20)    NULL,
    descripcion     NVARCHAR(300)  NOT NULL,
    resultado       VARCHAR(10)    NOT NULL,          
    detalle         NVARCHAR(1000) NULL,
    ejecutado_utc   DATETIME2(3)   NOT NULL CONSTRAINT df_resultado_prueba_ejecutado DEFAULT (SYSUTCDATETIME())
);';

-- E. 02_esquemas_y_tablas, lote 11
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''02_esquemas_y_tablas'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''02_esquemas_y_tablas'', N''Esquemas, secuencias y tablas'');';

-- E. 03_claves_y_restricciones, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 03_claves_y_restricciones, lote 2
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ref.uq_pais_nombre'', N''UQ'') IS NULL
    ALTER TABLE ref.pais ADD CONSTRAINT uq_pais_nombre UNIQUE (nombre);
IF OBJECT_ID(N''ref.uq_estado_eeuu_nombre'', N''UQ'') IS NULL
    ALTER TABLE ref.estado_eeuu ADD CONSTRAINT uq_estado_eeuu_nombre UNIQUE (nombre);
IF OBJECT_ID(N''ref.uq_localizacion_codigo'', N''UQ'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT uq_localizacion_codigo UNIQUE (codigo_localizacion);
IF OBJECT_ID(N''ref.uq_localizacion_id_tipo'', N''UQ'') IS NULL            
    ALTER TABLE ref.localizacion ADD CONSTRAINT uq_localizacion_id_tipo UNIQUE (id_localizacion, tipo_localizacion);
IF OBJECT_ID(N''ref.uq_aeropuerto_iata'', N''UQ'') IS NULL
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT uq_aeropuerto_iata UNIQUE (codigo_iata);
IF OBJECT_ID(N''ref.uq_aeropuerto_icao'', N''UQ'') IS NULL
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT uq_aeropuerto_icao UNIQUE (codigo_icao);
IF OBJECT_ID(N''ref.uq_cabina_nombre'', N''UQ'') IS NULL
    ALTER TABLE ref.cabina ADD CONSTRAINT uq_cabina_nombre UNIQUE (nombre);
IF OBJECT_ID(N''ref.uq_cabina_orden_abordaje'', N''UQ'') IS NULL
    ALTER TABLE ref.cabina ADD CONSTRAINT uq_cabina_orden_abordaje UNIQUE (orden_abordaje);
IF OBJECT_ID(N''ref.uq_modelo_avion'', N''UQ'') IS NULL
    ALTER TABLE ref.modelo_avion ADD CONSTRAINT uq_modelo_avion UNIQUE (fabricante, modelo);
IF OBJECT_ID(N''ref.uq_metodo_pago_nombre'', N''UQ'') IS NULL
    ALTER TABLE ref.metodo_pago ADD CONSTRAINT uq_metodo_pago_nombre UNIQUE (nombre);
IF OBJECT_ID(N''rh.uq_departamento_nombre'', N''UQ'') IS NULL
    ALTER TABLE rh.departamento ADD CONSTRAINT uq_departamento_nombre UNIQUE (nombre);
IF OBJECT_ID(N''rh.uq_cargo_nombre'', N''UQ'') IS NULL
    ALTER TABLE rh.cargo ADD CONSTRAINT uq_cargo_nombre UNIQUE (nombre);
IF OBJECT_ID(N''rh.uq_empleado_numero'', N''UQ'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT uq_empleado_numero UNIQUE (numero_empleado);
IF OBJECT_ID(N''rh.uq_empleado_email'', N''UQ'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT uq_empleado_email UNIQUE (email_corporativo);
IF OBJECT_ID(N''ops.uq_configuracion_codigo'', N''UQ'') IS NULL
    ALTER TABLE ops.configuracion_asientos ADD CONSTRAINT uq_configuracion_codigo UNIQUE (codigo_configuracion);
IF OBJECT_ID(N''ops.uq_asiento_fila_letra'', N''UQ'') IS NULL
    ALTER TABLE ops.asiento_configuracion ADD CONSTRAINT uq_asiento_fila_letra UNIQUE (id_configuracion, fila, letra);
IF OBJECT_ID(N''ops.uq_avion_matricula'', N''UQ'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT uq_avion_matricula UNIQUE (matricula);
IF OBJECT_ID(N''ops.uq_avion_numero_serie'', N''UQ'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT uq_avion_numero_serie UNIQUE (numero_serie);
IF OBJECT_ID(N''ops.uq_ruta_origen_destino'', N''UQ'') IS NULL                       
    ALTER TABLE ops.ruta ADD CONSTRAINT uq_ruta_origen_destino UNIQUE (id_aeropuerto_origen, id_aeropuerto_destino);
IF OBJECT_ID(N''ops.uq_programacion_numero_vigencia'', N''UQ'') IS NULL
    ALTER TABLE ops.programacion ADD CONSTRAINT uq_programacion_numero_vigencia UNIQUE (numero_vuelo, vigente_desde);
IF OBJECT_ID(N''ops.uq_vuelo_programacion_fecha'', N''UQ'') IS NULL                  
    ALTER TABLE ops.vuelo ADD CONSTRAINT uq_vuelo_programacion_fecha UNIQUE (id_programacion, fecha_salida_local);
IF OBJECT_ID(N''ven.uq_cliente_numero_viajero'', N''UQ'') IS NULL                    
    ALTER TABLE ven.cliente ADD CONSTRAINT uq_cliente_numero_viajero UNIQUE (numero_viajero);
IF OBJECT_ID(N''ven.uq_cliente_email_acceso'', N''UQ'') IS NULL                      
    ALTER TABLE ven.cliente ADD CONSTRAINT uq_cliente_email_acceso UNIQUE (email_acceso);
IF OBJECT_ID(N''ven.uq_compra_codigo_reserva'', N''UQ'') IS NULL
    ALTER TABLE ven.compra ADD CONSTRAINT uq_compra_codigo_reserva UNIQUE (codigo_reserva);
IF OBJECT_ID(N''ven.uq_tarifa_ruta_cabina_desde'', N''UQ'') IS NULL
    ALTER TABLE ven.tarifa ADD CONSTRAINT uq_tarifa_ruta_cabina_desde UNIQUE (id_ruta, codigo_cabina, vigente_desde);
IF OBJECT_ID(N''ven.uq_tarifa_id_cabina'', N''UQ'') IS NULL                          
    ALTER TABLE ven.tarifa ADD CONSTRAINT uq_tarifa_id_cabina UNIQUE (id_tarifa, codigo_cabina);
IF OBJECT_ID(N''ven.uq_descuento_codigo'', N''UQ'') IS NULL
    ALTER TABLE ven.descuento ADD CONSTRAINT uq_descuento_codigo UNIQUE (codigo_descuento);
IF OBJECT_ID(N''ven.uq_politica_cabina_horas'', N''UQ'') IS NULL
    ALTER TABLE ven.politica_cancelacion ADD CONSTRAINT uq_politica_cabina_horas UNIQUE (codigo_cabina, horas_antes_min);
IF OBJECT_ID(N''ven.uq_tiquete_numero'', N''UQ'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT uq_tiquete_numero UNIQUE (numero_tiquete);';

-- E. 03_claves_y_restricciones, lote 3
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ref.ck_pais_codigo'', N''C'') IS NULL
    ALTER TABLE ref.pais ADD CONSTRAINT ck_pais_codigo CHECK (codigo_pais COLLATE Latin1_General_BIN LIKE ''[A-Z][A-Z]'');
IF OBJECT_ID(N''ref.ck_estado_eeuu_codigo'', N''C'') IS NULL
    ALTER TABLE ref.estado_eeuu ADD CONSTRAINT ck_estado_eeuu_codigo CHECK (codigo_estado COLLATE Latin1_General_BIN LIKE ''[A-Z][A-Z]'');
IF OBJECT_ID(N''ref.ck_localizacion_tipo'', N''C'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT ck_localizacion_tipo CHECK (tipo_localizacion IN (''AER'', ''OFI'', ''WEB''));
IF OBJECT_ID(N''ref.ck_localizacion_datos_tipo'', N''C'') IS NULL  
    ALTER TABLE ref.localizacion ADD CONSTRAINT ck_localizacion_datos_tipo CHECK (
        (tipo_localizacion IN (''AER'', ''OFI'') AND ciudad IS NOT NULL AND codigo_estado IS NOT NULL
             AND zona_horaria IS NOT NULL AND url IS NULL)
     OR (tipo_localizacion = ''WEB'' AND url IS NOT NULL AND ciudad IS NULL AND codigo_estado IS NULL
             AND direccion IS NULL AND codigo_postal IS NULL AND zona_horaria IS NULL));
IF OBJECT_ID(N''ref.ck_localizacion_url'', N''C'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT ck_localizacion_url CHECK (url IS NULL OR url LIKE ''https://_%'');
IF OBJECT_ID(N''ref.ck_localizacion_codigo_postal'', N''C'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT ck_localizacion_codigo_postal CHECK (codigo_postal IS NULL OR codigo_postal LIKE ''[0-9][0-9][0-9][0-9][0-9]'');
IF OBJECT_ID(N''ref.ck_aeropuerto_iata'', N''C'') IS NULL
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT ck_aeropuerto_iata CHECK (codigo_iata COLLATE Latin1_General_BIN LIKE ''[A-Z][A-Z][A-Z]'');
IF OBJECT_ID(N''ref.ck_aeropuerto_icao'', N''C'') IS NULL
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT ck_aeropuerto_icao CHECK (codigo_icao COLLATE Latin1_General_BIN LIKE ''[A-Z][A-Z][A-Z][A-Z]'');
IF OBJECT_ID(N''ref.ck_aeropuerto_coordenadas'', N''C'') IS NULL
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT ck_aeropuerto_coordenadas CHECK (latitud BETWEEN -90 AND 90 AND longitud BETWEEN -180 AND 180);
IF OBJECT_ID(N''ref.ck_cabina_codigo'', N''C'') IS NULL
    ALTER TABLE ref.cabina ADD CONSTRAINT ck_cabina_codigo CHECK (codigo_cabina COLLATE Latin1_General_BIN LIKE ''[A-Z][A-Z][A-Z]'');
IF OBJECT_ID(N''ref.ck_cabina_equipaje'', N''C'') IS NULL
    ALTER TABLE ref.cabina ADD CONSTRAINT ck_cabina_equipaje CHECK (piezas_equipaje_bodega <= 5 AND peso_max_equipaje_kg BETWEEN 1 AND 50);
IF OBJECT_ID(N''ref.ck_modelo_avion_datos'', N''C'') IS NULL
    ALTER TABLE ref.modelo_avion ADD CONSTRAINT ck_modelo_avion_datos CHECK (alcance_millas > 0 AND velocidad_crucero_mph BETWEEN 200 AND 700);
IF OBJECT_ID(N''ref.ck_metodo_pago_canal'', N''C'') IS NULL
    ALTER TABLE ref.metodo_pago ADD CONSTRAINT ck_metodo_pago_canal CHECK (permite_web = 1 OR permite_fisico = 1);
IF OBJECT_ID(N''ref.ck_motivo_cancelacion_iniciador'', N''C'') IS NULL
    ALTER TABLE ref.motivo_cancelacion ADD CONSTRAINT ck_motivo_cancelacion_iniciador CHECK (iniciado_por IN (''CLIENTE'', ''AEROLINEA'', ''SISTEMA''));
IF OBJECT_ID(N''ref.ck_parametro_tipo'', N''C'') IS NULL
    ALTER TABLE ref.parametro ADD CONSTRAINT ck_parametro_tipo CHECK (tipo_dato IN (''INT'', ''DECIMAL'', ''DATE'', ''DATETIME'', ''TEXT''));
IF OBJECT_ID(N''ref.ck_mensaje_error_numero'', N''C'') IS NULL
    ALTER TABLE ref.mensaje_error ADD CONSTRAINT ck_mensaje_error_numero CHECK (numero_error BETWEEN 50000 AND 50999);

IF OBJECT_ID(N''rh.ck_cargo_categoria'', N''C'') IS NULL
    ALTER TABLE rh.cargo ADD CONSTRAINT ck_cargo_categoria CHECK (categoria_tripulacion IS NULL OR categoria_tripulacion IN (''TECNICA'', ''CABINA''));
IF OBJECT_ID(N''rh.ck_empleado_numero'', N''C'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_numero CHECK (numero_empleado COLLATE Latin1_General_BIN LIKE ''E[0-9][0-9][0-9][0-9][0-9]'');
IF OBJECT_ID(N''rh.ck_empleado_email'', N''C'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_email CHECK (email_corporativo LIKE ''%_@_%._%'');
IF OBJECT_ID(N''rh.ck_empleado_mayor_edad'', N''C'') IS NULL                           
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_mayor_edad CHECK (DATEADD(YEAR, 18, fecha_nacimiento) <= fecha_contratacion);
IF OBJECT_ID(N''rh.ck_empleado_terminacion'', N''C'') IS NULL                          
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_terminacion CHECK (fecha_terminacion IS NULL OR fecha_terminacion >= fecha_contratacion);
IF OBJECT_ID(N''rh.ck_empleado_salario'', N''C'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_salario CHECK (salario_anual_usd > 0);
IF OBJECT_ID(N''rh.ck_empleado_supervisor'', N''C'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT ck_empleado_supervisor CHECK (id_supervisor IS NULL OR id_supervisor <> id_empleado);

IF OBJECT_ID(N''ops.ck_asiento_codigo'', N''C'') IS NULL
    ALTER TABLE ops.asiento_configuracion ADD CONSTRAINT ck_asiento_codigo CHECK (codigo_asiento = CONCAT(fila, letra));
IF OBJECT_ID(N''ops.ck_asiento_fila_letra'', N''C'') IS NULL
    ALTER TABLE ops.asiento_configuracion ADD CONSTRAINT ck_asiento_fila_letra CHECK (fila BETWEEN 1 AND 60 AND letra COLLATE Latin1_General_BIN LIKE ''[A-K]'');
IF OBJECT_ID(N''ops.ck_avion_matricula'', N''C'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT ck_avion_matricula CHECK (matricula COLLATE Latin1_General_BIN LIKE ''N[1-9]%'' AND LEN(matricula) BETWEEN 3 AND 6);
IF OBJECT_ID(N''ops.ck_avion_estado'', N''C'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT ck_avion_estado CHECK (estado_operativo IN (''ACTIVO'', ''MANTENIMIENTO'', ''RETIRADO''));
IF OBJECT_ID(N''ops.ck_avion_fechas'', N''C'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT ck_avion_fechas CHECK (fecha_incorporacion >= fecha_fabricacion);
IF OBJECT_ID(N''ops.ck_ruta_origen_destino'', N''C'') IS NULL                          
    ALTER TABLE ops.ruta ADD CONSTRAINT ck_ruta_origen_destino CHECK (id_aeropuerto_origen <> id_aeropuerto_destino);
IF OBJECT_ID(N''ops.ck_ruta_distancia'', N''C'') IS NULL
    ALTER TABLE ops.ruta ADD CONSTRAINT ck_ruta_distancia CHECK (distancia_millas BETWEEN 50 AND 6000);
IF OBJECT_ID(N''ops.ck_programacion_numero'', N''C'') IS NULL
    ALTER TABLE ops.programacion ADD CONSTRAINT ck_programacion_numero CHECK (numero_vuelo BETWEEN 1 AND 9999);
IF OBJECT_ID(N''ops.ck_programacion_duracion'', N''C'') IS NULL
    ALTER TABLE ops.programacion ADD CONSTRAINT ck_programacion_duracion CHECK (duracion_programada_min BETWEEN 20 AND 1080);
IF OBJECT_ID(N''ops.ck_programacion_vigencia'', N''C'') IS NULL
    ALTER TABLE ops.programacion ADD CONSTRAINT ck_programacion_vigencia CHECK (vigente_hasta IS NULL OR vigente_hasta >= vigente_desde);
IF OBJECT_ID(N''ops.ck_programacion_dia_semana'', N''C'') IS NULL                      
    ALTER TABLE ops.programacion_dia ADD CONSTRAINT ck_programacion_dia_semana CHECK (dia_semana BETWEEN 1 AND 7);
IF OBJECT_ID(N''ops.ck_vuelo_horario'', N''C'') IS NULL                                
    ALTER TABLE ops.vuelo ADD CONSTRAINT ck_vuelo_horario CHECK (
        llegada_programada > salida_programada
        AND DATEDIFF(MINUTE, salida_programada, llegada_programada) BETWEEN 20 AND 1080);
IF OBJECT_ID(N''ops.ck_vuelo_estado_horas'', N''C'') IS NULL                           
    ALTER TABLE ops.vuelo ADD CONSTRAINT ck_vuelo_estado_horas CHECK (
        (codigo_estado = ''PROGRAMADO'' AND salida_estimada IS NULL AND salida_real IS NULL AND llegada_real IS NULL AND motivo_cancelacion IS NULL)
     OR (codigo_estado = ''DEMORADO''   AND salida_estimada > salida_programada AND salida_real IS NULL AND llegada_real IS NULL AND motivo_cancelacion IS NULL)
     OR (codigo_estado = ''EN_VUELO''   AND salida_real IS NOT NULL AND llegada_real IS NULL AND motivo_cancelacion IS NULL)
     OR (codigo_estado = ''ATERRIZADO'' AND salida_real IS NOT NULL AND llegada_real > salida_real AND motivo_cancelacion IS NULL)
     OR (codigo_estado = ''CANCELADO''  AND salida_real IS NULL AND llegada_real IS NULL AND motivo_cancelacion IS NOT NULL));
IF OBJECT_ID(N''ops.ck_vuelo_salida_real'', N''C'') IS NULL   
    ALTER TABLE ops.vuelo ADD CONSTRAINT ck_vuelo_salida_real CHECK (
        salida_real IS NULL
        OR (salida_real >= DATEADD(MINUTE, -30, salida_programada) AND salida_real <= DATEADD(HOUR, 24, salida_programada)));
IF OBJECT_ID(N''ops.ck_vuelo_cabina_capacidad'', N''C'') IS NULL                       
    ALTER TABLE ops.vuelo_cabina ADD CONSTRAINT ck_vuelo_cabina_capacidad CHECK (capacidad > 0 AND plazas_ocupadas >= 0 AND plazas_ocupadas <= capacidad);
IF OBJECT_ID(N''ops.ck_asignacion_rol'', N''C'') IS NULL
    ALTER TABLE ops.asignacion_tripulacion ADD CONSTRAINT ck_asignacion_rol CHECK (rol_vuelo IN (''CAPITAN'', ''PRIMER_OFICIAL'', ''JEFE_CABINA'', ''AUXILIAR_VUELO''));

IF OBJECT_ID(N''ven.ck_persona_genero'', N''C'') IS NULL
    ALTER TABLE ven.persona ADD CONSTRAINT ck_persona_genero CHECK (genero IS NULL OR genero IN (''F'', ''M'', ''X''));
IF OBJECT_ID(N''ven.ck_persona_email'', N''C'') IS NULL
    ALTER TABLE ven.persona ADD CONSTRAINT ck_persona_email CHECK (email_contacto IS NULL OR email_contacto LIKE ''%_@_%._%'');
IF OBJECT_ID(N''ven.ck_persona_documento'', N''C'') IS NULL   
    ALTER TABLE ven.persona ADD CONSTRAINT ck_persona_documento CHECK (
        (tipo_documento IS NULL AND numero_documento IS NULL AND codigo_pais_documento IS NULL)
     OR (tipo_documento IN (''PASAPORTE'', ''LICENCIA'', ''ID_ESTATAL'') AND numero_documento IS NOT NULL AND codigo_pais_documento IS NOT NULL));
IF OBJECT_ID(N''ven.ck_persona_fecha_nacimiento'', N''C'') IS NULL
    ALTER TABLE ven.persona ADD CONSTRAINT ck_persona_fecha_nacimiento CHECK (
        fecha_nacimiento IS NULL OR (fecha_nacimiento >= ''19000101'' AND fecha_nacimiento <= CAST(creado_utc AS DATE)));
IF OBJECT_ID(N''ven.ck_cliente_nivel'', N''C'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT ck_cliente_nivel CHECK (nivel_lealtad IN (''BASICO'', ''PLATA'', ''ORO'', ''PLATINO''));
IF OBJECT_ID(N''ven.ck_cliente_estado'', N''C'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT ck_cliente_estado CHECK (estado_cuenta IN (''ACTIVA'', ''SUSPENDIDA'', ''CERRADA''));
IF OBJECT_ID(N''ven.ck_cliente_numero_viajero'', N''C'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT ck_cliente_numero_viajero CHECK (numero_viajero COLLATE Latin1_General_BIN LIKE ''VF[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'');
IF OBJECT_ID(N''ven.ck_cliente_email'', N''C'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT ck_cliente_email CHECK (email_acceso LIKE ''%_@_%._%'');
IF OBJECT_ID(N''ven.ck_compra_codigo_reserva'', N''C'') IS NULL
    ALTER TABLE ven.compra ADD CONSTRAINT ck_compra_codigo_reserva CHECK (
        LEN(codigo_reserva) = 6 AND codigo_reserva COLLATE Latin1_General_BIN NOT LIKE ''%[^A-Z0-9]%'');
IF OBJECT_ID(N''ven.ck_tarifa_precio'', N''C'') IS NULL
    ALTER TABLE ven.tarifa ADD CONSTRAINT ck_tarifa_precio CHECK (precio_base_usd > 0);
IF OBJECT_ID(N''ven.ck_tarifa_vigencia'', N''C'') IS NULL
    ALTER TABLE ven.tarifa ADD CONSTRAINT ck_tarifa_vigencia CHECK (vigente_hasta IS NULL OR vigente_hasta >= vigente_desde);
IF OBJECT_ID(N''ven.ck_descuento_porcentaje'', N''C'') IS NULL
    ALTER TABLE ven.descuento ADD CONSTRAINT ck_descuento_porcentaje CHECK (porcentaje > 0 AND porcentaje <= 100);
IF OBJECT_ID(N''ven.ck_descuento_vigencia'', N''C'') IS NULL
    ALTER TABLE ven.descuento ADD CONSTRAINT ck_descuento_vigencia CHECK (vigente_hasta >= vigente_desde);
IF OBJECT_ID(N''ven.ck_descuento_anticipacion'', N''C'') IS NULL
    ALTER TABLE ven.descuento ADD CONSTRAINT ck_descuento_anticipacion CHECK (dias_anticipacion_min IS NULL OR dias_anticipacion_min BETWEEN 0 AND 365);
IF OBJECT_ID(N''ven.ck_politica_valores'', N''C'') IS NULL
    ALTER TABLE ven.politica_cancelacion ADD CONSTRAINT ck_politica_valores CHECK (horas_antes_min >= 0 AND porcentaje_reembolso BETWEEN 0 AND 100);
IF OBJECT_ID(N''ven.ck_tiquete_numero'', N''C'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_numero CHECK (LEN(numero_tiquete) = 13 AND numero_tiquete NOT LIKE ''%[^0-9]%'');
IF OBJECT_ID(N''ven.ck_tiquete_precio'', N''C'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_precio CHECK (precio_base_usd > 0);
IF OBJECT_ID(N''ven.ck_tiquete_descuento'', N''C'') IS NULL                            
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_descuento CHECK (
        (id_descuento IS NULL AND porcentaje_descuento = 0)
     OR (id_descuento IS NOT NULL AND porcentaje_descuento > 0 AND porcentaje_descuento <= 100));
IF OBJECT_ID(N''ven.ck_tiquete_cancelacion'', N''C'') IS NULL                          
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_cancelacion CHECK (
        (codigo_estado = ''CANCELADO'' AND fecha_cancelacion_utc IS NOT NULL AND codigo_motivo_cancelacion IS NOT NULL)
     OR (codigo_estado <> ''CANCELADO'' AND fecha_cancelacion_utc IS NULL AND codigo_motivo_cancelacion IS NULL));
IF OBJECT_ID(N''ven.ck_tiquete_emision'', N''C'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_emision CHECK (
        (codigo_estado IN (''EMITIDO'', ''USADO'', ''NO_PRESENTADO'') AND fecha_emision_utc IS NOT NULL)
     OR (codigo_estado = ''RESERVADO'' AND fecha_emision_utc IS NULL)
     OR  codigo_estado = ''CANCELADO'');
IF OBJECT_ID(N''ven.ck_tiquete_fechas'', N''C'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT ck_tiquete_fechas CHECK (
        fecha_limite_pago_utc > creado_utc
        AND (fecha_emision_utc IS NULL OR fecha_emision_utc >= creado_utc)
        AND (fecha_cancelacion_utc IS NULL OR fecha_cancelacion_utc >= creado_utc));
IF OBJECT_ID(N''ven.ck_pago_monto'', N''C'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_monto CHECK (monto_usd > 0);
IF OBJECT_ID(N''ven.ck_pago_tarjeta'', N''C'') IS NULL                                 
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_tarjeta CHECK (
        (codigo_metodo IN (''TC'', ''TD'') AND ultimos4_tarjeta IS NOT NULL AND marca_tarjeta IS NOT NULL)
     OR (codigo_metodo NOT IN (''TC'', ''TD'') AND ultimos4_tarjeta IS NULL AND marca_tarjeta IS NULL));
IF OBJECT_ID(N''ven.ck_pago_ultimos4'', N''C'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_ultimos4 CHECK (ultimos4_tarjeta IS NULL OR ultimos4_tarjeta LIKE ''[0-9][0-9][0-9][0-9]'');
IF OBJECT_ID(N''ven.ck_pago_marca'', N''C'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_marca CHECK (marca_tarjeta IS NULL OR marca_tarjeta IN (''VISA'', ''MASTERCARD'', ''AMEX'', ''DISCOVER''));
IF OBJECT_ID(N''ven.ck_pago_estado_datos'', N''C'') IS NULL                            
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_estado_datos CHECK (
        (codigo_estado = ''PENDIENTE''  AND fecha_resolucion_utc IS NULL AND motivo_rechazo IS NULL)
     OR (codigo_estado = ''CONFIRMADO'' AND fecha_resolucion_utc IS NOT NULL AND referencia_autorizacion IS NOT NULL AND motivo_rechazo IS NULL)
     OR (codigo_estado = ''FALLIDO''    AND fecha_resolucion_utc IS NOT NULL AND motivo_rechazo IS NOT NULL)
     OR (codigo_estado = ''ANULADO''    AND fecha_resolucion_utc IS NOT NULL));
IF OBJECT_ID(N''ven.ck_pago_fechas'', N''C'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT ck_pago_fechas CHECK (fecha_resolucion_utc IS NULL OR fecha_resolucion_utc >= fecha_creacion_utc);
IF OBJECT_ID(N''ven.ck_reembolso_valores'', N''C'') IS NULL
    ALTER TABLE ven.reembolso ADD CONSTRAINT ck_reembolso_valores CHECK (monto_usd > 0 AND porcentaje_aplicado > 0 AND porcentaje_aplicado <= 100);
IF OBJECT_ID(N''ven.ck_reembolso_regla'', N''C'') IS NULL
    ALTER TABLE ven.reembolso ADD CONSTRAINT ck_reembolso_regla CHECK (regla_aplicada IN (''REEMBOLSO_TOTAL'', ''REGLA_24H'', ''POLITICA_CABINA''));

IF OBJECT_ID(N''aud.ck_cambio_estado_entidad'', N''C'') IS NULL
    ALTER TABLE aud.cambio_estado ADD CONSTRAINT ck_cambio_estado_entidad CHECK (entidad IN (''VUELO'', ''TIQUETE'', ''PAGO''));
IF OBJECT_ID(N''tst.ck_resultado_prueba_resultado'', N''C'') IS NULL
    ALTER TABLE tst.resultado_prueba ADD CONSTRAINT ck_resultado_prueba_resultado CHECK (resultado IN (''SUPERADA'', ''FALLIDA''));';

-- E. 03_claves_y_restricciones, lote 4
EXEC sys.sp_executesql N'IF OBJECT_ID(N''ref.fk_localizacion_estado'', N''F'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT fk_localizacion_estado FOREIGN KEY (codigo_estado) REFERENCES ref.estado_eeuu (codigo_estado);
IF OBJECT_ID(N''ref.fk_localizacion_zona_horaria'', N''F'') IS NULL
    ALTER TABLE ref.localizacion ADD CONSTRAINT fk_localizacion_zona_horaria FOREIGN KEY (zona_horaria) REFERENCES ref.zona_horaria (nombre_windows);
IF OBJECT_ID(N''ref.fk_aeropuerto_localizacion'', N''F'') IS NULL   
    ALTER TABLE ref.aeropuerto ADD CONSTRAINT fk_aeropuerto_localizacion FOREIGN KEY (id_localizacion, tipo_localizacion)
        REFERENCES ref.localizacion (id_localizacion, tipo_localizacion);
IF OBJECT_ID(N''ref.fk_transicion_vuelo_origen'', N''F'') IS NULL
    ALTER TABLE ref.transicion_vuelo ADD CONSTRAINT fk_transicion_vuelo_origen FOREIGN KEY (estado_origen) REFERENCES ref.estado_vuelo (codigo_estado);
IF OBJECT_ID(N''ref.fk_transicion_vuelo_destino'', N''F'') IS NULL
    ALTER TABLE ref.transicion_vuelo ADD CONSTRAINT fk_transicion_vuelo_destino FOREIGN KEY (estado_destino) REFERENCES ref.estado_vuelo (codigo_estado);
IF OBJECT_ID(N''ref.fk_transicion_tiquete_origen'', N''F'') IS NULL
    ALTER TABLE ref.transicion_tiquete ADD CONSTRAINT fk_transicion_tiquete_origen FOREIGN KEY (estado_origen) REFERENCES ref.estado_tiquete (codigo_estado);
IF OBJECT_ID(N''ref.fk_transicion_tiquete_destino'', N''F'') IS NULL
    ALTER TABLE ref.transicion_tiquete ADD CONSTRAINT fk_transicion_tiquete_destino FOREIGN KEY (estado_destino) REFERENCES ref.estado_tiquete (codigo_estado);
IF OBJECT_ID(N''ref.fk_transicion_pago_origen'', N''F'') IS NULL
    ALTER TABLE ref.transicion_pago ADD CONSTRAINT fk_transicion_pago_origen FOREIGN KEY (estado_origen) REFERENCES ref.estado_pago (codigo_estado);
IF OBJECT_ID(N''ref.fk_transicion_pago_destino'', N''F'') IS NULL
    ALTER TABLE ref.transicion_pago ADD CONSTRAINT fk_transicion_pago_destino FOREIGN KEY (estado_destino) REFERENCES ref.estado_pago (codigo_estado);

IF OBJECT_ID(N''rh.fk_cargo_departamento'', N''F'') IS NULL
    ALTER TABLE rh.cargo ADD CONSTRAINT fk_cargo_departamento FOREIGN KEY (codigo_departamento) REFERENCES rh.departamento (codigo_departamento);
IF OBJECT_ID(N''rh.fk_empleado_cargo'', N''F'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT fk_empleado_cargo FOREIGN KEY (codigo_cargo) REFERENCES rh.cargo (codigo_cargo);
IF OBJECT_ID(N''rh.fk_empleado_localizacion'', N''F'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT fk_empleado_localizacion FOREIGN KEY (id_localizacion_base) REFERENCES ref.localizacion (id_localizacion);
IF OBJECT_ID(N''rh.fk_empleado_supervisor'', N''F'') IS NULL
    ALTER TABLE rh.empleado ADD CONSTRAINT fk_empleado_supervisor FOREIGN KEY (id_supervisor) REFERENCES rh.empleado (id_empleado);

IF OBJECT_ID(N''ops.fk_configuracion_modelo'', N''F'') IS NULL
    ALTER TABLE ops.configuracion_asientos ADD CONSTRAINT fk_configuracion_modelo FOREIGN KEY (id_modelo) REFERENCES ref.modelo_avion (id_modelo);
IF OBJECT_ID(N''ops.fk_asiento_configuracion'', N''F'') IS NULL
    ALTER TABLE ops.asiento_configuracion ADD CONSTRAINT fk_asiento_configuracion FOREIGN KEY (id_configuracion) REFERENCES ops.configuracion_asientos (id_configuracion);
IF OBJECT_ID(N''ops.fk_asiento_cabina'', N''F'') IS NULL
    ALTER TABLE ops.asiento_configuracion ADD CONSTRAINT fk_asiento_cabina FOREIGN KEY (codigo_cabina) REFERENCES ref.cabina (codigo_cabina);
IF OBJECT_ID(N''ops.fk_avion_configuracion'', N''F'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT fk_avion_configuracion FOREIGN KEY (id_configuracion) REFERENCES ops.configuracion_asientos (id_configuracion);
IF OBJECT_ID(N''ops.fk_avion_aeropuerto_base'', N''F'') IS NULL
    ALTER TABLE ops.avion ADD CONSTRAINT fk_avion_aeropuerto_base FOREIGN KEY (id_aeropuerto_base) REFERENCES ref.aeropuerto (id_localizacion);
IF OBJECT_ID(N''ops.fk_ruta_origen'', N''F'') IS NULL
    ALTER TABLE ops.ruta ADD CONSTRAINT fk_ruta_origen FOREIGN KEY (id_aeropuerto_origen) REFERENCES ref.aeropuerto (id_localizacion);
IF OBJECT_ID(N''ops.fk_ruta_destino'', N''F'') IS NULL
    ALTER TABLE ops.ruta ADD CONSTRAINT fk_ruta_destino FOREIGN KEY (id_aeropuerto_destino) REFERENCES ref.aeropuerto (id_localizacion);
IF OBJECT_ID(N''ops.fk_programacion_ruta'', N''F'') IS NULL
    ALTER TABLE ops.programacion ADD CONSTRAINT fk_programacion_ruta FOREIGN KEY (id_ruta) REFERENCES ops.ruta (id_ruta);
IF OBJECT_ID(N''ops.fk_programacion_dia_programacion'', N''F'') IS NULL
    ALTER TABLE ops.programacion_dia ADD CONSTRAINT fk_programacion_dia_programacion FOREIGN KEY (id_programacion) REFERENCES ops.programacion (id_programacion);
IF OBJECT_ID(N''ops.fk_vuelo_programacion'', N''F'') IS NULL
    ALTER TABLE ops.vuelo ADD CONSTRAINT fk_vuelo_programacion FOREIGN KEY (id_programacion) REFERENCES ops.programacion (id_programacion);
IF OBJECT_ID(N''ops.fk_vuelo_avion'', N''F'') IS NULL
    ALTER TABLE ops.vuelo ADD CONSTRAINT fk_vuelo_avion FOREIGN KEY (id_avion) REFERENCES ops.avion (id_avion);
IF OBJECT_ID(N''ops.fk_vuelo_estado'', N''F'') IS NULL
    ALTER TABLE ops.vuelo ADD CONSTRAINT fk_vuelo_estado FOREIGN KEY (codigo_estado) REFERENCES ref.estado_vuelo (codigo_estado);
IF OBJECT_ID(N''ops.fk_vuelo_cabina_vuelo'', N''F'') IS NULL
    ALTER TABLE ops.vuelo_cabina ADD CONSTRAINT fk_vuelo_cabina_vuelo FOREIGN KEY (id_vuelo) REFERENCES ops.vuelo (id_vuelo);
IF OBJECT_ID(N''ops.fk_vuelo_cabina_cabina'', N''F'') IS NULL
    ALTER TABLE ops.vuelo_cabina ADD CONSTRAINT fk_vuelo_cabina_cabina FOREIGN KEY (codigo_cabina) REFERENCES ref.cabina (codigo_cabina);
IF OBJECT_ID(N''ops.fk_asignacion_vuelo'', N''F'') IS NULL
    ALTER TABLE ops.asignacion_tripulacion ADD CONSTRAINT fk_asignacion_vuelo FOREIGN KEY (id_vuelo) REFERENCES ops.vuelo (id_vuelo);
IF OBJECT_ID(N''ops.fk_asignacion_empleado'', N''F'') IS NULL
    ALTER TABLE ops.asignacion_tripulacion ADD CONSTRAINT fk_asignacion_empleado FOREIGN KEY (id_empleado) REFERENCES rh.empleado (id_empleado);

IF OBJECT_ID(N''ven.fk_persona_pais_nacionalidad'', N''F'') IS NULL
    ALTER TABLE ven.persona ADD CONSTRAINT fk_persona_pais_nacionalidad FOREIGN KEY (codigo_pais_nacionalidad) REFERENCES ref.pais (codigo_pais);
IF OBJECT_ID(N''ven.fk_persona_pais_documento'', N''F'') IS NULL
    ALTER TABLE ven.persona ADD CONSTRAINT fk_persona_pais_documento FOREIGN KEY (codigo_pais_documento) REFERENCES ref.pais (codigo_pais);
IF OBJECT_ID(N''ven.fk_cliente_persona'', N''F'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT fk_cliente_persona FOREIGN KEY (id_persona) REFERENCES ven.persona (id_persona);
IF OBJECT_ID(N''ven.fk_cliente_aeropuerto'', N''F'') IS NULL
    ALTER TABLE ven.cliente ADD CONSTRAINT fk_cliente_aeropuerto FOREIGN KEY (id_aeropuerto_preferido) REFERENCES ref.aeropuerto (id_localizacion);
IF OBJECT_ID(N''ven.fk_compra_comprador'', N''F'') IS NULL
    ALTER TABLE ven.compra ADD CONSTRAINT fk_compra_comprador FOREIGN KEY (id_persona_comprador) REFERENCES ven.persona (id_persona);
IF OBJECT_ID(N''ven.fk_compra_localizacion'', N''F'') IS NULL
    ALTER TABLE ven.compra ADD CONSTRAINT fk_compra_localizacion FOREIGN KEY (id_localizacion_venta) REFERENCES ref.localizacion (id_localizacion);
IF OBJECT_ID(N''ven.fk_compra_vendedor'', N''F'') IS NULL
    ALTER TABLE ven.compra ADD CONSTRAINT fk_compra_vendedor FOREIGN KEY (id_empleado_vendedor) REFERENCES rh.empleado (id_empleado);
IF OBJECT_ID(N''ven.fk_tarifa_ruta'', N''F'') IS NULL
    ALTER TABLE ven.tarifa ADD CONSTRAINT fk_tarifa_ruta FOREIGN KEY (id_ruta) REFERENCES ops.ruta (id_ruta);
IF OBJECT_ID(N''ven.fk_tarifa_cabina'', N''F'') IS NULL
    ALTER TABLE ven.tarifa ADD CONSTRAINT fk_tarifa_cabina FOREIGN KEY (codigo_cabina) REFERENCES ref.cabina (codigo_cabina);
IF OBJECT_ID(N''ven.fk_descuento_cabina'', N''F'') IS NULL
    ALTER TABLE ven.descuento ADD CONSTRAINT fk_descuento_cabina FOREIGN KEY (codigo_cabina) REFERENCES ref.cabina (codigo_cabina);
IF OBJECT_ID(N''ven.fk_politica_cabina'', N''F'') IS NULL
    ALTER TABLE ven.politica_cancelacion ADD CONSTRAINT fk_politica_cabina FOREIGN KEY (codigo_cabina) REFERENCES ref.cabina (codigo_cabina);
IF OBJECT_ID(N''ven.fk_tiquete_compra'', N''F'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_compra FOREIGN KEY (id_compra) REFERENCES ven.compra (id_compra);
IF OBJECT_ID(N''ven.fk_tiquete_vuelo_cabina'', N''F'') IS NULL                         
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_vuelo_cabina FOREIGN KEY (id_vuelo, codigo_cabina) REFERENCES ops.vuelo_cabina (id_vuelo, codigo_cabina);
IF OBJECT_ID(N''ven.fk_tiquete_pasajero'', N''F'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_pasajero FOREIGN KEY (id_persona_pasajero) REFERENCES ven.persona (id_persona);
IF OBJECT_ID(N''ven.fk_tiquete_tarifa_cabina'', N''F'') IS NULL                        
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_tarifa_cabina FOREIGN KEY (id_tarifa, codigo_cabina) REFERENCES ven.tarifa (id_tarifa, codigo_cabina);
IF OBJECT_ID(N''ven.fk_tiquete_descuento'', N''F'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_descuento FOREIGN KEY (id_descuento) REFERENCES ven.descuento (id_descuento);
IF OBJECT_ID(N''ven.fk_tiquete_estado'', N''F'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_estado FOREIGN KEY (codigo_estado) REFERENCES ref.estado_tiquete (codigo_estado);
IF OBJECT_ID(N''ven.fk_tiquete_motivo'', N''F'') IS NULL
    ALTER TABLE ven.tiquete ADD CONSTRAINT fk_tiquete_motivo FOREIGN KEY (codigo_motivo_cancelacion) REFERENCES ref.motivo_cancelacion (codigo_motivo);
IF OBJECT_ID(N''ven.fk_pago_tiquete'', N''F'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT fk_pago_tiquete FOREIGN KEY (id_tiquete) REFERENCES ven.tiquete (id_tiquete);
IF OBJECT_ID(N''ven.fk_pago_metodo'', N''F'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT fk_pago_metodo FOREIGN KEY (codigo_metodo) REFERENCES ref.metodo_pago (codigo_metodo);
IF OBJECT_ID(N''ven.fk_pago_localizacion'', N''F'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT fk_pago_localizacion FOREIGN KEY (id_localizacion_cobro) REFERENCES ref.localizacion (id_localizacion);
IF OBJECT_ID(N''ven.fk_pago_estado'', N''F'') IS NULL
    ALTER TABLE ven.pago ADD CONSTRAINT fk_pago_estado FOREIGN KEY (codigo_estado) REFERENCES ref.estado_pago (codigo_estado);
IF OBJECT_ID(N''ven.fk_reembolso_pago'', N''F'') IS NULL
    ALTER TABLE ven.reembolso ADD CONSTRAINT fk_reembolso_pago FOREIGN KEY (id_pago) REFERENCES ven.pago (id_pago);
IF OBJECT_ID(N''ven.fk_reembolso_motivo'', N''F'') IS NULL
    ALTER TABLE ven.reembolso ADD CONSTRAINT fk_reembolso_motivo FOREIGN KEY (codigo_motivo) REFERENCES ref.motivo_cancelacion (codigo_motivo);';

-- E. 03_claves_y_restricciones, lote 5
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_tiquete_vuelo_asiento'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_tiquete_vuelo_asiento ON ven.tiquete (id_vuelo, codigo_asiento)
        WHERE codigo_asiento IS NOT NULL AND codigo_estado IN (''RESERVADO'', ''EMITIDO'', ''USADO'', ''NO_PRESENTADO'');

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_tiquete_vuelo_pasajero'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_tiquete_vuelo_pasajero ON ven.tiquete (id_vuelo, id_persona_pasajero)
        WHERE codigo_estado IN (''RESERVADO'', ''EMITIDO'', ''USADO'', ''NO_PRESENTADO'');

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_asignacion_capitan'' AND object_id = OBJECT_ID(N''ops.asignacion_tripulacion''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_asignacion_capitan ON ops.asignacion_tripulacion (id_vuelo) WHERE rol_vuelo = ''CAPITAN'';
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_asignacion_primer_oficial'' AND object_id = OBJECT_ID(N''ops.asignacion_tripulacion''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_asignacion_primer_oficial ON ops.asignacion_tripulacion (id_vuelo) WHERE rol_vuelo = ''PRIMER_OFICIAL'';
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_asignacion_jefe_cabina'' AND object_id = OBJECT_ID(N''ops.asignacion_tripulacion''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_asignacion_jefe_cabina ON ops.asignacion_tripulacion (id_vuelo) WHERE rol_vuelo = ''JEFE_CABINA'';

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ux_localizacion_url'' AND object_id = OBJECT_ID(N''ref.localizacion''))
    CREATE UNIQUE NONCLUSTERED INDEX ux_localizacion_url ON ref.localizacion (url) WHERE url IS NOT NULL;';

-- E. 03_claves_y_restricciones, lote 6
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''03_claves_y_restricciones'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''03_claves_y_restricciones'', N''UNIQUE, CHECK, FK e índices únicos filtrados'');';

-- E. 04_indices, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 04_indices, lote 2
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_vuelo_avion_salida'' AND object_id = OBJECT_ID(N''ops.vuelo''))
    CREATE NONCLUSTERED INDEX ix_vuelo_avion_salida ON ops.vuelo (id_avion, salida_programada)
        INCLUDE (llegada_programada, codigo_estado);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_vuelo_fecha'' AND object_id = OBJECT_ID(N''ops.vuelo''))
    CREATE NONCLUSTERED INDEX ix_vuelo_fecha ON ops.vuelo (fecha_salida_local)
        INCLUDE (id_programacion, codigo_estado, id_avion);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_programacion_ruta'' AND object_id = OBJECT_ID(N''ops.programacion''))
    CREATE NONCLUSTERED INDEX ix_programacion_ruta ON ops.programacion (id_ruta);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_ruta_destino'' AND object_id = OBJECT_ID(N''ops.ruta''))
    CREATE NONCLUSTERED INDEX ix_ruta_destino ON ops.ruta (id_aeropuerto_destino);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_asignacion_empleado'' AND object_id = OBJECT_ID(N''ops.asignacion_tripulacion''))
    CREATE NONCLUSTERED INDEX ix_asignacion_empleado ON ops.asignacion_tripulacion (id_empleado) INCLUDE (rol_vuelo);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_empleado_cargo'' AND object_id = OBJECT_ID(N''rh.empleado''))
    CREATE NONCLUSTERED INDEX ix_empleado_cargo ON rh.empleado (codigo_cargo) INCLUDE (id_localizacion_base, fecha_contratacion, fecha_terminacion);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_compra_comprador'' AND object_id = OBJECT_ID(N''ven.compra''))
    CREATE NONCLUSTERED INDEX ix_compra_comprador ON ven.compra (id_persona_comprador);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_compra_fecha'' AND object_id = OBJECT_ID(N''ven.compra''))
    CREATE NONCLUSTERED INDEX ix_compra_fecha ON ven.compra (fecha_compra_utc) INCLUDE (id_localizacion_venta, id_persona_comprador);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_compra'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_compra ON ven.tiquete (id_compra);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_vuelo_cabina'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_vuelo_cabina ON ven.tiquete (id_vuelo, codigo_cabina)
        INCLUDE (codigo_estado, precio_base_usd, porcentaje_descuento, precio_final_usd);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_pasajero'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_pasajero ON ven.tiquete (id_persona_pasajero);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_tarifa'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_tarifa ON ven.tiquete (id_tarifa);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_descuento'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_descuento ON ven.tiquete (id_descuento) WHERE id_descuento IS NOT NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_tiquete_reservas_pendientes'' AND object_id = OBJECT_ID(N''ven.tiquete''))
    CREATE NONCLUSTERED INDEX ix_tiquete_reservas_pendientes ON ven.tiquete (fecha_limite_pago_utc)
        WHERE codigo_estado = ''RESERVADO'';

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_pago_tiquete'' AND object_id = OBJECT_ID(N''ven.pago''))
    CREATE NONCLUSTERED INDEX ix_pago_tiquete ON ven.pago (id_tiquete) INCLUDE (codigo_estado, monto_usd, fecha_resolucion_utc);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_pago_resolucion'' AND object_id = OBJECT_ID(N''ven.pago''))
    CREATE NONCLUSTERED INDEX ix_pago_resolucion ON ven.pago (fecha_resolucion_utc) INCLUDE (codigo_estado, monto_usd, codigo_metodo);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_reembolso_pago'' AND object_id = OBJECT_ID(N''ven.reembolso''))
    CREATE NONCLUSTERED INDEX ix_reembolso_pago ON ven.reembolso (id_pago) INCLUDE (monto_usd);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_reembolso_fecha'' AND object_id = OBJECT_ID(N''ven.reembolso''))
    CREATE NONCLUSTERED INDEX ix_reembolso_fecha ON ven.reembolso (fecha_reembolso_utc) INCLUDE (monto_usd, codigo_motivo);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_persona_documento'' AND object_id = OBJECT_ID(N''ven.persona''))
    CREATE NONCLUSTERED INDEX ix_persona_documento ON ven.persona (numero_documento) WHERE numero_documento IS NOT NULL;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_persona_apellidos'' AND object_id = OBJECT_ID(N''ven.persona''))
    CREATE NONCLUSTERED INDEX ix_persona_apellidos ON ven.persona (apellidos, nombres);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_cambio_estado_entidad'' AND object_id = OBJECT_ID(N''aud.cambio_estado''))
    CREATE NONCLUSTERED INDEX ix_cambio_estado_entidad ON aud.cambio_estado (entidad, id_entidad);';

-- E. 04_indices, lote 3
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''04_indices'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''04_indices'', N''Índices de rendimiento'');';

-- E. 05_funciones_y_triggers, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 05_funciones_y_triggers, lote 2
EXEC sys.sp_executesql N'CREATE OR ALTER FUNCTION ref.fn_calendario (@desde DATE, @hasta DATE)
RETURNS TABLE
AS
RETURN
WITH d0 (n) AS (SELECT 0 FROM (VALUES (0),(0),(0),(0),(0),(0),(0),(0),(0),(0)) AS v (n)),
     d1 (n) AS (SELECT 0 FROM d0 AS a CROSS JOIN d0 AS b),          
     d2 (n) AS (SELECT 0 FROM d1 AS a CROSS JOIN d1 AS b),          
     num (i) AS (
        SELECT TOP (CASE WHEN @hasta >= @desde THEN DATEDIFF(DAY, @desde, @hasta) + 1 ELSE 0 END)
               ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1
        FROM d2)
SELECT DATEADD(DAY, i, @desde) AS fecha,
       CAST(DATEDIFF(DAY, CAST(''19000101'' AS DATE), DATEADD(DAY, i, @desde)) % 7 + 1 AS TINYINT) AS dia_semana_iso
FROM num;';

-- E. 05_funciones_y_triggers, lote 3
EXEC sys.sp_executesql N'CREATE OR ALTER FUNCTION ven.fn_politica_reembolso (
    @id_tiquete INT, @codigo_motivo VARCHAR(15), @fecha_cancelacion_utc DATETIME2(0))
RETURNS TABLE
AS
RETURN
WITH base AS (
    SELECT t.id_tiquete, t.codigo_cabina, t.creado_utc AS fecha_venta_utc,
           CONVERT(DATETIME2(0), SWITCHOFFSET(v.salida_programada, ''+00:00'')) AS salida_utc
    FROM ven.tiquete AS t
    JOIN ops.vuelo   AS v ON v.id_vuelo = t.id_vuelo
    WHERE t.id_tiquete = @id_tiquete
),
opciones AS (
    SELECT 1 AS prioridad, CAST(100.00 AS DECIMAL(5,2)) AS porcentaje, CAST(''REEMBOLSO_TOTAL'' AS VARCHAR(20)) AS regla
    FROM ref.motivo_cancelacion AS m
    WHERE m.codigo_motivo = @codigo_motivo AND m.reembolso_total = 1
    UNION ALL
    SELECT 2, CAST(100.00 AS DECIMAL(5,2)), CAST(''REGLA_24H'' AS VARCHAR(20))
    FROM base AS b
    WHERE @codigo_motivo = ''VOLUNTARIA''
      AND @fecha_cancelacion_utc <= DATEADD(HOUR, 24, b.fecha_venta_utc)
      AND DATEDIFF(MINUTE, b.fecha_venta_utc, b.salida_utc) >= 7 * 24 * 60
    UNION ALL
    SELECT 3, p.porcentaje_reembolso, CAST(''POLITICA_CABINA'' AS VARCHAR(20))
    FROM base AS b
    CROSS APPLY (
        SELECT TOP (1) pc.porcentaje_reembolso
        FROM ven.politica_cancelacion AS pc
        WHERE pc.codigo_cabina = b.codigo_cabina
          AND pc.horas_antes_min * 60 <= DATEDIFF(MINUTE, @fecha_cancelacion_utc, b.salida_utc)
        ORDER BY pc.horas_antes_min DESC) AS p
)
SELECT TOP (1)
       o.porcentaje AS porcentaje_reembolso,
       o.regla      AS regla_aplicada,
       (SELECT CAST(DATEDIFF(MINUTE, @fecha_cancelacion_utc, b.salida_utc) / 60.0 AS DECIMAL(9,2)) FROM base AS b) AS horas_antes_salida
FROM opciones AS o
ORDER BY o.prioridad;';

-- E. 05_funciones_y_triggers, lote 4
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ops.trg_programacion_reglas ON ops.programacion
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048);

    SELECT TOP (1) @msg = CONCAT(N''RN-03: el vuelo '', i.numero_vuelo, N'' ya tiene la programación '', p.id_programacion,
                                 N'' con una vigencia que se solapa.'')
    FROM inserted AS i
    JOIN ops.programacion AS p WITH (UPDLOCK, HOLDLOCK)
      ON p.numero_vuelo = i.numero_vuelo AND p.id_programacion <> i.id_programacion
    WHERE p.vigente_desde <= ISNULL(i.vigente_hasta, ''99991231'')
      AND i.vigente_desde <= ISNULL(p.vigente_hasta, ''99991231'')
      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50001, @msg, 1;
END;';

-- E. 05_funciones_y_triggers, lote 5
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ops.trg_vuelo_reglas ON ops.vuelo
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048), @bloqueados INT;
    DECLARE @es_insercion BIT = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN 0 ELSE 1 END;
    DECLARE @rotacion INT = ISNULL((SELECT CAST(valor AS INT) FROM ref.parametro WHERE clave = ''MIN_ROTACION_AVION''), 40);
    DECLARE @asientos_por_tcp DECIMAL(5,1) = ISNULL((SELECT CAST(valor AS INT) FROM ref.parametro WHERE clave = ''ASIENTOS_POR_TRIPULANTE_CABINA''), 50);

    IF @es_insercion = 0
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''La programación de origen del vuelo '', i.id_vuelo, N'' no puede cambiar.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
        WHERE i.id_programacion <> d.id_programacion
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50024, @msg, 1;
    END;

    IF @es_insercion = 1
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-08: un vuelo nuevo no puede crearse en estado '', i.codigo_estado, N''.'')
        FROM inserted AS i JOIN ref.estado_vuelo AS e ON e.codigo_estado = i.codigo_estado
        WHERE e.es_estado_inicial = 0
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50021, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''El vuelo de la fecha '', CONVERT(CHAR(10), i.fecha_salida_local, 23),
                                     N'' no corresponde a los días ni a la vigencia de la programación '', i.id_programacion, N''.'')
        FROM inserted AS i
        JOIN ops.programacion AS p ON p.id_programacion = i.id_programacion
        WHERE p.activa = 0
           OR i.fecha_salida_local < p.vigente_desde
           OR i.fecha_salida_local > ISNULL(p.vigente_hasta, ''99991231'')
           OR NOT EXISTS (SELECT 1 FROM ops.programacion_dia AS pd
                          WHERE pd.id_programacion = p.id_programacion
                            AND pd.dia_semana = DATEDIFF(DAY, CAST(''19000101'' AS DATE), i.fecha_salida_local) % 7 + 1)
                            OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50022, @msg, 1;
    END
    ELSE
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-08: transición de vuelo no válida (vuelo '', i.id_vuelo, N''): '',
                                     d.codigo_estado, N'' -> '', i.codigo_estado, N''.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
        WHERE i.codigo_estado <> d.codigo_estado
          AND NOT EXISTS (SELECT 1 FROM ref.transicion_vuelo AS t
                          WHERE t.estado_origen = d.codigo_estado AND t.estado_destino = i.codigo_estado)
                          OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50023, @msg, 1;
    END;

    SELECT TOP (1) @msg = CONCAT(N''RN-06: el vuelo '', i.id_vuelo, N'' tiene un desfase horario distinto al de la zona del aeropuerto.'')
    FROM inserted AS i
    JOIN ops.programacion AS p  ON p.id_programacion = i.id_programacion
    JOIN ops.ruta         AS r  ON r.id_ruta = p.id_ruta
    JOIN ref.localizacion AS lo ON lo.id_localizacion = r.id_aeropuerto_origen
    JOIN ref.localizacion AS ld ON ld.id_localizacion = r.id_aeropuerto_destino
    WHERE DATEPART(TZOFFSET, i.salida_programada)  <> DATEPART(TZOFFSET, i.salida_programada  AT TIME ZONE lo.zona_horaria)
       OR DATEPART(TZOFFSET, i.llegada_programada) <> DATEPART(TZOFFSET, i.llegada_programada AT TIME ZONE ld.zona_horaria)
       OR (i.salida_estimada IS NOT NULL AND DATEPART(TZOFFSET, i.salida_estimada) <> DATEPART(TZOFFSET, i.salida_estimada AT TIME ZONE lo.zona_horaria))
       OR (i.salida_real     IS NOT NULL AND DATEPART(TZOFFSET, i.salida_real)     <> DATEPART(TZOFFSET, i.salida_real     AT TIME ZONE lo.zona_horaria))
       OR (i.llegada_real    IS NOT NULL AND DATEPART(TZOFFSET, i.llegada_real)    <> DATEPART(TZOFFSET, i.llegada_real    AT TIME ZONE ld.zona_horaria))
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50026, @msg, 1;

    DECLARE @cambio_avion TABLE (id_vuelo INT PRIMARY KEY);
    INSERT @cambio_avion (id_vuelo)
    SELECT i.id_vuelo
    FROM inserted AS i LEFT JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
    WHERE i.id_avion IS NOT NULL
      AND (d.id_vuelo IS NULL
           OR ISNULL(d.id_avion, -1) <> i.id_avion
           OR d.salida_programada <> i.salida_programada
           OR d.llegada_programada <> i.llegada_programada
           OR (d.codigo_estado = ''CANCELADO'' AND i.codigo_estado <> ''CANCELADO''))
           OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));

    IF EXISTS (SELECT 1 FROM @cambio_avion)
    BEGIN

        SELECT TOP (1) @msg = CONCAT(N''RN-10: el avión '', a.matricula, N'' está en estado '', a.estado_operativo, N'' y no puede asignarse.'')
        FROM inserted AS i
        JOIN @cambio_avion AS c ON c.id_vuelo = i.id_vuelo
        JOIN ops.avion AS a ON a.id_avion = i.id_avion
        LEFT JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
        WHERE a.estado_operativo <> ''ACTIVO'' AND ISNULL(d.id_avion, -1) <> i.id_avion
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50027, @msg, 1;

        SELECT @bloqueados = COUNT(*) FROM ops.avion WITH (UPDLOCK, ROWLOCK)
        WHERE id_avion IN (SELECT i.id_avion FROM inserted AS i JOIN @cambio_avion AS c ON c.id_vuelo = i.id_vuelo)
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        WITH agenda AS (
            SELECT v.id_avion, v.id_vuelo, v.salida_programada,
                   LAG(v.llegada_programada) OVER (PARTITION BY v.id_avion ORDER BY v.salida_programada, v.id_vuelo) AS llegada_anterior,
                   LAG(v.id_vuelo)           OVER (PARTITION BY v.id_avion ORDER BY v.salida_programada, v.id_vuelo) AS vuelo_anterior
            FROM ops.vuelo AS v
            WHERE v.codigo_estado <> ''CANCELADO''
              AND v.id_avion IN (SELECT i.id_avion FROM inserted AS i JOIN @cambio_avion AS c ON c.id_vuelo = i.id_vuelo)
        )
        SELECT TOP (1) @msg = CONCAT(N''RN-09: el avión '', a.matricula, N'' ya está asignado al vuelo '', g.vuelo_anterior,
                                     N'', que se solapa con el vuelo '', g.id_vuelo, N'' (rotación mínima '', @rotacion, N'' min).'')
        FROM agenda AS g
        JOIN ops.avion AS a ON a.id_avion = g.id_avion
        WHERE g.salida_programada < DATEADD(MINUTE, @rotacion, g.llegada_anterior)
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50028, @msg, 1;
    END;

    IF @es_insercion = 0
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''SUP-03: el vuelo '', i.id_vuelo, N'' tiene tiquetes activos; el nuevo avión debe tener la misma configuración de asientos.'')
        FROM inserted AS i
        JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
        JOIN ops.avion AS anterior ON anterior.id_avion = d.id_avion
        LEFT JOIN ops.avion AS nuevo ON nuevo.id_avion = i.id_avion
        WHERE ISNULL(i.id_avion, -1) <> d.id_avion
          AND (nuevo.id_avion IS NULL OR nuevo.id_configuracion <> anterior.id_configuracion)
          AND EXISTS (SELECT 1 FROM ven.tiquete AS t WHERE t.id_vuelo = i.id_vuelo AND t.codigo_estado <> ''CANCELADO'')
          OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50025, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-35: el vuelo '', i.id_vuelo, N'' no tiene tripulación completa (capitán '', ISNULL(tr.capitanes, 0),
                                     N'', primer oficial '', ISNULL(tr.primeros_oficiales, 0), N'', cabina '', ISNULL(tr.cabina, 0),
                                     N'' de '', CEILING(ISNULL(cap.asientos, 0) / @asientos_por_tcp), N'' requeridos).'')
        FROM inserted AS i
        JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
        OUTER APPLY (SELECT SUM(CASE WHEN a.rol_vuelo = ''CAPITAN'' THEN 1 ELSE 0 END) AS capitanes,
                            SUM(CASE WHEN a.rol_vuelo = ''PRIMER_OFICIAL'' THEN 1 ELSE 0 END) AS primeros_oficiales,
                            SUM(CASE WHEN a.rol_vuelo IN (''JEFE_CABINA'', ''AUXILIAR_VUELO'') THEN 1 ELSE 0 END) AS cabina
                     FROM ops.asignacion_tripulacion AS a WHERE a.id_vuelo = i.id_vuelo) AS tr
        OUTER APPLY (SELECT SUM(vc.capacidad) AS asientos FROM ops.vuelo_cabina AS vc WHERE vc.id_vuelo = i.id_vuelo) AS cap
        WHERE i.codigo_estado = ''EN_VUELO'' AND d.codigo_estado <> ''EN_VUELO''
          AND (i.id_avion IS NULL
               OR ISNULL(tr.capitanes, 0) <> 1
               OR ISNULL(tr.primeros_oficiales, 0) <> 1
               OR ISNULL(tr.cabina, 0) < CEILING(ISNULL(cap.asientos, 0) / @asientos_por_tcp))
               OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50029, @msg, 1;
    END;

    INSERT aud.cambio_estado (entidad, id_entidad, estado_anterior, estado_nuevo)
    SELECT ''VUELO'', i.id_vuelo, d.codigo_estado, i.codigo_estado
    FROM inserted AS i LEFT JOIN deleted AS d ON d.id_vuelo = i.id_vuelo
    WHERE d.id_vuelo IS NULL OR d.codigo_estado <> i.codigo_estado
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
END;';

-- E. 05_funciones_y_triggers, lote 6
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ops.trg_asignacion_tripulacion_reglas ON ops.asignacion_tripulacion
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048), @bloqueados INT;
    DECLARE @descanso INT = ISNULL((SELECT CAST(valor AS INT) FROM ref.parametro WHERE clave = ''MIN_DESCANSO_TRIPULACION''), 30);

    SELECT TOP (1) @msg = CONCAT(N''RN-33: el empleado '', e.numero_empleado, N'' (cargo '', e.codigo_cargo,
                                 N'') no puede desempeñar el rol '', i.rol_vuelo, N''.'')
    FROM inserted AS i
    JOIN rh.empleado AS e ON e.id_empleado = i.id_empleado
    JOIN rh.cargo    AS c ON c.codigo_cargo = e.codigo_cargo

    WHERE NOT ((i.rol_vuelo IN (''CAPITAN'', ''PRIMER_OFICIAL'') AND ISNULL(c.categoria_tripulacion, '''') = ''TECNICA'')
            OR (i.rol_vuelo IN (''JEFE_CABINA'', ''AUXILIAR_VUELO'') AND ISNULL(c.categoria_tripulacion, '''') = ''CABINA''))
            OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50031, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-33: el empleado '', e.numero_empleado, N'' no está vigente el '',
                                 CONVERT(CHAR(10), v.fecha_salida_local, 23), N''.'')
    FROM inserted AS i
    JOIN rh.empleado AS e ON e.id_empleado = i.id_empleado
    JOIN ops.vuelo   AS v ON v.id_vuelo = i.id_vuelo
    WHERE e.fecha_contratacion > v.fecha_salida_local
       OR (e.fecha_terminacion IS NOT NULL AND e.fecha_terminacion < v.fecha_salida_local)
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50032, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-33: el vuelo '', v.id_vuelo, N'' está en estado '', v.codigo_estado, N'' y no admite cambios de tripulación.'')
    FROM inserted AS i JOIN ops.vuelo AS v ON v.id_vuelo = i.id_vuelo
    WHERE v.codigo_estado NOT IN (''PROGRAMADO'', ''DEMORADO'')
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50033, @msg, 1;

    SELECT @bloqueados = COUNT(*) FROM rh.empleado WITH (UPDLOCK, ROWLOCK)
    WHERE id_empleado IN (SELECT id_empleado FROM inserted)
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    WITH agenda AS (
        SELECT a.id_empleado, v.id_vuelo, v.salida_programada,
               LAG(v.llegada_programada) OVER (PARTITION BY a.id_empleado ORDER BY v.salida_programada, v.id_vuelo) AS llegada_anterior,
               LAG(v.id_vuelo)           OVER (PARTITION BY a.id_empleado ORDER BY v.salida_programada, v.id_vuelo) AS vuelo_anterior
        FROM ops.asignacion_tripulacion AS a
        JOIN ops.vuelo AS v ON v.id_vuelo = a.id_vuelo AND v.codigo_estado <> ''CANCELADO''
        WHERE a.id_empleado IN (SELECT id_empleado FROM inserted)
    )
    SELECT TOP (1) @msg = CONCAT(N''RN-33: el empleado '', e.numero_empleado, N'' ya está asignado al vuelo '', g.vuelo_anterior,
                                 N'', que se solapa con el vuelo '', g.id_vuelo, N'' (descanso mínimo '', @descanso, N'' min).'')
    FROM agenda AS g
    JOIN rh.empleado AS e ON e.id_empleado = g.id_empleado
    WHERE g.salida_programada < DATEADD(MINUTE, @descanso, g.llegada_anterior)
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50034, @msg, 1;
END;';

-- E. 05_funciones_y_triggers, lote 7
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_tarifa_reglas ON ven.tarifa
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048);

    SELECT TOP (1) @msg = CONCAT(N''RN-18: la tarifa '', i.id_tarifa, N'' se solapa con la tarifa '', t.id_tarifa,
                                 N'' de la misma ruta y cabina.'')
    FROM inserted AS i
    JOIN ven.tarifa AS t WITH (UPDLOCK, HOLDLOCK)
      ON t.id_ruta = i.id_ruta AND t.codigo_cabina = i.codigo_cabina AND t.id_tarifa <> i.id_tarifa
    WHERE t.vigente_desde <= ISNULL(i.vigente_hasta, ''99991231'')
      AND i.vigente_desde <= ISNULL(t.vigente_hasta, ''99991231'')
      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50002, @msg, 1;

    IF EXISTS (SELECT 1 FROM deleted)
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-20: la tarifa '', i.id_tarifa, N'' ya se usó en tiquetes; no se puede cambiar su ruta, '',
                                     N''cabina, precio ni inicio de vigencia. Cierre su vigencia y cree una nueva versión.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_tarifa = i.id_tarifa
        WHERE (i.id_ruta <> d.id_ruta OR i.codigo_cabina <> d.codigo_cabina
               OR i.precio_base_usd <> d.precio_base_usd OR i.vigente_desde <> d.vigente_desde)
          AND EXISTS (SELECT 1 FROM ven.tiquete AS t WHERE t.id_tarifa = i.id_tarifa)
          OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50003, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-20: la vigencia de la tarifa '', i.id_tarifa, N'' no puede terminar antes de ventas ya realizadas con ella.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_tarifa = i.id_tarifa
        WHERE ISNULL(i.vigente_hasta, ''99991231'') < ISNULL(d.vigente_hasta, ''99991231'')
          AND EXISTS (SELECT 1 FROM ven.tiquete AS t
                      WHERE t.id_tarifa = i.id_tarifa AND CAST(t.creado_utc AS DATE) > i.vigente_hasta)
                      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50004, @msg, 1;
    END;
END;';

-- E. 05_funciones_y_triggers, lote 8
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_descuento_reglas ON ven.descuento
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @msg NVARCHAR(2048);
    SELECT TOP (1) @msg = CONCAT(N''RN-21: el descuento '', i.codigo_descuento, N'' ya se aplicó a tiquetes; '',
                                 N''no se pueden cambiar su código, porcentaje ni condiciones.'')
    FROM inserted AS i JOIN deleted AS d ON d.id_descuento = i.id_descuento
    WHERE (i.codigo_descuento <> d.codigo_descuento OR i.porcentaje <> d.porcentaje
           OR ISNULL(i.codigo_cabina, '''') <> ISNULL(d.codigo_cabina, '''')
           OR ISNULL(i.dias_anticipacion_min, -1) <> ISNULL(d.dias_anticipacion_min, -1)
           OR i.solo_clientes_registrados <> d.solo_clientes_registrados
           OR i.vigente_desde <> d.vigente_desde)
      AND EXISTS (SELECT 1 FROM ven.tiquete AS t WHERE t.id_descuento = i.id_descuento)
      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50005, @msg, 1;
END;';

-- E. 05_funciones_y_triggers, lote 9
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_compra_reglas ON ven.compra
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048);

    SELECT TOP (1) @msg = CONCAT(N''Los datos de la compra '', d.codigo_reserva, N'' (localizador, comprador, canal, vendedor y fecha) son inmutables.'')
    FROM inserted AS i JOIN deleted AS d ON d.id_compra = i.id_compra
    WHERE i.codigo_reserva <> d.codigo_reserva OR i.id_persona_comprador <> d.id_persona_comprador
       OR i.id_localizacion_venta <> d.id_localizacion_venta OR i.fecha_compra_utc <> d.fecha_compra_utc
       OR ISNULL(i.id_empleado_vendedor, -1) <> ISNULL(d.id_empleado_vendedor, -1)
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50010, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''La localización '', l.codigo_localizacion, N'' no está habilitada para vender tiquetes.'')
    FROM inserted AS i JOIN ref.localizacion AS l ON l.id_localizacion = i.id_localizacion_venta
    WHERE l.vende_tiquetes = 0 OR l.activa = 0
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50011, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-32: la compra '', i.codigo_reserva,
                                 CASE WHEN l.tipo_localizacion = ''WEB'' THEN N'' es web y no admite vendedor.''
                                      ELSE N'' es física y requiere un vendedor.'' END)
    FROM inserted AS i JOIN ref.localizacion AS l ON l.id_localizacion = i.id_localizacion_venta
    WHERE (l.tipo_localizacion = ''WEB'' AND i.id_empleado_vendedor IS NOT NULL)
       OR (l.tipo_localizacion IN (''AER'', ''OFI'') AND i.id_empleado_vendedor IS NULL)
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50012, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-32: el vendedor '', e.numero_empleado, N'' no estaba vigente en la fecha de la compra.'')
    FROM inserted AS i JOIN rh.empleado AS e ON e.id_empleado = i.id_empleado_vendedor
    WHERE e.fecha_contratacion > CAST(i.fecha_compra_utc AS DATE)
       OR (e.fecha_terminacion IS NOT NULL AND e.fecha_terminacion < CAST(i.fecha_compra_utc AS DATE))
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50013, @msg, 1;
END;';

-- E. 05_funciones_y_triggers, lote 10
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_tiquete_reglas ON ven.tiquete
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048);
    DECLARE @es_insercion BIT = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN 0 ELSE 1 END;

    IF @es_insercion = 0
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-19: los datos comerciales del tiquete '', i.numero_tiquete,
                                     N'' (vuelo, cabina, pasajero, tarifa, precio y descuento) son inmutables.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_tiquete = i.id_tiquete
        WHERE i.numero_tiquete <> d.numero_tiquete OR i.id_compra <> d.id_compra OR i.id_vuelo <> d.id_vuelo
           OR i.codigo_cabina <> d.codigo_cabina OR i.id_persona_pasajero <> d.id_persona_pasajero
           OR i.id_tarifa <> d.id_tarifa OR i.precio_base_usd <> d.precio_base_usd
           OR i.porcentaje_descuento <> d.porcentaje_descuento OR ISNULL(i.id_descuento, -1) <> ISNULL(d.id_descuento, -1)
           OR i.creado_utc <> d.creado_utc
           OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50040, @msg, 1;
    END;

    IF @es_insercion = 1
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-08: un tiquete nuevo debe crearse en estado RESERVADO (se recibió '', i.codigo_estado, N'').'')
        FROM inserted AS i JOIN ref.estado_tiquete AS e ON e.codigo_estado = i.codigo_estado
        WHERE e.es_estado_inicial = 0
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50041, @msg, 1;
    END
    ELSE
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-08: transición de tiquete no válida ('', i.numero_tiquete, N''): '',
                                     d.codigo_estado, N'' -> '', i.codigo_estado, N''.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_tiquete = i.id_tiquete
        WHERE i.codigo_estado <> d.codigo_estado
          AND NOT EXISTS (SELECT 1 FROM ref.transicion_tiquete AS t
                          WHERE t.estado_origen = d.codigo_estado AND t.estado_destino = i.codigo_estado)
                          OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50042, @msg, 1;
    END;

    IF @es_insercion = 1
    BEGIN

        SELECT TOP (1) @msg = CONCAT(N''RN-31: el vuelo '', v.id_vuelo, N'' ('', v.codigo_estado, N'') no admite ventas en '',
                                     CONVERT(VARCHAR(19), i.creado_utc, 120), N'' UTC.'')
        FROM inserted AS i
        JOIN ven.compra AS c ON c.id_compra = i.id_compra
        JOIN ops.vuelo  AS v ON v.id_vuelo = i.id_vuelo
        WHERE v.codigo_estado NOT IN (''PROGRAMADO'', ''DEMORADO'')
           OR i.creado_utc >= CONVERT(DATETIME2(0), SWITCHOFFSET(v.salida_programada, ''+00:00''))
           OR i.creado_utc < c.fecha_compra_utc
           OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50043, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-17: la tarifa '', i.id_tarifa, N'' no corresponde a la ruta del vuelo, '',
                                     N''no estaba vigente el '', CONVERT(CHAR(10), CAST(i.creado_utc AS DATE), 23),
                                     N'' o su precio difiere del precio base del tiquete.'')
        FROM inserted AS i
        JOIN ops.vuelo        AS v  ON v.id_vuelo = i.id_vuelo
        JOIN ops.programacion AS p  ON p.id_programacion = v.id_programacion
        JOIN ven.tarifa       AS tf ON tf.id_tarifa = i.id_tarifa
        WHERE tf.id_ruta <> p.id_ruta
           OR CAST(i.creado_utc AS DATE) < tf.vigente_desde
           OR CAST(i.creado_utc AS DATE) > ISNULL(tf.vigente_hasta, ''99991231'')
           OR tf.precio_base_usd <> i.precio_base_usd
           OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50044, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-21: el descuento '', ds.codigo_descuento, N'' no es aplicable al tiquete '', i.numero_tiquete,
                                     N'' (porcentaje, vigencia, cabina, anticipación o registro del comprador).'')
        FROM inserted AS i
        JOIN ven.descuento AS ds ON ds.id_descuento = i.id_descuento
        JOIN ven.compra    AS c  ON c.id_compra = i.id_compra
        JOIN ops.vuelo     AS v  ON v.id_vuelo = i.id_vuelo
        WHERE ds.porcentaje <> i.porcentaje_descuento
           OR ds.activo = 0
           OR CAST(i.creado_utc AS DATE) NOT BETWEEN ds.vigente_desde AND ds.vigente_hasta
           OR (ds.codigo_cabina IS NOT NULL AND ds.codigo_cabina <> i.codigo_cabina)
           OR (ds.dias_anticipacion_min IS NOT NULL
               AND DATEDIFF(DAY, CAST(i.creado_utc AS DATE), v.fecha_salida_local) < ds.dias_anticipacion_min)
           OR (ds.solo_clientes_registrados = 1
               AND NOT EXISTS (SELECT 1 FROM ven.cliente AS cl
                               WHERE cl.id_persona = c.id_persona_comprador
                                 AND cl.fecha_registro_utc <= i.creado_utc
                                 AND cl.estado_cuenta = ''ACTIVA''))
                                 OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50045, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-41: el pasajero '', p.id_persona, N'' requiere fecha de nacimiento y género.'')
        FROM inserted AS i JOIN ven.persona AS p ON p.id_persona = i.id_persona_pasajero
        WHERE p.fecha_nacimiento IS NULL OR p.genero IS NULL
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50046, @msg, 1;
    END;

    SELECT TOP (1) @msg = CONCAT(N''RN-24: el tiquete '', i.numero_tiquete, N'' no está pagado (cobrado '',
                                 ISNULL(pg.cobrado, 0), N'' de '', i.precio_final_usd, N'' USD).'')
    FROM inserted AS i
    LEFT JOIN deleted AS d ON d.id_tiquete = i.id_tiquete
    OUTER APPLY (SELECT SUM(p.monto_usd) AS cobrado
                 FROM ven.pago AS p JOIN ref.estado_pago AS ep ON ep.codigo_estado = p.codigo_estado
                 WHERE p.id_tiquete = i.id_tiquete AND ep.es_cobro = 1) AS pg
    WHERE i.codigo_estado = ''EMITIDO'' AND ISNULL(d.codigo_estado, '''') <> ''EMITIDO''
      AND ISNULL(pg.cobrado, 0) < i.precio_final_usd
      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50047, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''El tiquete '', i.numero_tiquete, N'' no puede pasar a '', i.codigo_estado,
                                 N'' con el vuelo en estado '', v.codigo_estado, N''.'')
    FROM inserted AS i
    JOIN deleted  AS d ON d.id_tiquete = i.id_tiquete
    JOIN ops.vuelo AS v ON v.id_vuelo = i.id_vuelo
    WHERE i.codigo_estado <> d.codigo_estado
      AND ((i.codigo_estado IN (''USADO'', ''NO_PRESENTADO'') AND v.codigo_estado NOT IN (''EN_VUELO'', ''ATERRIZADO''))
        OR (i.codigo_estado = ''CANCELADO'' AND v.codigo_estado NOT IN (''PROGRAMADO'', ''DEMORADO'', ''CANCELADO''))
        OR (i.codigo_estado = ''CANCELADO'' AND i.codigo_motivo_cancelacion <> ''VUELO_CANCELADO''
            AND i.fecha_cancelacion_utc >= CONVERT(DATETIME2(0), SWITCHOFFSET(v.salida_programada, ''+00:00''))))
            OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50048, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-13: el asiento '', i.codigo_asiento, N'' no existe en la cabina '', i.codigo_cabina,
                                 N'' del avión asignado al vuelo '', i.id_vuelo, N'', o el vuelo ya no admite cambios de asiento.'')
    FROM inserted AS i
    LEFT JOIN deleted AS d ON d.id_tiquete = i.id_tiquete
    JOIN ops.vuelo AS v ON v.id_vuelo = i.id_vuelo
    LEFT JOIN ops.avion AS a ON a.id_avion = v.id_avion
    WHERE i.codigo_asiento IS NOT NULL
      AND (d.id_tiquete IS NULL OR ISNULL(d.codigo_asiento, '''') <> i.codigo_asiento)
      AND (v.codigo_estado NOT IN (''PROGRAMADO'', ''DEMORADO'')
           OR i.codigo_estado NOT IN (''RESERVADO'', ''EMITIDO'')
           OR NOT EXISTS (SELECT 1 FROM ops.asiento_configuracion AS s
                          WHERE s.id_configuracion = a.id_configuracion
                            AND s.codigo_asiento = i.codigo_asiento
                            AND s.codigo_cabina = i.codigo_cabina))
                            OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50049, @msg, 1;

    DECLARE @delta TABLE (id_vuelo INT NOT NULL, codigo_cabina CHAR(3) NOT NULL, cambio INT NOT NULL,
                          PRIMARY KEY (id_vuelo, codigo_cabina));
    INSERT @delta (id_vuelo, codigo_cabina, cambio)
    SELECT x.id_vuelo, x.codigo_cabina, SUM(x.cambio)
    FROM (SELECT i.id_vuelo, i.codigo_cabina, CAST(e.ocupa_inventario AS INT) AS cambio
          FROM inserted AS i JOIN ref.estado_tiquete AS e ON e.codigo_estado = i.codigo_estado
          UNION ALL
          SELECT d.id_vuelo, d.codigo_cabina, -CAST(e.ocupa_inventario AS INT)
          FROM deleted AS d JOIN ref.estado_tiquete AS e ON e.codigo_estado = d.codigo_estado) AS x
    GROUP BY x.id_vuelo, x.codigo_cabina
    HAVING SUM(x.cambio) <> 0
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));

    IF EXISTS (SELECT 1 FROM @delta)
    BEGIN

        SELECT TOP (1) @msg = CONCAT(N''RN-11: sin disponibilidad en la cabina '', vc.codigo_cabina, N'' del vuelo '', vc.id_vuelo,
                                     N'' (capacidad '', vc.capacidad, N'', ocupadas '', vc.plazas_ocupadas, N'', solicitadas '', d.cambio, N'').'')
        FROM ops.vuelo_cabina AS vc WITH (UPDLOCK, ROWLOCK)
        JOIN @delta AS d ON d.id_vuelo = vc.id_vuelo AND d.codigo_cabina = vc.codigo_cabina
        WHERE vc.plazas_ocupadas + d.cambio > vc.capacidad
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50020, @msg, 1;

        UPDATE vc
           SET plazas_ocupadas = vc.plazas_ocupadas + d.cambio
        FROM ops.vuelo_cabina AS vc
        JOIN @delta AS d ON d.id_vuelo = vc.id_vuelo AND d.codigo_cabina = vc.codigo_cabina
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    END;

    INSERT aud.cambio_estado (entidad, id_entidad, estado_anterior, estado_nuevo)
    SELECT ''TIQUETE'', i.id_tiquete, d.codigo_estado, i.codigo_estado
    FROM inserted AS i LEFT JOIN deleted AS d ON d.id_tiquete = i.id_tiquete
    WHERE d.id_tiquete IS NULL OR d.codigo_estado <> i.codigo_estado
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
END;';

-- E. 05_funciones_y_triggers, lote 11
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_pago_reglas ON ven.pago
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048), @bloqueados INT;
    DECLARE @es_insercion BIT = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN 0 ELSE 1 END;

    SELECT @bloqueados = COUNT(*)
    FROM ven.tiquete AS t WITH (UPDLOCK, ROWLOCK)
    WHERE t.id_tiquete IN (SELECT id_tiquete FROM inserted)
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));

    IF @es_insercion = 0
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''El pago '', i.id_pago, N'' solo puede cambiar de estado; su tiquete, método, monto y fecha son inmutables.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_pago = i.id_pago
        WHERE i.id_tiquete <> d.id_tiquete OR i.codigo_metodo <> d.codigo_metodo OR i.monto_usd <> d.monto_usd
           OR i.id_localizacion_cobro <> d.id_localizacion_cobro OR i.fecha_creacion_utc <> d.fecha_creacion_utc
           OR ISNULL(i.ultimos4_tarjeta, '''') <> ISNULL(d.ultimos4_tarjeta, '''')
           OR ISNULL(i.marca_tarjeta, '''') <> ISNULL(d.marca_tarjeta, '''')
           OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50050, @msg, 1;

        SELECT TOP (1) @msg = CONCAT(N''RN-08: transición de pago no válida (pago '', i.id_pago, N''): '',
                                     d.codigo_estado, N'' -> '', i.codigo_estado, N''.'')
        FROM inserted AS i JOIN deleted AS d ON d.id_pago = i.id_pago
        WHERE i.codigo_estado <> d.codigo_estado
          AND NOT EXISTS (SELECT 1 FROM ref.transicion_pago AS t
                          WHERE t.estado_origen = d.codigo_estado AND t.estado_destino = i.codigo_estado)
                          OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50051, @msg, 1;
    END
    ELSE
    BEGIN
        SELECT TOP (1) @msg = CONCAT(N''RN-08: un pago no puede crearse en estado '', i.codigo_estado, N''.'')
        FROM inserted AS i JOIN ref.estado_pago AS e ON e.codigo_estado = i.codigo_estado
        WHERE e.es_estado_inicial = 0
        OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
        IF @msg IS NOT NULL THROW 50052, @msg, 1;
    END;

    SELECT TOP (1) @msg = CONCAT(N''El tiquete '', t.numero_tiquete, N'' está en estado '', t.codigo_estado,
                                 N''; solo se registran o confirman pagos de tiquetes RESERVADOS.'')
    FROM inserted AS i
    LEFT JOIN deleted AS d ON d.id_pago = i.id_pago
    JOIN ven.tiquete AS t ON t.id_tiquete = i.id_tiquete
    WHERE t.codigo_estado <> ''RESERVADO''
      AND (d.id_pago IS NULL OR (i.codigo_estado = ''CONFIRMADO'' AND d.codigo_estado <> ''CONFIRMADO''))
      OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50053, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-23: los pagos confirmados del tiquete '', t.numero_tiquete, N'' ('', s.cobrado,
                                 N'' USD) superarían su precio final ('', t.precio_final_usd, N'' USD).'')
    FROM (SELECT DISTINCT id_tiquete FROM inserted) AS i
    JOIN ven.tiquete AS t ON t.id_tiquete = i.id_tiquete
    CROSS APPLY (SELECT SUM(p.monto_usd) AS cobrado
                 FROM ven.pago AS p JOIN ref.estado_pago AS ep ON ep.codigo_estado = p.codigo_estado
                 WHERE p.id_tiquete = i.id_tiquete AND ep.es_cobro = 1) AS s
    WHERE s.cobrado > t.precio_final_usd
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50054, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-25: el método '', m.codigo_metodo, N'' no está permitido en la localización '', l.codigo_localizacion, N''.'')
    FROM inserted AS i
    JOIN ref.metodo_pago  AS m ON m.codigo_metodo = i.codigo_metodo
    JOIN ref.localizacion AS l ON l.id_localizacion = i.id_localizacion_cobro
    WHERE l.vende_tiquetes = 0
       OR (l.tipo_localizacion = ''WEB'' AND m.permite_web = 0)
       OR (l.tipo_localizacion <> ''WEB'' AND m.permite_fisico = 0)
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50055, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''El pago '', i.id_pago, N'' es anterior a la venta del tiquete '', t.numero_tiquete, N''.'')
    FROM inserted AS i JOIN ven.tiquete AS t ON t.id_tiquete = i.id_tiquete
    WHERE i.fecha_creacion_utc < t.creado_utc
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50056, @msg, 1;

    INSERT aud.cambio_estado (entidad, id_entidad, estado_anterior, estado_nuevo)
    SELECT ''PAGO'', i.id_pago, d.codigo_estado, i.codigo_estado
    FROM inserted AS i LEFT JOIN deleted AS d ON d.id_pago = i.id_pago
    WHERE d.id_pago IS NULL OR d.codigo_estado <> i.codigo_estado
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
END;';

-- E. 05_funciones_y_triggers, lote 12
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_reembolso_reglas ON ven.reembolso
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) RETURN;
    DECLARE @msg NVARCHAR(2048), @bloqueados INT;

    IF EXISTS (SELECT 1 FROM deleted)
        THROW 50060, N''RN-29: los reembolsos son inmutables; registre un movimiento nuevo si fuera necesario.'', 1;

    SELECT @bloqueados = COUNT(*)
    FROM ven.pago AS p WITH (UPDLOCK, ROWLOCK)
    WHERE p.id_pago IN (SELECT id_pago FROM inserted)
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));

    SELECT TOP (1) @msg = CONCAT(N''RN-28: el pago '', p.id_pago, N'' ('', p.codigo_estado, N'') del tiquete '', t.numero_tiquete,
                                 N'' ('', t.codigo_estado, N'') no admite reembolsos.'')
    FROM inserted AS i
    JOIN ven.pago    AS p ON p.id_pago = i.id_pago
    JOIN ven.tiquete AS t ON t.id_tiquete = p.id_tiquete
    WHERE p.codigo_estado <> ''CONFIRMADO'' OR t.codigo_estado <> ''CANCELADO''
       OR i.codigo_motivo <> t.codigo_motivo_cancelacion
       OR i.fecha_reembolso_utc < t.fecha_cancelacion_utc
       OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50061, @msg, 1;

    SELECT TOP (1) @msg = CONCAT(N''RN-28: los reembolsos del pago '', p.id_pago, N'' ('', s.reembolsado,
                                 N'' USD) superan el monto pagado ('', p.monto_usd, N'' USD).'')
    FROM (SELECT DISTINCT id_pago FROM inserted) AS i
    JOIN ven.pago AS p ON p.id_pago = i.id_pago
    CROSS APPLY (SELECT SUM(r.monto_usd) AS reembolsado FROM ven.reembolso AS r WHERE r.id_pago = i.id_pago) AS s
    WHERE s.reembolsado > p.monto_usd
    OPTION (RECOMPILE, USE HINT (''DISABLE_OPTIMIZER_ROWGOAL''));
    IF @msg IS NOT NULL THROW 50062, @msg, 1;
END;';

-- E. 05_funciones_y_triggers, lote 13
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_tiquete_sin_borrado ON ven.tiquete
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM deleted)
        THROW 50039, N''RN-29: los tiquetes no se eliminan; use ven.usp_cancelar_tiquete.'', 1;
END;';

-- E. 05_funciones_y_triggers, lote 14
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_pago_sin_borrado ON ven.pago
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM deleted)
        THROW 50059, N''RN-29: los pagos no se eliminan; un pago pendiente se anula y uno confirmado se reembolsa.'', 1;
END;';

-- E. 05_funciones_y_triggers, lote 15
EXEC sys.sp_executesql N'CREATE OR ALTER TRIGGER ven.trg_reembolso_sin_borrado ON ven.reembolso
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM deleted)
        THROW 50069, N''RN-29: los reembolsos no se eliminan.'', 1;
END;';

-- E. 05_funciones_y_triggers, lote 16
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''05_funciones_y_triggers'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''05_funciones_y_triggers'', N''Funciones y triggers de reglas de negocio'');';

-- E. 06_vistas, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 06_vistas, lote 2
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_vuelo
AS
SELECT v.id_vuelo,
       CONCAT(''XX'', p.numero_vuelo)                                        AS codigo_vuelo,
       p.numero_vuelo,
       p.id_programacion,
       v.fecha_salida_local,
       DATEDIFF(DAY, CAST(''19000101'' AS DATE), v.fecha_salida_local) % 7 + 1 AS dia_semana_iso,
       r.id_ruta,
       ao.codigo_iata                                                      AS origen,
       ad.codigo_iata                                                      AS destino,
       CONCAT(ao.codigo_iata, ''-'', ad.codigo_iata)                         AS ruta,
       r.distancia_millas,
       v.salida_programada,
       v.llegada_programada,
       CONVERT(DATETIME2(0), SWITCHOFFSET(v.salida_programada, ''+00:00''))  AS salida_programada_utc,
       CONVERT(DATETIME2(0), SWITCHOFFSET(v.llegada_programada, ''+00:00'')) AS llegada_programada_utc,
       DATEPART(HOUR, v.salida_programada)                                 AS hora_salida_local,
       DATEDIFF(MINUTE, v.salida_programada, v.llegada_programada)         AS duracion_programada_min,
       CASE WHEN CAST(v.llegada_programada AS DATE) > v.fecha_salida_local THEN 1 ELSE 0 END AS llega_dia_siguiente,
       v.salida_estimada,
       v.salida_real,
       v.llegada_real,
       DATEDIFF(MINUTE, v.salida_programada, v.salida_real)                AS demora_salida_min,
       DATEDIFF(MINUTE, v.llegada_programada, v.llegada_real)              AS demora_llegada_min,
       v.codigo_estado,
       v.id_avion,
       a.matricula,
       m.fabricante,
       m.modelo,
       cfg.codigo_configuracion
FROM ops.vuelo                    AS v
JOIN ops.programacion             AS p   ON p.id_programacion = v.id_programacion
JOIN ops.ruta                     AS r   ON r.id_ruta = p.id_ruta
JOIN ref.aeropuerto               AS ao  ON ao.id_localizacion = r.id_aeropuerto_origen
JOIN ref.aeropuerto               AS ad  ON ad.id_localizacion = r.id_aeropuerto_destino
LEFT JOIN ops.avion               AS a   ON a.id_avion = v.id_avion
LEFT JOIN ops.configuracion_asientos AS cfg ON cfg.id_configuracion = a.id_configuracion
LEFT JOIN ref.modelo_avion        AS m   ON m.id_modelo = cfg.id_modelo;';

-- E. 06_vistas, lote 3
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_ocupacion_vuelo_cabina
AS
SELECT vc.id_vuelo,
       vc.codigo_cabina,
       v.fecha_salida_local,
       v.codigo_estado                                AS estado_vuelo,
       v.id_ruta,
       v.ruta,
       v.codigo_vuelo,
       vc.capacidad,
       vc.plazas_ocupadas,
       vc.capacidad - vc.plazas_ocupadas              AS plazas_disponibles,
       ISNULL(t.tiquetes_activos, 0)                  AS tiquetes_activos,
       ISNULL(t.reservados, 0)                        AS reservados,
       ISNULL(t.emitidos, 0)                          AS emitidos,
       ISNULL(t.usados, 0)                            AS usados,
       ISNULL(t.no_presentados, 0)                    AS no_presentados,
       ISNULL(t.cancelados, 0)                        AS cancelados,
       CAST(vc.plazas_ocupadas * 1.0 / vc.capacidad AS DECIMAL(7,4)) AS factor_ocupacion_vendido,
       CASE WHEN v.codigo_estado IN (''EN_VUELO'', ''ATERRIZADO'')
            THEN CAST(ISNULL(t.usados, 0) * 1.0 / vc.capacidad AS DECIMAL(7,4)) END AS factor_ocupacion_volado
FROM ops.vuelo_cabina AS vc
JOIN rpt.v_vuelo      AS v ON v.id_vuelo = vc.id_vuelo
LEFT JOIN (
    SELECT id_vuelo, codigo_cabina,
           SUM(CASE WHEN codigo_estado <> ''CANCELADO'' THEN 1 ELSE 0 END)     AS tiquetes_activos,
           SUM(CASE WHEN codigo_estado = ''RESERVADO'' THEN 1 ELSE 0 END)      AS reservados,
           SUM(CASE WHEN codigo_estado = ''EMITIDO'' THEN 1 ELSE 0 END)        AS emitidos,
           SUM(CASE WHEN codigo_estado = ''USADO'' THEN 1 ELSE 0 END)          AS usados,
           SUM(CASE WHEN codigo_estado = ''NO_PRESENTADO'' THEN 1 ELSE 0 END)  AS no_presentados,
           SUM(CASE WHEN codigo_estado = ''CANCELADO'' THEN 1 ELSE 0 END)      AS cancelados
    FROM ven.tiquete
    GROUP BY id_vuelo, codigo_cabina
) AS t ON t.id_vuelo = vc.id_vuelo AND t.codigo_cabina = vc.codigo_cabina;';

-- E. 06_vistas, lote 4
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_tiquete_financiero
AS
SELECT t.id_tiquete,
       t.numero_tiquete,
       t.id_compra,
       t.id_vuelo,
       t.codigo_cabina,
       t.codigo_estado,
       t.creado_utc                                                AS fecha_venta_utc,
       t.precio_base_usd,
       t.porcentaje_descuento,
       t.monto_descuento_usd,
       t.precio_final_usd,
       ISNULL(pg.cobrado_usd, 0)                                   AS cobrado_usd,
       ISNULL(pg.pagos_confirmados, 0)                             AS pagos_confirmados,
       ISNULL(pg.pagos_fallidos, 0)                                AS pagos_fallidos,
       ISNULL(pg.pendiente_confirmacion_usd, 0)                    AS pendiente_confirmacion_usd,
       ISNULL(rb.reembolsado_usd, 0)                               AS reembolsado_usd,
       ISNULL(pg.cobrado_usd, 0) - ISNULL(rb.reembolsado_usd, 0)   AS cobro_neto_usd,
       CASE WHEN t.codigo_estado = ''RESERVADO''
            THEN t.precio_final_usd - ISNULL(pg.cobrado_usd, 0) ELSE 0 END AS saldo_pendiente_usd,
       CASE WHEN t.codigo_estado = ''CANCELADO''
            THEN ISNULL(pg.cobrado_usd, 0) - ISNULL(rb.reembolsado_usd, 0) ELSE 0 END AS penalidad_retenida_usd
FROM ven.tiquete AS t
LEFT JOIN (
    SELECT id_tiquete,
           SUM(CASE WHEN codigo_estado = ''CONFIRMADO'' THEN monto_usd ELSE 0 END) AS cobrado_usd,
           SUM(CASE WHEN codigo_estado = ''CONFIRMADO'' THEN 1 ELSE 0 END)         AS pagos_confirmados,
           SUM(CASE WHEN codigo_estado = ''FALLIDO'' THEN 1 ELSE 0 END)            AS pagos_fallidos,
           SUM(CASE WHEN codigo_estado = ''PENDIENTE'' THEN monto_usd ELSE 0 END)  AS pendiente_confirmacion_usd
    FROM ven.pago
    GROUP BY id_tiquete
) AS pg ON pg.id_tiquete = t.id_tiquete
LEFT JOIN (
    SELECT p.id_tiquete, SUM(r.monto_usd) AS reembolsado_usd
    FROM ven.reembolso AS r
    JOIN ven.pago      AS p ON p.id_pago = r.id_pago
    GROUP BY p.id_tiquete
) AS rb ON rb.id_tiquete = t.id_tiquete;';

-- E. 06_vistas, lote 5
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_venta
AS
SELECT t.id_tiquete,
       t.numero_tiquete,
       c.id_compra,
       c.codigo_reserva,
       t.creado_utc                                     AS fecha_venta_utc,
       CAST(t.creado_utc AS DATE)                       AS fecha_venta,
       l.codigo_localizacion,
       l.nombre                                         AS localizacion,
       l.tipo_localizacion,
       CASE WHEN l.tipo_localizacion = ''WEB'' THEN ''WEB'' ELSE ''FISICO'' END AS canal,
       c.id_persona_comprador,
       CASE WHEN cc.id_persona IS NOT NULL AND cc.fecha_registro_utc <= t.creado_utc THEN 1 ELSE 0 END AS comprador_registrado,
       t.id_persona_pasajero,
       CASE WHEN cp.id_persona IS NOT NULL AND cp.fecha_registro_utc <= t.creado_utc THEN 1 ELSE 0 END AS pasajero_registrado,
       CASE WHEN t.id_persona_pasajero = c.id_persona_comprador THEN 1 ELSE 0 END AS comprador_es_pasajero,
       t.id_vuelo,
       v.codigo_vuelo,
       v.fecha_salida_local,
       v.id_ruta,
       v.ruta,
       t.codigo_cabina,
       t.codigo_estado,
       t.codigo_motivo_cancelacion,
       t.precio_base_usd,
       t.porcentaje_descuento,
       t.monto_descuento_usd,
       t.precio_final_usd,
       ds.codigo_descuento,
       DATEDIFF(DAY, CAST(t.creado_utc AS DATE), v.fecha_salida_local) AS dias_anticipacion
FROM ven.tiquete          AS t
JOIN ven.compra           AS c  ON c.id_compra = t.id_compra
JOIN ref.localizacion     AS l  ON l.id_localizacion = c.id_localizacion_venta
JOIN rpt.v_vuelo          AS v  ON v.id_vuelo = t.id_vuelo
LEFT JOIN ven.cliente     AS cc ON cc.id_persona = c.id_persona_comprador
LEFT JOIN ven.cliente     AS cp ON cp.id_persona = t.id_persona_pasajero
LEFT JOIN ven.descuento   AS ds ON ds.id_descuento = t.id_descuento;';

-- E. 06_vistas, lote 6
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_utilizacion_avion_dia
AS
SELECT a.id_avion,
       a.matricula,
       m.modelo,
       v.fecha_salida_local,
       COUNT(*)                                                                    AS vuelos,
       SUM(DATEDIFF(MINUTE, v.salida_programada, v.llegada_programada))            AS minutos_bloque_programados,
       SUM(CASE WHEN v.codigo_estado = ''ATERRIZADO''
                THEN DATEDIFF(MINUTE, v.salida_real, v.llegada_real) END)          AS minutos_bloque_reales
FROM ops.vuelo                    AS v
JOIN ops.avion                    AS a   ON a.id_avion = v.id_avion
JOIN ops.configuracion_asientos   AS cfg ON cfg.id_configuracion = a.id_configuracion
JOIN ref.modelo_avion             AS m   ON m.id_modelo = cfg.id_modelo
WHERE v.codigo_estado <> ''CANCELADO''
GROUP BY a.id_avion, a.matricula, m.modelo, v.fecha_salida_local;';

-- E. 06_vistas, lote 7
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_conciliacion_inventario
AS
SELECT vc.id_vuelo,
       vc.codigo_cabina,
       vc.capacidad,
       vc.plazas_ocupadas,
       ISNULL(t.ocupan, 0)                        AS tiquetes_que_ocupan,
       vc.plazas_ocupadas - ISNULL(t.ocupan, 0)   AS diferencia
FROM ops.vuelo_cabina AS vc
LEFT JOIN (
    SELECT t.id_vuelo, t.codigo_cabina, COUNT(*) AS ocupan
    FROM ven.tiquete AS t
    JOIN ref.estado_tiquete AS e ON e.codigo_estado = t.codigo_estado
    WHERE e.ocupa_inventario = 1
    GROUP BY t.id_vuelo, t.codigo_cabina
) AS t ON t.id_vuelo = vc.id_vuelo AND t.codigo_cabina = vc.codigo_cabina;';

-- E. 06_vistas, lote 8
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_programacion
AS
SELECT p.id_programacion,
       CONCAT(''XX'', p.numero_vuelo) AS codigo_vuelo,
       CONCAT(ao.codigo_iata, ''-'', ad.codigo_iata) AS ruta,
       p.hora_salida_local,
       p.duracion_programada_min,
       p.vigente_desde,
       p.vigente_hasta,
       p.activa,
       MAX(CASE WHEN d.dia_semana = 1 THEN 1 ELSE 0 END) AS lun,
       MAX(CASE WHEN d.dia_semana = 2 THEN 1 ELSE 0 END) AS mar,
       MAX(CASE WHEN d.dia_semana = 3 THEN 1 ELSE 0 END) AS mie,
       MAX(CASE WHEN d.dia_semana = 4 THEN 1 ELSE 0 END) AS jue,
       MAX(CASE WHEN d.dia_semana = 5 THEN 1 ELSE 0 END) AS vie,
       MAX(CASE WHEN d.dia_semana = 6 THEN 1 ELSE 0 END) AS sab,
       MAX(CASE WHEN d.dia_semana = 7 THEN 1 ELSE 0 END) AS dom,
       COUNT(d.dia_semana) AS dias_por_semana
FROM ops.programacion          AS p
JOIN ops.ruta                  AS r  ON r.id_ruta = p.id_ruta
JOIN ref.aeropuerto            AS ao ON ao.id_localizacion = r.id_aeropuerto_origen
JOIN ref.aeropuerto            AS ad ON ad.id_localizacion = r.id_aeropuerto_destino
LEFT JOIN ops.programacion_dia AS d  ON d.id_programacion = p.id_programacion
GROUP BY p.id_programacion, p.numero_vuelo, ao.codigo_iata, ad.codigo_iata, p.hora_salida_local,
         p.duracion_programada_min, p.vigente_desde, p.vigente_hasta, p.activa;';

-- E. 06_vistas, lote 9
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_empleado
AS
SELECT e.id_empleado,
       e.numero_empleado,
       CONCAT(e.nombres, N'' '', e.apellidos) AS nombre_completo,
       e.codigo_cargo,
       c.nombre                    AS cargo,
       c.categoria_tripulacion,
       d.nombre                    AS departamento,
       l.codigo_localizacion       AS base,
       e.fecha_contratacion,
       e.fecha_terminacion,
       CASE WHEN e.fecha_terminacion IS NULL THEN 1 ELSE 0 END AS activo
FROM rh.empleado        AS e
JOIN rh.cargo           AS c ON c.codigo_cargo = e.codigo_cargo
JOIN rh.departamento    AS d ON d.codigo_departamento = c.codigo_departamento
JOIN ref.localizacion   AS l ON l.id_localizacion = e.id_localizacion_base;';

-- E. 06_vistas, lote 10
EXEC sys.sp_executesql N'CREATE OR ALTER VIEW rpt.v_tripulacion_vuelo
AS
SELECT a.id_vuelo,
       v.codigo_vuelo,
       v.fecha_salida_local,
       v.ruta,
       v.codigo_estado AS estado_vuelo,
       a.id_empleado,
       e.numero_empleado,
       e.nombre_completo,
       a.rol_vuelo,
       v.duracion_programada_min,
       CASE WHEN v.codigo_estado = ''ATERRIZADO'' THEN DATEDIFF(MINUTE, v.salida_real, v.llegada_real) END AS minutos_reales
FROM ops.asignacion_tripulacion AS a
JOIN rpt.v_vuelo                AS v ON v.id_vuelo = a.id_vuelo
JOIN rpt.v_empleado             AS e ON e.id_empleado = a.id_empleado;';

-- E. 06_vistas, lote 11
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''06_vistas'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''06_vistas'', N''Vistas de reporte'');';

-- E. 07_procedimientos, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 07_procedimientos, lote 2
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_registrar_persona
    @nombres                    NVARCHAR(60),
    @apellidos                  NVARCHAR(60),
    @fecha_nacimiento           DATE          = NULL,
    @genero                     CHAR(1)       = NULL,
    @email_contacto             VARCHAR(120)  = NULL,
    @telefono                   VARCHAR(20)   = NULL,
    @codigo_pais_nacionalidad   CHAR(2)       = NULL,
    @tipo_documento             VARCHAR(10)   = NULL,
    @numero_documento           VARCHAR(20)   = NULL,
    @codigo_pais_documento      CHAR(2)       = NULL,
    @id_persona                 INT           = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NULLIF(LTRIM(RTRIM(@nombres)), N'''') IS NULL OR NULLIF(LTRIM(RTRIM(@apellidos)), N'''') IS NULL
        THROW 50101, N''Nombres y apellidos son obligatorios.'', 1;

    INSERT ven.persona (nombres, apellidos, fecha_nacimiento, genero, email_contacto, telefono,
                        codigo_pais_nacionalidad, tipo_documento, numero_documento, codigo_pais_documento)
    VALUES (LTRIM(RTRIM(@nombres)), LTRIM(RTRIM(@apellidos)), @fecha_nacimiento, @genero, LOWER(@email_contacto), @telefono,
            @codigo_pais_nacionalidad, @tipo_documento, @numero_documento, @codigo_pais_documento);
    SET @id_persona = CAST(SCOPE_IDENTITY() AS INT);
END;';

-- E. 07_procedimientos, lote 3
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_registrar_cliente
    @id_persona                 INT,
    @email_acceso               VARCHAR(120),
    @acepta_marketing           BIT           = 0,
    @id_aeropuerto_preferido    INT           = NULL,
    @numero_viajero             CHAR(10)      = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF NOT EXISTS (SELECT 1 FROM ven.persona WHERE id_persona = @id_persona)
        THROW 50102, N''La persona no existe.'', 1;
    IF EXISTS (SELECT 1 FROM ven.cliente WHERE id_persona = @id_persona)
        THROW 50103, N''La persona ya tiene una cuenta de cliente.'', 1;

    DECLARE @serie INT = NEXT VALUE FOR ven.seq_numero_viajero;
    SET @numero_viajero = CONCAT(''VF'', RIGHT(CONCAT(''00000000'', @serie), 8));
    BEGIN TRY
        INSERT ven.cliente (id_persona, numero_viajero, email_acceso, acepta_marketing, id_aeropuerto_preferido)
        VALUES (@id_persona, @numero_viajero, LOWER(@email_acceso), @acepta_marketing, @id_aeropuerto_preferido);
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() IN (2601, 2627) AND ERROR_MESSAGE() LIKE N''%uq_cliente_email_acceso%''
            THROW 50104, N''El correo de acceso ya está registrado por otro cliente.'', 1;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 4
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_consultar_disponibilidad
    @origen         CHAR(3),
    @destino        CHAR(3),
    @fecha_salida   DATE,
    @fecha_venta_utc DATETIME2(0) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET @fecha_venta_utc = ISNULL(@fecha_venta_utc, SYSUTCDATETIME());
    SELECT o.id_vuelo, o.codigo_vuelo, o.ruta, v.salida_programada, v.llegada_programada, o.codigo_cabina,
           o.capacidad, o.plazas_disponibles, tf.id_tarifa, tf.precio_base_usd
    FROM rpt.v_ocupacion_vuelo_cabina AS o
    JOIN rpt.v_vuelo AS v ON v.id_vuelo = o.id_vuelo
    OUTER APPLY (SELECT TOP (1) t.id_tarifa, t.precio_base_usd
                 FROM ven.tarifa AS t
                 WHERE t.id_ruta = o.id_ruta AND t.codigo_cabina = o.codigo_cabina
                   AND CAST(@fecha_venta_utc AS DATE) BETWEEN t.vigente_desde AND ISNULL(t.vigente_hasta, ''99991231'')) AS tf
    WHERE v.origen = @origen AND v.destino = @destino AND o.fecha_salida_local = @fecha_salida
      AND o.estado_vuelo IN (''PROGRAMADO'', ''DEMORADO'')
    ORDER BY v.salida_programada, o.codigo_cabina;
END;';

-- E. 07_procedimientos, lote 5
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_emitir_tiquete
    @id_vuelo               INT,
    @codigo_cabina          CHAR(3),
    @id_persona_pasajero    INT,
    @id_persona_comprador   INT,
    @id_localizacion_venta  INT,
    @id_empleado_vendedor   INT           = NULL,
    @codigo_descuento       VARCHAR(20)   = NULL,
    @codigo_asiento         VARCHAR(4)    = NULL,
    @fecha_venta_utc        DATETIME2(0)  = NULL,
    @id_compra              INT           = NULL OUTPUT,   
    @id_tiquete             INT           = NULL OUTPUT,
    @numero_tiquete         CHAR(13)      = NULL OUTPUT,
    @codigo_reserva         CHAR(6)       = NULL OUTPUT,
    @precio_final_usd       DECIMAL(10,2) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @ahora DATETIME2(0) = SYSUTCDATETIME();
    SET @fecha_venta_utc = ISNULL(@fecha_venta_utc, @ahora);
    IF @fecha_venta_utc > DATEADD(MINUTE, 5, @ahora)
        THROW 50110, N''La fecha de venta no puede estar en el futuro.'', 1;

    DECLARE @id_ruta SMALLINT, @salida_utc DATETIME2(0), @estado_vuelo VARCHAR(15), @fecha_vuelo DATE;
    SELECT @id_ruta = p.id_ruta,
           @salida_utc = CONVERT(DATETIME2(0), SWITCHOFFSET(v.salida_programada, ''+00:00'')),
           @estado_vuelo = v.codigo_estado,
           @fecha_vuelo = v.fecha_salida_local
    FROM ops.vuelo AS v JOIN ops.programacion AS p ON p.id_programacion = v.id_programacion
    WHERE v.id_vuelo = @id_vuelo;

    IF @id_ruta IS NULL
        THROW 50111, N''El vuelo no existe.'', 1;
    IF @estado_vuelo NOT IN (''PROGRAMADO'', ''DEMORADO'') OR @fecha_venta_utc >= @salida_utc
        THROW 50112, N''El vuelo no está abierto a la venta.'', 1;
    IF NOT EXISTS (SELECT 1 FROM ops.vuelo_cabina WHERE id_vuelo = @id_vuelo AND codigo_cabina = @codigo_cabina)
        THROW 50113, N''La cabina no existe en este vuelo o el vuelo aún no tiene avión asignado.'', 1;

    DECLARE @id_tarifa INT, @precio_base DECIMAL(10,2);
    SELECT @id_tarifa = id_tarifa, @precio_base = precio_base_usd
    FROM ven.tarifa
    WHERE id_ruta = @id_ruta AND codigo_cabina = @codigo_cabina
      AND CAST(@fecha_venta_utc AS DATE) BETWEEN vigente_desde AND ISNULL(vigente_hasta, ''99991231'');
    IF @id_tarifa IS NULL
        THROW 50114, N''No hay tarifa vigente para la ruta y la cabina en la fecha de venta.'', 1;

    DECLARE @id_descuento SMALLINT = NULL, @porcentaje DECIMAL(5,2) = 0;
    IF @codigo_descuento IS NOT NULL
    BEGIN
        SELECT @id_descuento = d.id_descuento, @porcentaje = d.porcentaje
        FROM ven.descuento AS d
        WHERE d.codigo_descuento = @codigo_descuento AND d.activo = 1
          AND CAST(@fecha_venta_utc AS DATE) BETWEEN d.vigente_desde AND d.vigente_hasta
          AND (d.codigo_cabina IS NULL OR d.codigo_cabina = @codigo_cabina)
          AND (d.dias_anticipacion_min IS NULL
               OR DATEDIFF(DAY, CAST(@fecha_venta_utc AS DATE), @fecha_vuelo) >= d.dias_anticipacion_min)
          AND (d.solo_clientes_registrados = 0
               OR EXISTS (SELECT 1 FROM ven.cliente AS c
                          WHERE c.id_persona = @id_persona_comprador AND c.fecha_registro_utc <= @fecha_venta_utc
                            AND c.estado_cuenta = ''ACTIVA''));
        IF @id_descuento IS NULL
            THROW 50115, N''El código de descuento no existe o no es aplicable a esta venta.'', 1;
    END;

    DECLARE @horas_limite INT = ISNULL((SELECT CAST(valor AS INT) FROM ref.parametro WHERE clave = ''HORAS_LIMITE_PAGO''), 72);
    DECLARE @horas_cierre INT = ISNULL((SELECT CAST(valor AS INT) FROM ref.parametro WHERE clave = ''HORAS_CIERRE_VENTA''), 3);
    DECLARE @limite_pago DATETIME2(0) = DATEADD(HOUR, @horas_limite, @fecha_venta_utc);
    IF @limite_pago > DATEADD(HOUR, -@horas_cierre, @salida_utc)
        SET @limite_pago = DATEADD(HOUR, -@horas_cierre, @salida_utc);
    IF @limite_pago <= @fecha_venta_utc
        THROW 50119, N''Las ventas de este vuelo ya cerraron (cierre antes de la salida).'', 1;

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;

        IF @id_compra IS NULL
        BEGIN

            DECLARE @alfabeto CHAR(32) = ''ABCDEFGHJKLMNPQRSTUVWXYZ23456789'', @bytes BINARY(6), @intentos INT = 0;
            WHILE 1 = 1
            BEGIN
                SET @bytes = CRYPT_GEN_RANDOM(6);
                SET @codigo_reserva = CONCAT(
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 1, 1) AS INT) % 32 + 1, 1),
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 2, 1) AS INT) % 32 + 1, 1),
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 3, 1) AS INT) % 32 + 1, 1),
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 4, 1) AS INT) % 32 + 1, 1),
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 5, 1) AS INT) % 32 + 1, 1),
                    SUBSTRING(@alfabeto, CAST(SUBSTRING(@bytes, 6, 1) AS INT) % 32 + 1, 1));
                IF NOT EXISTS (SELECT 1 FROM ven.compra WITH (UPDLOCK, HOLDLOCK) WHERE codigo_reserva = @codigo_reserva) BREAK;
                SET @intentos += 1;
                IF @intentos >= 10 THROW 50116, N''No se pudo generar un localizador único.'', 1;
            END;

            INSERT ven.compra (codigo_reserva, id_persona_comprador, id_localizacion_venta, id_empleado_vendedor,
                               fecha_compra_utc, email_confirmacion)
            SELECT @codigo_reserva, p.id_persona, @id_localizacion_venta, @id_empleado_vendedor, @fecha_venta_utc, p.email_contacto
            FROM ven.persona AS p WHERE p.id_persona = @id_persona_comprador;
            IF @@ROWCOUNT = 0 THROW 50117, N''El comprador no existe.'', 1;
            SET @id_compra = CAST(SCOPE_IDENTITY() AS INT);
        END
        ELSE
        BEGIN
            SET @codigo_reserva = NULL;
            SELECT @codigo_reserva = codigo_reserva
            FROM ven.compra WITH (UPDLOCK)
            WHERE id_compra = @id_compra AND id_persona_comprador = @id_persona_comprador
              AND fecha_compra_utc <= @fecha_venta_utc;
            IF @codigo_reserva IS NULL
                THROW 50118, N''La compra no existe, pertenece a otro comprador o es posterior a la venta.'', 1;
        END;

        DECLARE @serie BIGINT = NEXT VALUE FOR ven.seq_numero_tiquete;
        SET @numero_tiquete = CONCAT(''000'', RIGHT(CONCAT(''0000000000'', @serie), 10));

        INSERT ven.tiquete (numero_tiquete, id_compra, id_vuelo, codigo_cabina, id_persona_pasajero, codigo_asiento,
                            id_tarifa, precio_base_usd, id_descuento, porcentaje_descuento, codigo_estado,
                            fecha_limite_pago_utc, creado_utc)
        VALUES (@numero_tiquete, @id_compra, @id_vuelo, @codigo_cabina, @id_persona_pasajero, @codigo_asiento,
                @id_tarifa, @precio_base, @id_descuento, @porcentaje, ''RESERVADO'',
                @limite_pago, @fecha_venta_utc);
        SET @id_tiquete = CAST(SCOPE_IDENTITY() AS INT);
        SELECT @precio_final_usd = precio_final_usd FROM ven.tiquete WHERE id_tiquete = @id_tiquete;

        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        DECLARE @numero INT = ERROR_NUMBER(), @mensaje NVARCHAR(2048) = ERROR_MESSAGE();
        IF @numero IN (2601, 2627) AND @mensaje LIKE N''%ux_tiquete_vuelo_asiento%''
            THROW 50120, N''RN-12: el asiento ya está ocupado en este vuelo.'', 1;
        IF @numero IN (2601, 2627) AND @mensaje LIKE N''%ux_tiquete_vuelo_pasajero%''
            THROW 50121, N''RN-14: el pasajero ya tiene un tiquete activo en este vuelo.'', 1;
        IF @numero = 547 AND @mensaje LIKE N''%ck_vuelo_cabina_capacidad%''
            THROW 50020, N''RN-11: sin disponibilidad en la cabina solicitada.'', 1;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 6
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_asignar_asiento
    @id_tiquete         INT,
    @codigo_asiento     VARCHAR(4) = NULL,
    @asiento_asignado   VARCHAR(4) = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @intento INT = 0, @id_vuelo INT, @cabina CHAR(3), @estado VARCHAR(15);

    WHILE 1 = 1
    BEGIN
        BEGIN TRY
            IF @tran_propia = 1 BEGIN TRANSACTION;
            SELECT @id_vuelo = id_vuelo, @cabina = codigo_cabina, @estado = codigo_estado
            FROM ven.tiquete WITH (UPDLOCK, ROWLOCK) WHERE id_tiquete = @id_tiquete;
            IF @id_vuelo IS NULL THROW 50122, N''El tiquete no existe.'', 1;
            IF @estado NOT IN (''RESERVADO'', ''EMITIDO'') THROW 50123, N''Solo se asignan asientos a tiquetes reservados o emitidos.'', 1;

            SET @asiento_asignado = @codigo_asiento;
            IF @asiento_asignado IS NULL
            BEGIN

                DECLARE @semaforo SMALLINT;
                SELECT @semaforo = capacidad FROM ops.vuelo_cabina WITH (UPDLOCK, ROWLOCK)
                WHERE id_vuelo = @id_vuelo AND codigo_cabina = @cabina;
                SELECT TOP (1) @asiento_asignado = s.codigo_asiento
                FROM ops.vuelo AS v
                JOIN ops.avion AS a ON a.id_avion = v.id_avion
                JOIN ops.asiento_configuracion AS s ON s.id_configuracion = a.id_configuracion AND s.codigo_cabina = @cabina
                WHERE v.id_vuelo = @id_vuelo
                  AND NOT EXISTS (SELECT 1 FROM ven.tiquete AS t
                                  WHERE t.id_vuelo = @id_vuelo AND t.codigo_asiento = s.codigo_asiento
                                    AND t.codigo_estado IN (''RESERVADO'', ''EMITIDO'', ''USADO'', ''NO_PRESENTADO''))
                ORDER BY s.fila, s.letra;
            END;
            IF @asiento_asignado IS NULL THROW 50124, N''No quedan asientos libres en la cabina.'', 1;

            UPDATE ven.tiquete SET codigo_asiento = @asiento_asignado WHERE id_tiquete = @id_tiquete;
            IF @tran_propia = 1 COMMIT TRANSACTION;
            BREAK;
        END TRY
        BEGIN CATCH
            IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;

            IF ERROR_NUMBER() IN (2601, 2627) AND @codigo_asiento IS NULL AND @tran_propia = 1 AND @intento < 5
            BEGIN
                SET @intento += 1;
                CONTINUE;
            END;
            IF ERROR_NUMBER() IN (2601, 2627)
                THROW 50120, N''RN-12: el asiento ya está ocupado en este vuelo.'', 1;
            THROW;
        END CATCH;
    END;
END;';

-- E. 07_procedimientos, lote 7
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_registrar_pago
    @id_tiquete                 INT,
    @codigo_metodo              VARCHAR(12),
    @monto_usd                  DECIMAL(10,2),
    @id_localizacion_cobro      INT,
    @resultado                  VARCHAR(15)   = ''CONFIRMADO'',   
    @referencia_autorizacion    VARCHAR(30)   = NULL,
    @ultimos4_tarjeta           CHAR(4)       = NULL,
    @marca_tarjeta              VARCHAR(12)   = NULL,
    @motivo_rechazo             NVARCHAR(100) = NULL,
    @fecha_pago_utc             DATETIME2(0)  = NULL,
    @id_pago                    INT           = NULL OUTPUT,
    @saldo_pendiente_usd        DECIMAL(10,2) = NULL OUTPUT,
    @estado_tiquete             VARCHAR(15)   = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @fecha_pago_utc = ISNULL(@fecha_pago_utc, SYSUTCDATETIME());
    IF @resultado NOT IN (''CONFIRMADO'', ''FALLIDO'', ''PENDIENTE'')
        THROW 50130, N''El resultado del pago debe ser CONFIRMADO, FALLIDO o PENDIENTE.'', 1;
    IF @monto_usd IS NULL OR @monto_usd <= 0
        THROW 50131, N''El monto del pago debe ser mayor que cero.'', 1;
    IF @resultado = ''CONFIRMADO'' AND @referencia_autorizacion IS NULL
        SET @referencia_autorizacion = CONCAT(''AUT'', RIGHT(CONVERT(VARCHAR(20), CRYPT_GEN_RANDOM(5), 2), 10));
    IF @resultado = ''FALLIDO'' AND @motivo_rechazo IS NULL
        SET @motivo_rechazo = N''Rechazado por la entidad emisora'';

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @estado VARCHAR(15), @precio DECIMAL(10,2), @limite DATETIME2(0), @cobrado DECIMAL(12,2), @pendiente DECIMAL(12,2);
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;

        SELECT @estado = codigo_estado, @precio = precio_final_usd, @limite = fecha_limite_pago_utc
        FROM ven.tiquete WITH (UPDLOCK, ROWLOCK)
        WHERE id_tiquete = @id_tiquete;

        IF @estado IS NULL THROW 50132, N''El tiquete no existe.'', 1;
        IF @estado <> ''RESERVADO'' THROW 50133, N''El tiquete no tiene saldo pendiente (no está en estado RESERVADO).'', 1;
        IF @fecha_pago_utc > @limite THROW 50134, N''La reserva venció; el pago no se acepta.'', 1;

        SELECT @cobrado   = ISNULL(SUM(CASE WHEN codigo_estado = ''CONFIRMADO'' THEN monto_usd ELSE 0 END), 0),
               @pendiente = ISNULL(SUM(CASE WHEN codigo_estado = ''PENDIENTE''  THEN monto_usd ELSE 0 END), 0)
        FROM ven.pago WHERE id_tiquete = @id_tiquete;

        IF @resultado <> ''FALLIDO'' AND @monto_usd > @precio - @cobrado - @pendiente
        BEGIN
            DECLARE @msg NVARCHAR(400) = CONCAT(N''RN-37: el monto ('', @monto_usd, N'' USD) supera el saldo disponible para pagar ('',
                                                @precio - @cobrado - @pendiente, N'' USD).'');
            THROW 50135, @msg, 1;
        END;

        INSERT ven.pago (id_tiquete, codigo_metodo, id_localizacion_cobro, monto_usd, codigo_estado, fecha_creacion_utc,
                         fecha_resolucion_utc, referencia_autorizacion, ultimos4_tarjeta, marca_tarjeta, motivo_rechazo)
        VALUES (@id_tiquete, @codigo_metodo, @id_localizacion_cobro, @monto_usd, @resultado, @fecha_pago_utc,
                CASE WHEN @resultado = ''PENDIENTE'' THEN NULL ELSE @fecha_pago_utc END,
                CASE WHEN @resultado = ''FALLIDO'' THEN NULL ELSE @referencia_autorizacion END,
                @ultimos4_tarjeta, @marca_tarjeta,
                CASE WHEN @resultado = ''FALLIDO'' THEN @motivo_rechazo END);
        SET @id_pago = CAST(SCOPE_IDENTITY() AS INT);

        IF @resultado = ''CONFIRMADO'' AND @cobrado + @monto_usd = @precio
            UPDATE ven.tiquete SET codigo_estado = ''EMITIDO'', fecha_emision_utc = @fecha_pago_utc WHERE id_tiquete = @id_tiquete;

        SELECT @saldo_pendiente_usd = saldo_pendiente_usd, @estado_tiquete = codigo_estado
        FROM rpt.v_tiquete_financiero WHERE id_tiquete = @id_tiquete;

        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 8
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_resolver_pago
    @id_pago                    INT,
    @resultado                  VARCHAR(15),        
    @referencia_autorizacion    VARCHAR(30)   = NULL,
    @motivo_rechazo             NVARCHAR(100) = NULL,
    @fecha_resolucion_utc       DATETIME2(0)  = NULL,
    @estado_tiquete             VARCHAR(15)   = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @fecha_resolucion_utc = ISNULL(@fecha_resolucion_utc, SYSUTCDATETIME());
    IF @resultado NOT IN (''CONFIRMADO'', ''FALLIDO'', ''ANULADO'')
        THROW 50136, N''El resultado debe ser CONFIRMADO, FALLIDO o ANULADO.'', 1;

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @id_tiquete INT, @precio DECIMAL(10,2), @cobrado DECIMAL(12,2);
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;
        SELECT @id_tiquete = id_tiquete FROM ven.pago WHERE id_pago = @id_pago;
        IF @id_tiquete IS NULL THROW 50137, N''El pago no existe.'', 1;
        SELECT @precio = precio_final_usd FROM ven.tiquete WITH (UPDLOCK, ROWLOCK) WHERE id_tiquete = @id_tiquete;

        UPDATE ven.pago
           SET codigo_estado = @resultado,
               fecha_resolucion_utc = @fecha_resolucion_utc,
               referencia_autorizacion = CASE WHEN @resultado = ''CONFIRMADO''
                                              THEN ISNULL(@referencia_autorizacion, CONCAT(''AUT'', RIGHT(CONVERT(VARCHAR(20), CRYPT_GEN_RANDOM(5), 2), 10)))
                                              ELSE referencia_autorizacion END,
               motivo_rechazo = CASE WHEN @resultado = ''FALLIDO'' THEN ISNULL(@motivo_rechazo, N''Rechazado por la entidad emisora'') END
         WHERE id_pago = @id_pago;   

        SELECT @cobrado = ISNULL(SUM(monto_usd), 0) FROM ven.pago WHERE id_tiquete = @id_tiquete AND codigo_estado = ''CONFIRMADO'';
        IF @resultado = ''CONFIRMADO'' AND @cobrado = @precio
            UPDATE ven.tiquete SET codigo_estado = ''EMITIDO'', fecha_emision_utc = @fecha_resolucion_utc
             WHERE id_tiquete = @id_tiquete AND codigo_estado = ''RESERVADO'';
        SELECT @estado_tiquete = codigo_estado FROM ven.tiquete WHERE id_tiquete = @id_tiquete;
        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 9
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_cancelar_tiquete
    @id_tiquete             INT,
    @codigo_motivo          VARCHAR(15)   = ''VOLUNTARIA'',
    @fecha_cancelacion_utc  DATETIME2(0)  = NULL,
    @monto_reembolsado_usd  DECIMAL(10,2) = NULL OUTPUT,
    @monto_retenido_usd     DECIMAL(10,2) = NULL OUTPUT,
    @regla_aplicada         VARCHAR(20)   = NULL OUTPUT,
    @porcentaje_reembolso   DECIMAL(5,2)  = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @fecha_cancelacion_utc = ISNULL(@fecha_cancelacion_utc, SYSUTCDATETIME());
    IF NOT EXISTS (SELECT 1 FROM ref.motivo_cancelacion WHERE codigo_motivo = @codigo_motivo)
        THROW 50140, N''El motivo de cancelación no existe.'', 1;

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @estado VARCHAR(15), @cobrado DECIMAL(12,2);
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;

        SELECT @estado = codigo_estado FROM ven.tiquete WITH (UPDLOCK, ROWLOCK) WHERE id_tiquete = @id_tiquete;
        IF @estado IS NULL THROW 50141, N''El tiquete no existe.'', 1;
        IF @estado NOT IN (''RESERVADO'', ''EMITIDO'')
            THROW 50142, N''Solo se cancelan tiquetes en estado RESERVADO o EMITIDO.'', 1;

        SELECT @porcentaje_reembolso = porcentaje_reembolso, @regla_aplicada = regla_aplicada
        FROM ven.fn_politica_reembolso(@id_tiquete, @codigo_motivo, @fecha_cancelacion_utc);
        IF @porcentaje_reembolso IS NULL
            THROW 50143, N''No hay política de reembolso aplicable: el vuelo ya salió o la fecha de cancelación es posterior a la salida.'', 1;

        SELECT @cobrado = ISNULL(SUM(monto_usd), 0) FROM ven.pago WHERE id_tiquete = @id_tiquete AND codigo_estado = ''CONFIRMADO'';
        SET @monto_reembolsado_usd = CAST(ROUND(@cobrado * @porcentaje_reembolso / 100.0, 2) AS DECIMAL(10,2));
        SET @monto_retenido_usd = @cobrado - @monto_reembolsado_usd;

        UPDATE ven.tiquete
           SET codigo_estado = ''CANCELADO'', fecha_cancelacion_utc = @fecha_cancelacion_utc, codigo_motivo_cancelacion = @codigo_motivo
         WHERE id_tiquete = @id_tiquete;

        UPDATE ven.pago SET codigo_estado = ''ANULADO'', fecha_resolucion_utc = @fecha_cancelacion_utc
         WHERE id_tiquete = @id_tiquete AND codigo_estado = ''PENDIENTE'';

        IF @monto_reembolsado_usd > 0
        BEGIN
            WITH pagos AS (
                SELECT id_pago, monto_usd,
                       SUM(monto_usd) OVER (ORDER BY fecha_resolucion_utc DESC, id_pago DESC ROWS UNBOUNDED PRECEDING) AS acumulado
                FROM ven.pago
                WHERE id_tiquete = @id_tiquete AND codigo_estado = ''CONFIRMADO''
            )
            INSERT ven.reembolso (id_pago, monto_usd, fecha_reembolso_utc, codigo_motivo, porcentaje_aplicado, regla_aplicada, referencia)
            SELECT id_pago,
                   CASE WHEN acumulado <= @monto_reembolsado_usd THEN monto_usd
                        ELSE @monto_reembolsado_usd - (acumulado - monto_usd) END,
                   @fecha_cancelacion_utc, @codigo_motivo, @porcentaje_reembolso, @regla_aplicada, CONCAT(''RB'', id_pago)
            FROM pagos
            WHERE acumulado - monto_usd < @monto_reembolsado_usd;
        END;

        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 10
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_vencer_reservas
    @fecha_corte_utc    DATETIME2(0) = NULL,
    @tiquetes_vencidos  INT          = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @fecha_corte_utc = ISNULL(@fecha_corte_utc, SYSUTCDATETIME());
    SET @tiquetes_vencidos = 0;
    DECLARE @id INT, @limite DATETIME2(0);
    DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
        SELECT id_tiquete, fecha_limite_pago_utc FROM ven.tiquete
        WHERE codigo_estado = ''RESERVADO'' AND fecha_limite_pago_utc < @fecha_corte_utc
        ORDER BY fecha_limite_pago_utc, id_tiquete;
    OPEN cur;
    FETCH NEXT FROM cur INTO @id, @limite;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC ven.usp_cancelar_tiquete @id_tiquete = @id, @codigo_motivo = ''VENCIMIENTO'', @fecha_cancelacion_utc = @limite;
        SET @tiquetes_vencidos += 1;
        FETCH NEXT FROM cur INTO @id, @limite;
    END;
    CLOSE cur;
    DEALLOCATE cur;
END;';

-- E. 07_procedimientos, lote 11
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ven.usp_registrar_abordaje
    @id_tiquete INT,
    @presentado BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    UPDATE ven.tiquete
       SET codigo_estado = CASE WHEN @presentado = 1 THEN ''USADO'' ELSE ''NO_PRESENTADO'' END
     WHERE id_tiquete = @id_tiquete;   
    IF @@ROWCOUNT = 0 THROW 50144, N''El tiquete no existe.'', 1;
END;';

-- E. 07_procedimientos, lote 12
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ops.usp_generar_vuelos
    @fecha_desde    DATE,
    @fecha_hasta    DATE,
    @vuelos_creados INT = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    IF @fecha_desde IS NULL OR @fecha_hasta IS NULL OR @fecha_hasta < @fecha_desde
        THROW 50150, N''Rango de fechas no válido.'', 1;
    IF DATEDIFF(DAY, @fecha_desde, @fecha_hasta) > 400
        THROW 50151, N''El rango máximo es de 400 días por ejecución.'', 1;

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;

        WITH candidatos AS (
            SELECT p.id_programacion, p.numero_vuelo, p.duracion_programada_min, c.fecha,
                   lo.zona_horaria AS zona_origen, ld.zona_horaria AS zona_destino,
                   DATETIME2FROMPARTS(YEAR(c.fecha), MONTH(c.fecha), DAY(c.fecha),
                                      DATEPART(HOUR, p.hora_salida_local), DATEPART(MINUTE, p.hora_salida_local), 0, 0, 0) AS salida_local
            FROM ops.programacion AS p
            JOIN ops.ruta         AS r  ON r.id_ruta = p.id_ruta AND r.activa = 1
            JOIN ref.localizacion AS lo ON lo.id_localizacion = r.id_aeropuerto_origen
            JOIN ref.localizacion AS ld ON ld.id_localizacion = r.id_aeropuerto_destino
            CROSS APPLY ref.fn_calendario(
                CASE WHEN p.vigente_desde > @fecha_desde THEN p.vigente_desde ELSE @fecha_desde END,
                CASE WHEN ISNULL(p.vigente_hasta, ''99991231'') < @fecha_hasta THEN p.vigente_hasta ELSE @fecha_hasta END) AS c
            JOIN ops.programacion_dia AS pd ON pd.id_programacion = p.id_programacion AND pd.dia_semana = c.dia_semana_iso
            WHERE p.activa = 1
        ),
        horarios AS (

            SELECT id_programacion, numero_vuelo, fecha, zona_destino, duracion_programada_min,
                   salida_local AT TIME ZONE zona_origen AS salida
            FROM candidatos
        )
        INSERT ops.vuelo (id_programacion, salida_programada, llegada_programada)
        SELECT h.id_programacion, h.salida, DATEADD(MINUTE, h.duracion_programada_min, h.salida) AT TIME ZONE h.zona_destino
        FROM horarios AS h
        WHERE NOT EXISTS (SELECT 1 FROM ops.vuelo AS v
                          WHERE v.id_programacion = h.id_programacion AND v.fecha_salida_local = h.fecha)
        ORDER BY h.fecha, h.salida, h.numero_vuelo;   
        SET @vuelos_creados = @@ROWCOUNT;

        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 13
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ops.usp_sincronizar_inventario
    @id_vuelo INT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @capacidad TABLE (id_vuelo INT NOT NULL, codigo_cabina CHAR(3) NOT NULL, capacidad SMALLINT NOT NULL,
                              PRIMARY KEY (id_vuelo, codigo_cabina));
    INSERT @capacidad (id_vuelo, codigo_cabina, capacidad)
    SELECT v.id_vuelo, s.codigo_cabina, COUNT(*)
    FROM ops.vuelo AS v
    JOIN ops.avion AS a ON a.id_avion = v.id_avion
    JOIN ops.asiento_configuracion AS s ON s.id_configuracion = a.id_configuracion
    WHERE @id_vuelo IS NULL OR v.id_vuelo = @id_vuelo
    GROUP BY v.id_vuelo, s.codigo_cabina;

    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;
        UPDATE vc SET capacidad = c.capacidad
        FROM ops.vuelo_cabina AS vc
        JOIN @capacidad AS c ON c.id_vuelo = vc.id_vuelo AND c.codigo_cabina = vc.codigo_cabina
        WHERE vc.capacidad <> c.capacidad;              

        INSERT ops.vuelo_cabina (id_vuelo, codigo_cabina, capacidad)
        SELECT c.id_vuelo, c.codigo_cabina, c.capacidad
        FROM @capacidad AS c
        WHERE NOT EXISTS (SELECT 1 FROM ops.vuelo_cabina AS vc WHERE vc.id_vuelo = c.id_vuelo AND vc.codigo_cabina = c.codigo_cabina);
        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        IF ERROR_NUMBER() = 547 AND ERROR_MESSAGE() LIKE N''%ck_vuelo_cabina_capacidad%''
            THROW 50163, N''La nueva capacidad sería menor que las plazas ya vendidas.'', 1;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 14
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ops.usp_asignar_avion
    @id_vuelo   INT,
    @id_avion   SMALLINT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @estado_avion VARCHAR(15), @estado_vuelo VARCHAR(15);
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;

        SELECT @estado_avion = estado_operativo FROM ops.avion WITH (UPDLOCK, HOLDLOCK) WHERE id_avion = @id_avion;
        IF @estado_avion IS NULL THROW 50160, N''El avión no existe.'', 1;
        SELECT @estado_vuelo = codigo_estado FROM ops.vuelo WITH (UPDLOCK) WHERE id_vuelo = @id_vuelo;
        IF @estado_vuelo IS NULL THROW 50161, N''El vuelo no existe.'', 1;
        IF @estado_vuelo NOT IN (''PROGRAMADO'', ''DEMORADO'') THROW 50162, N''Solo se asignan aviones a vuelos programados o demorados.'', 1;

        UPDATE ops.vuelo SET id_avion = @id_avion WHERE id_vuelo = @id_vuelo;   
        EXEC ops.usp_sincronizar_inventario @id_vuelo = @id_vuelo;
        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 15
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE ops.usp_cambiar_estado_vuelo
    @id_vuelo               INT,
    @nuevo_estado           VARCHAR(15),
    @momento                DATETIMEOFFSET(0) = NULL,   
    @salida_estimada        DATETIMEOFFSET(0) = NULL,   
    @motivo_cancelacion     NVARCHAR(200)     = NULL,   
    @tiquetes_cancelados    INT               = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    SET @momento = ISNULL(@momento, SYSDATETIMEOFFSET());
    SET @tiquetes_cancelados = 0;
    DECLARE @tran_propia BIT = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    DECLARE @estado VARCHAR(15), @zona_origen VARCHAR(50), @zona_destino VARCHAR(50);
    BEGIN TRY
        IF @tran_propia = 1 BEGIN TRANSACTION;
        SELECT @estado = v.codigo_estado, @zona_origen = lo.zona_horaria, @zona_destino = ld.zona_horaria
        FROM ops.vuelo AS v WITH (UPDLOCK, ROWLOCK)
        JOIN ops.programacion AS p ON p.id_programacion = v.id_programacion
        JOIN ops.ruta AS r ON r.id_ruta = p.id_ruta
        JOIN ref.localizacion AS lo ON lo.id_localizacion = r.id_aeropuerto_origen
        JOIN ref.localizacion AS ld ON ld.id_localizacion = r.id_aeropuerto_destino
        WHERE v.id_vuelo = @id_vuelo;
        IF @estado IS NULL THROW 50170, N''El vuelo no existe.'', 1;

        IF @nuevo_estado = ''DEMORADO''
        BEGIN
            IF @salida_estimada IS NULL THROW 50171, N''Una demora requiere la nueva hora estimada de salida.'', 1;
            UPDATE ops.vuelo SET codigo_estado = ''DEMORADO'', salida_estimada = @salida_estimada AT TIME ZONE @zona_origen
             WHERE id_vuelo = @id_vuelo;
        END
        ELSE IF @nuevo_estado = ''EN_VUELO''
            UPDATE ops.vuelo SET codigo_estado = ''EN_VUELO'', salida_real = @momento AT TIME ZONE @zona_origen
             WHERE id_vuelo = @id_vuelo;
        ELSE IF @nuevo_estado = ''ATERRIZADO''
            UPDATE ops.vuelo SET codigo_estado = ''ATERRIZADO'', llegada_real = @momento AT TIME ZONE @zona_destino
             WHERE id_vuelo = @id_vuelo;
        ELSE IF @nuevo_estado = ''CANCELADO''
        BEGIN
            IF @motivo_cancelacion IS NULL THROW 50172, N''La cancelación de un vuelo requiere un motivo.'', 1;
            UPDATE ops.vuelo SET codigo_estado = ''CANCELADO'', motivo_cancelacion = @motivo_cancelacion
             WHERE id_vuelo = @id_vuelo;

            DECLARE @id INT, @fecha DATETIME2(0) = CONVERT(DATETIME2(0), SWITCHOFFSET(@momento, ''+00:00''));
            DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
                SELECT id_tiquete FROM ven.tiquete WHERE id_vuelo = @id_vuelo AND codigo_estado IN (''RESERVADO'', ''EMITIDO'');
            OPEN cur;
            FETCH NEXT FROM cur INTO @id;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                EXEC ven.usp_cancelar_tiquete @id_tiquete = @id, @codigo_motivo = ''VUELO_CANCELADO'', @fecha_cancelacion_utc = @fecha;
                SET @tiquetes_cancelados += 1;
                FETCH NEXT FROM cur INTO @id;
            END;
            CLOSE cur;
            DEALLOCATE cur;
        END
        ELSE
            THROW 50173, N''Estado de destino no válido (use DEMORADO, EN_VUELO, ATERRIZADO o CANCELADO).'', 1;

        IF @tran_propia = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @tran_propia = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;';

-- E. 07_procedimientos, lote 16
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_ocupacion_por_ruta
    @fecha_desde    DATE,
    @fecha_hasta    DATE,
    @codigo_cabina  CHAR(3) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT o.ruta, o.codigo_cabina,
           COUNT(*)                                                   AS vuelos,
           SUM(o.capacidad)                                           AS asientos_ofrecidos,
           SUM(o.usados)                                              AS pasajeros_volados,
           CAST(SUM(o.usados) * 1.0 / NULLIF(SUM(o.capacidad), 0) AS DECIMAL(7,4)) AS factor_ocupacion
    FROM rpt.v_ocupacion_vuelo_cabina AS o
    WHERE o.estado_vuelo = ''ATERRIZADO''
      AND o.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
      AND (@codigo_cabina IS NULL OR o.codigo_cabina = @codigo_cabina)
    GROUP BY o.ruta, o.codigo_cabina
    ORDER BY o.ruta, o.codigo_cabina;
END;';

-- E. 07_procedimientos, lote 17
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_resumen_financiero
    @fecha_desde DATE,
    @fecha_hasta DATE
AS
BEGIN
    SET NOCOUNT ON;
    WITH ventas AS (
        SELECT DATEFROMPARTS(YEAR(creado_utc), MONTH(creado_utc), 1) AS mes, COUNT(*) AS tiquetes, SUM(precio_final_usd) AS ventas_usd
        FROM ven.tiquete
        WHERE CAST(creado_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
        GROUP BY DATEFROMPARTS(YEAR(creado_utc), MONTH(creado_utc), 1)
    ), cobros AS (
        SELECT DATEFROMPARTS(YEAR(fecha_resolucion_utc), MONTH(fecha_resolucion_utc), 1) AS mes, SUM(monto_usd) AS cobros_usd
        FROM ven.pago
        WHERE codigo_estado = ''CONFIRMADO'' AND CAST(fecha_resolucion_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
        GROUP BY DATEFROMPARTS(YEAR(fecha_resolucion_utc), MONTH(fecha_resolucion_utc), 1)
    ), reembolsos AS (
        SELECT DATEFROMPARTS(YEAR(fecha_reembolso_utc), MONTH(fecha_reembolso_utc), 1) AS mes, SUM(monto_usd) AS reembolsos_usd
        FROM ven.reembolso
        WHERE CAST(fecha_reembolso_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
        GROUP BY DATEFROMPARTS(YEAR(fecha_reembolso_utc), MONTH(fecha_reembolso_utc), 1)
    ), meses AS (
        SELECT mes FROM ventas UNION SELECT mes FROM cobros UNION SELECT mes FROM reembolsos
    )
    SELECT m.mes,
           ISNULL(v.tiquetes, 0)                                  AS tiquetes_vendidos,
           ISNULL(v.ventas_usd, 0)                                AS ventas_usd,
           ISNULL(c.cobros_usd, 0)                                AS cobros_confirmados_usd,
           ISNULL(r.reembolsos_usd, 0)                            AS reembolsos_usd,
           ISNULL(c.cobros_usd, 0) - ISNULL(r.reembolsos_usd, 0)  AS cobro_neto_usd
    FROM meses AS m
    LEFT JOIN ventas     AS v ON v.mes = m.mes
    LEFT JOIN cobros     AS c ON c.mes = m.mes
    LEFT JOIN reembolsos AS r ON r.mes = m.mes
    ORDER BY m.mes;
END;';

-- E. 07_procedimientos, lote 18
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''07_procedimientos'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''07_procedimientos'', N''Procedimientos almacenados'');';

-- E. 08_seguridad, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;';

-- E. 08_seguridad, lote 2
EXEC sys.sp_executesql N'IF DATABASE_PRINCIPAL_ID(N''rol_analista'')    IS NULL CREATE ROLE rol_analista AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N''rol_ventas'')      IS NULL CREATE ROLE rol_ventas AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N''rol_operaciones'') IS NULL CREATE ROLE rol_operaciones AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N''rol_aplicacion'')  IS NULL CREATE ROLE rol_aplicacion AUTHORIZATION dbo;';

-- E. 08_seguridad, lote 3
EXEC sys.sp_executesql N'GRANT SELECT  ON SCHEMA::rpt TO rol_analista;
GRANT EXECUTE ON SCHEMA::rpt TO rol_analista;

GRANT EXECUTE ON OBJECT::ven.usp_registrar_persona        TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_registrar_cliente        TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_consultar_disponibilidad TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_emitir_tiquete           TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_asignar_asiento          TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_registrar_pago           TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_resolver_pago            TO rol_ventas;
GRANT EXECUTE ON OBJECT::ven.usp_cancelar_tiquete         TO rol_ventas;
GRANT SELECT  ON OBJECT::rpt.v_vuelo                      TO rol_ventas;
GRANT SELECT  ON OBJECT::rpt.v_ocupacion_vuelo_cabina     TO rol_ventas;
GRANT SELECT  ON OBJECT::rpt.v_tiquete_financiero         TO rol_ventas;

GRANT EXECUTE ON SCHEMA::ops TO rol_operaciones;
GRANT SELECT  ON SCHEMA::ops TO rol_operaciones;
GRANT SELECT  ON SCHEMA::rpt TO rol_operaciones;
GRANT EXECUTE ON OBJECT::ven.usp_registrar_abordaje TO rol_operaciones;
GRANT EXECUTE ON OBJECT::ven.usp_vencer_reservas    TO rol_operaciones;

GRANT EXECUTE ON SCHEMA::ven TO rol_aplicacion;
GRANT EXECUTE ON SCHEMA::ops TO rol_aplicacion;
GRANT EXECUTE ON SCHEMA::rpt TO rol_aplicacion;
GRANT SELECT  ON SCHEMA::rpt TO rol_aplicacion;
GRANT SELECT  ON SCHEMA::ref TO rol_aplicacion;
DENY  INSERT, UPDATE, DELETE ON SCHEMA::ven TO rol_aplicacion;
DENY  INSERT, UPDATE, DELETE ON SCHEMA::ops TO rol_aplicacion;';

-- E. 08_seguridad, lote 4
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''ven.persona'') AND name = N''email_contacto'')
    ALTER TABLE ven.persona ALTER COLUMN email_contacto ADD MASKED WITH (FUNCTION = ''email()'');
IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''ven.persona'') AND name = N''telefono'')
    ALTER TABLE ven.persona ALTER COLUMN telefono ADD MASKED WITH (FUNCTION = ''partial(0,"XXX-XXX-",4)'');

IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''ven.persona'') AND name = N''numero_documento'')
BEGIN
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N''ix_persona_documento'' AND object_id = OBJECT_ID(N''ven.persona''))
        DROP INDEX ix_persona_documento ON ven.persona;
    ALTER TABLE ven.persona ALTER COLUMN numero_documento ADD MASKED WITH (FUNCTION = ''partial(0,"XXXXXX",3)'');
    CREATE NONCLUSTERED INDEX ix_persona_documento ON ven.persona (numero_documento) WHERE numero_documento IS NOT NULL;
END;
IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''ven.persona'') AND name = N''fecha_nacimiento'')
    ALTER TABLE ven.persona ALTER COLUMN fecha_nacimiento ADD MASKED WITH (FUNCTION = ''default()'');
IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''ven.cliente'') AND name = N''email_acceso'')
    ALTER TABLE ven.cliente ALTER COLUMN email_acceso ADD MASKED WITH (FUNCTION = ''email()'');
IF NOT EXISTS (SELECT 1 FROM sys.masked_columns WHERE object_id = OBJECT_ID(N''rh.empleado'') AND name = N''salario_anual_usd'')
    ALTER TABLE rh.empleado ALTER COLUMN salario_anual_usd ADD MASKED WITH (FUNCTION = ''default()'');';

-- E. 08_seguridad, lote 5
EXEC sys.sp_executesql N'IF DATABASE_PRINCIPAL_ID(N''usr_demo_analista'') IS NULL CREATE USER usr_demo_analista WITHOUT LOGIN;
IF DATABASE_PRINCIPAL_ID(N''usr_demo_aplicacion'') IS NULL CREATE USER usr_demo_aplicacion WITHOUT LOGIN;
IF IS_ROLEMEMBER(N''rol_analista'', N''usr_demo_analista'') = 0 ALTER ROLE rol_analista ADD MEMBER usr_demo_analista;
IF IS_ROLEMEMBER(N''rol_aplicacion'', N''usr_demo_aplicacion'') = 0 ALTER ROLE rol_aplicacion ADD MEMBER usr_demo_aplicacion;';

-- E. 08_seguridad, lote 6
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''08_seguridad'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''08_seguridad'', N''Roles, permisos y enmascaramiento'');';

-- E. 09_datos_referencia, lote 1
EXEC sys.sp_executesql N'SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
SET XACT_ABORT ON;';

-- E. 09_datos_referencia, lote 2
EXEC sys.sp_executesql N'INSERT ref.pais (codigo_pais, nombre)
SELECT v.codigo, v.nombre
FROM (VALUES (''US'', N''Estados Unidos''), (''MX'', N''México''), (''CA'', N''Canadá''), (''CO'', N''Colombia''), (''PE'', N''Perú''),
             (''ES'', N''España''), (''GB'', N''Reino Unido''), (''DE'', N''Alemania''), (''BR'', N''Brasil''), (''AR'', N''Argentina''),
             (''CL'', N''Chile''), (''FR'', N''Francia''), (''JP'', N''Japón''), (''IN'', N''India''), (''CN'', N''China''),
             (''PH'', N''Filipinas''), (''KR'', N''Corea del Sur''), (''DO'', N''República Dominicana''), (''EC'', N''Ecuador''),
             (''VE'', N''Venezuela'')) AS v (codigo, nombre)
WHERE NOT EXISTS (SELECT 1 FROM ref.pais AS p WHERE p.codigo_pais = v.codigo);

INSERT ref.estado_eeuu (codigo_estado, nombre)
SELECT v.codigo, v.nombre
FROM (VALUES (''AL'', N''Alabama''), (''AK'', N''Alaska''), (''AZ'', N''Arizona''), (''AR'', N''Arkansas''), (''CA'', N''California''),
             (''CO'', N''Colorado''), (''CT'', N''Connecticut''), (''DE'', N''Delaware''), (''DC'', N''District of Columbia''),
             (''FL'', N''Florida''), (''GA'', N''Georgia''), (''HI'', N''Hawaii''), (''ID'', N''Idaho''), (''IL'', N''Illinois''),
             (''IN'', N''Indiana''), (''IA'', N''Iowa''), (''KS'', N''Kansas''), (''KY'', N''Kentucky''), (''LA'', N''Louisiana''),
             (''ME'', N''Maine''), (''MD'', N''Maryland''), (''MA'', N''Massachusetts''), (''MI'', N''Michigan''), (''MN'', N''Minnesota''),
             (''MS'', N''Mississippi''), (''MO'', N''Missouri''), (''MT'', N''Montana''), (''NE'', N''Nebraska''), (''NV'', N''Nevada''),
             (''NH'', N''New Hampshire''), (''NJ'', N''New Jersey''), (''NM'', N''New Mexico''), (''NY'', N''New York''),
             (''NC'', N''North Carolina''), (''ND'', N''North Dakota''), (''OH'', N''Ohio''), (''OK'', N''Oklahoma''), (''OR'', N''Oregon''),
             (''PA'', N''Pennsylvania''), (''RI'', N''Rhode Island''), (''SC'', N''South Carolina''), (''SD'', N''South Dakota''),
             (''TN'', N''Tennessee''), (''TX'', N''Texas''), (''UT'', N''Utah''), (''VT'', N''Vermont''), (''VA'', N''Virginia''),
             (''WA'', N''Washington''), (''WV'', N''West Virginia''), (''WI'', N''Wisconsin''), (''WY'', N''Wyoming'')) AS v (codigo, nombre)
WHERE NOT EXISTS (SELECT 1 FROM ref.estado_eeuu AS e WHERE e.codigo_estado = v.codigo);

INSERT ref.zona_horaria (nombre_windows, nombre_iana, descripcion, observa_horario_verano)
SELECT v.w, v.i, v.d, v.dst
FROM (VALUES (''Eastern Standard Time'',     ''America/New_York'',    N''Hora del Este (ET)'', 1),
             (''Central Standard Time'',     ''America/Chicago'',     N''Hora del Centro (CT)'', 1),
             (''Mountain Standard Time'',    ''America/Denver'',      N''Hora de la Montaña (MT)'', 1),
             (''US Mountain Standard Time'', ''America/Phoenix'',     N''Hora de la Montaña sin horario de verano (Arizona)'', 0),
             (''Pacific Standard Time'',     ''America/Los_Angeles'', N''Hora del Pacífico (PT)'', 1),
             (''Alaskan Standard Time'',     ''America/Anchorage'',   N''Hora de Alaska (AKT)'', 1),
             (''Hawaiian Standard Time'',    ''Pacific/Honolulu'',    N''Hora de Hawái-Aleutianas sin horario de verano'', 0)) AS v (w, i, d, dst)
WHERE NOT EXISTS (SELECT 1 FROM ref.zona_horaria AS z WHERE z.nombre_windows = v.w);

INSERT ref.cabina (codigo_cabina, nombre, descripcion, piezas_equipaje_bodega, peso_max_equipaje_kg, acceso_sala_vip, orden_abordaje)
SELECT v.c, v.n, v.d, v.p, v.k, v.s, v.o
FROM (VALUES (''VIP'', N''Cabina VIP'', N''Asientos amplios, embarque prioritario, comida a bordo y acceso a sala VIP'', 2, 32, 1, 1),
             (''ECO'', N''Cabina económica'', N''Asiento estándar; equipaje de bodega con cargo adicional'', 0, 23, 0, 2)) AS v (c, n, d, p, k, s, o)
WHERE NOT EXISTS (SELECT 1 FROM ref.cabina AS c WHERE c.codigo_cabina = v.c);

INSERT ref.metodo_pago (codigo_metodo, nombre, es_tarjeta, permite_web, permite_fisico)
SELECT v.c, v.n, v.t, v.w, v.f
FROM (VALUES (''TC'', N''Tarjeta de crédito'', 1, 1, 1), (''TD'', N''Tarjeta de débito'', 1, 1, 1),
             (''EFECTIVO'', N''Efectivo'', 0, 0, 1), (''BILLETERA'', N''Billetera digital'', 0, 1, 1)) AS v (c, n, t, w, f)
WHERE NOT EXISTS (SELECT 1 FROM ref.metodo_pago AS m WHERE m.codigo_metodo = v.c);

INSERT ref.estado_vuelo (codigo_estado, descripcion, es_estado_inicial, es_final)
SELECT v.c, v.d, v.i, v.f
FROM (VALUES (''PROGRAMADO'', N''Vuelo generado, aún no ha salido'', 1, 0),
             (''DEMORADO'',   N''Salida retrasada respecto de la hora programada'', 0, 0),
             (''EN_VUELO'',   N''Vuelo en el aire'', 0, 0),
             (''ATERRIZADO'', N''Vuelo completado'', 0, 1),
             (''CANCELADO'',  N''Vuelo cancelado por la aerolínea'', 0, 1)) AS v (c, d, i, f)
WHERE NOT EXISTS (SELECT 1 FROM ref.estado_vuelo AS e WHERE e.codigo_estado = v.c);

INSERT ref.estado_tiquete (codigo_estado, descripcion, es_estado_inicial, es_final, ocupa_inventario)
SELECT v.c, v.d, v.i, v.f, v.o
FROM (VALUES (''RESERVADO'',     N''Plaza retenida; pago pendiente o parcial'', 1, 0, 1),
             (''EMITIDO'',       N''Pagado en su totalidad'', 0, 0, 1),
             (''USADO'',         N''El pasajero voló'', 0, 1, 1),
             (''NO_PRESENTADO'', N''El pasajero no se presentó'', 0, 1, 1),
             (''CANCELADO'',     N''Tiquete cancelado; la plaza se libera'', 0, 1, 0)) AS v (c, d, i, f, o)
WHERE NOT EXISTS (SELECT 1 FROM ref.estado_tiquete AS e WHERE e.codigo_estado = v.c);

INSERT ref.estado_pago (codigo_estado, descripcion, es_estado_inicial, es_final, es_cobro)
SELECT v.c, v.d, v.i, v.f, v.k
FROM (VALUES (''PENDIENTE'',  N''En espera de la respuesta de la pasarela'', 1, 0, 0),
             (''CONFIRMADO'', N''Cobro aprobado'', 1, 1, 1),
             (''FALLIDO'',    N''Cobro rechazado'', 1, 1, 0),
             (''ANULADO'',    N''Pago pendiente anulado (p. ej., por cancelación)'', 0, 1, 0)) AS v (c, d, i, f, k)
WHERE NOT EXISTS (SELECT 1 FROM ref.estado_pago AS e WHERE e.codigo_estado = v.c);

INSERT ref.transicion_vuelo (estado_origen, estado_destino)
SELECT v.o, v.d
FROM (VALUES (''PROGRAMADO'', ''DEMORADO''), (''PROGRAMADO'', ''EN_VUELO''), (''PROGRAMADO'', ''CANCELADO''),
             (''DEMORADO'', ''DEMORADO''), (''DEMORADO'', ''EN_VUELO''), (''DEMORADO'', ''CANCELADO''),
             (''EN_VUELO'', ''ATERRIZADO'')) AS v (o, d)
WHERE NOT EXISTS (SELECT 1 FROM ref.transicion_vuelo AS t WHERE t.estado_origen = v.o AND t.estado_destino = v.d);

INSERT ref.transicion_tiquete (estado_origen, estado_destino)
SELECT v.o, v.d
FROM (VALUES (''RESERVADO'', ''EMITIDO''), (''RESERVADO'', ''CANCELADO''), (''EMITIDO'', ''USADO''),
             (''EMITIDO'', ''NO_PRESENTADO''), (''EMITIDO'', ''CANCELADO'')) AS v (o, d)
WHERE NOT EXISTS (SELECT 1 FROM ref.transicion_tiquete AS t WHERE t.estado_origen = v.o AND t.estado_destino = v.d);

INSERT ref.transicion_pago (estado_origen, estado_destino)
SELECT v.o, v.d
FROM (VALUES (''PENDIENTE'', ''CONFIRMADO''), (''PENDIENTE'', ''FALLIDO''), (''PENDIENTE'', ''ANULADO'')) AS v (o, d)
WHERE NOT EXISTS (SELECT 1 FROM ref.transicion_pago AS t WHERE t.estado_origen = v.o AND t.estado_destino = v.d);

INSERT ref.motivo_cancelacion (codigo_motivo, descripcion, iniciado_por, reembolso_total)
SELECT v.c, v.d, v.i, v.r
FROM (VALUES (''VOLUNTARIA'',      N''Cancelación solicitada por el cliente'', ''CLIENTE'', 0),
             (''VUELO_CANCELADO'', N''La aerolínea canceló el vuelo'', ''AEROLINEA'', 1),
             (''VENCIMIENTO'',     N''La reserva no se pagó dentro del plazo'', ''SISTEMA'', 1)) AS v (c, d, i, r)
WHERE NOT EXISTS (SELECT 1 FROM ref.motivo_cancelacion AS m WHERE m.codigo_motivo = v.c);

INSERT ref.parametro (clave, valor, tipo_dato, descripcion)
SELECT v.k, v.v, v.t, v.d
FROM (VALUES (''CODIGO_AEROLINEA'',          ''XX'',   ''TEXT'', N''Designador ficticio usado en los códigos de vuelo''),
             (''PREFIJO_TIQUETE'',           ''000'',  ''TEXT'', N''Prefijo ficticio de 3 dígitos del número de tiquete''),
             (''MONEDA'',                    ''USD'',  ''TEXT'', N''Moneda base de todos los importes''),
             (''MIN_ROTACION_AVION'',        ''40'',   ''INT'',  N''Minutos mínimos en tierra entre dos vuelos del mismo avión''),
             (''MIN_DESCANSO_TRIPULACION'',  ''30'',   ''INT'',  N''Minutos mínimos entre dos vuelos del mismo tripulante''),
             (''ASIENTOS_POR_TRIPULANTE_CABINA'', ''50'', ''INT'', N''Supuesto académico: un tripulante de cabina por cada 50 asientos''),
             (''HORAS_LIMITE_PAGO'',         ''72'',   ''INT'',  N''Horas para completar el pago de una reserva''),
             (''HORAS_CIERRE_VENTA'',        ''3'',    ''INT'',  N''Horas antes de la salida en que cierra la venta y vence la reserva''),
             (''INICIO_VENTAS'',             ''2026-07-01'', ''DATE'', N''Fecha de apertura de ventas''),
             (''INICIO_OPERACIONES'',        ''2026-09-01'', ''DATE'', N''Fecha del primer vuelo'')) AS v (k, v, t, d)
WHERE NOT EXISTS (SELECT 1 FROM ref.parametro AS p WHERE p.clave = v.k);

INSERT ref.mensaje_error (numero_error, mensaje, regla)
SELECT v.n, v.m, v.r
FROM (VALUES
 (50001, N''Vigencias solapadas de un mismo número de vuelo'', ''RN-03''),
 (50002, N''Tarifas con vigencias solapadas para la misma ruta y cabina'', ''RN-18''),
 (50003, N''Tarifa ya usada: no se modifican ruta, cabina, precio ni inicio de vigencia'', ''RN-20''),
 (50004, N''La vigencia de una tarifa no puede terminar antes de ventas realizadas'', ''RN-20''),
 (50005, N''Descuento ya aplicado: no se modifican sus condiciones'', ''RN-21''),
 (50010, N''Los datos de una compra son inmutables'', NULL),
 (50011, N''Localización no habilitada para vender'', NULL),
 (50012, N''Venta web sin vendedor; venta física con vendedor'', ''RN-32''),
 (50013, N''El vendedor no estaba vigente en la fecha de la compra'', ''RN-32''),
 (50020, N''Sin disponibilidad en la cabina (sobreventa)'', ''RN-11''),
 (50021, N''Estado inicial de vuelo no válido'', ''RN-08''),
 (50022, N''El vuelo no corresponde a la programación'', ''RN-04''),
 (50023, N''Transición de vuelo no válida'', ''RN-08''),
 (50024, N''La programación de un vuelo no puede cambiar'', NULL),
 (50025, N''Cambio de avión con tiquetes activos hacia otra configuración'', ''SUP-03''),
 (50026, N''Desfase horario distinto al de la zona del aeropuerto'', ''RN-06''),
 (50027, N''Avión no activo'', ''RN-10''),
 (50028, N''Solape de vuelos del mismo avión'', ''RN-09''),
 (50029, N''Tripulación incompleta para iniciar el vuelo'', ''RN-35''),
 (50031, N''Rol de tripulación incompatible con el cargo'', ''RN-33''),
 (50032, N''Empleado no vigente en la fecha del vuelo'', ''RN-33''),
 (50033, N''El vuelo no admite cambios de tripulación'', ''RN-33''),
 (50034, N''Solape de vuelos del mismo tripulante'', ''RN-33''),
 (50039, N''Los tiquetes no se eliminan'', ''RN-29''),
 (50040, N''Datos comerciales del tiquete inmutables'', ''RN-19''),
 (50041, N''Estado inicial de tiquete no válido'', ''RN-08''),
 (50042, N''Transición de tiquete no válida'', ''RN-08''),
 (50043, N''Vuelo cerrado a la venta o venta posterior a la salida'', ''RN-31''),
 (50044, N''Tarifa no aplicable al vuelo o a la fecha de venta'', ''RN-17''),
 (50045, N''Descuento no aplicable'', ''RN-21''),
 (50046, N''Pasajero sin datos obligatorios'', ''RN-41''),
 (50047, N''Emisión sin pago total'', ''RN-24''),
 (50048, N''Cambio de estado del tiquete incompatible con el vuelo'', ''RN-08''),
 (50049, N''Asiento inexistente, de otra cabina o fuera de plazo'', ''RN-13''),
 (50050, N''Datos del pago inmutables'', NULL),
 (50051, N''Transición de pago no válida'', ''RN-08''),
 (50052, N''Estado inicial de pago no válido'', ''RN-08''),
 (50053, N''Pago sobre un tiquete que no está reservado'', ''RN-42''),
 (50054, N''Pagos confirmados superiores al precio final'', ''RN-23''),
 (50055, N''Método de pago no permitido en la localización'', ''RN-25''),
 (50056, N''Pago anterior a la venta'', NULL),
 (50059, N''Los pagos no se eliminan'', ''RN-29''),
 (50060, N''Los reembolsos son inmutables'', ''RN-29''),
 (50061, N''Reembolso sobre un pago o tiquete no válido'', ''RN-28''),
 (50062, N''Reembolsos superiores al pago'', ''RN-28''),
 (50069, N''Los reembolsos no se eliminan'', ''RN-29''),
 (50101, N''Nombres y apellidos obligatorios'', NULL),
 (50102, N''La persona no existe'', NULL),
 (50103, N''La persona ya es cliente'', NULL),
 (50104, N''Correo de acceso duplicado'', ''RN-38''),
 (50110, N''Fecha de venta en el futuro'', NULL),
 (50111, N''El vuelo no existe'', NULL),
 (50112, N''Vuelo cerrado a la venta'', ''RN-31''),
 (50113, N''Cabina inexistente en el vuelo'', ''RN-15''),
 (50114, N''Sin tarifa vigente'', ''RN-17''),
 (50115, N''Descuento inexistente o no aplicable'', ''RN-21''),
 (50116, N''No se pudo generar un localizador único'', NULL),
 (50117, N''El comprador no existe'', NULL),
 (50118, N''Compra no válida para agregar el tiquete'', NULL),
 (50119, N''Ventas cerradas antes de la salida'', ''SUP-07''),
 (50120, N''Asiento ocupado'', ''RN-12''),
 (50121, N''Pasajero con tiquete activo en el vuelo'', ''RN-14''),
 (50122, N''El tiquete no existe'', NULL),
 (50123, N''Estado del tiquete no admite asiento'', NULL),
 (50124, N''Sin asientos libres en la cabina'', NULL),
 (50130, N''Resultado de pago no válido'', NULL),
 (50131, N''Monto de pago no válido'', NULL),
 (50132, N''El tiquete no existe'', NULL),
 (50133, N''El tiquete no tiene saldo pendiente'', NULL),
 (50134, N''Reserva vencida'', ''SUP-07''),
 (50135, N''Monto superior al saldo pendiente'', ''RN-37''),
 (50136, N''Resultado de resolución no válido'', NULL),
 (50137, N''El pago no existe'', NULL),
 (50140, N''Motivo de cancelación inexistente'', NULL),
 (50141, N''El tiquete no existe'', NULL),
 (50142, N''Estado del tiquete no admite cancelación'', NULL),
 (50143, N''Sin política de reembolso aplicable'', ''RN-36''),
 (50144, N''El tiquete no existe'', NULL),
 (50150, N''Rango de fechas no válido'', NULL),
 (50151, N''Rango de generación demasiado amplio'', NULL),
 (50160, N''El avión no existe'', NULL),
 (50161, N''El vuelo no existe'', NULL),
 (50162, N''Estado del vuelo no admite asignación'', NULL),
 (50163, N''Capacidad menor que las plazas vendidas'', ''RN-11''),
 (50170, N''El vuelo no existe'', NULL),
 (50171, N''Demora sin hora estimada'', NULL),
 (50172, N''Cancelación de vuelo sin motivo'', NULL),
 (50173, N''Estado de destino no válido'', ''RN-08''),
 (50190, N''La carga sintética requiere tablas transaccionales vacías'', NULL)) AS v (n, m, r)
WHERE NOT EXISTS (SELECT 1 FROM ref.mensaje_error AS e WHERE e.numero_error = v.n);';

-- E. 09_datos_referencia, lote 3
EXEC sys.sp_executesql N'INSERT ref.localizacion (codigo_localizacion, tipo_localizacion, nombre, ciudad, codigo_estado, zona_horaria, url, vende_tiquetes, fecha_apertura)
SELECT v.cod, v.tipo, v.nombre, v.ciudad, v.estado, v.zona, v.url, v.vende, ''20260601''
FROM (VALUES
 (''AER-JFK'', ''AER'', N''John F. Kennedy International Airport'',            N''New York'',          ''NY'', ''Eastern Standard Time'',     NULL, 1),
 (''AER-BOS'', ''AER'', N''Boston Logan International Airport'',               N''Boston'',            ''MA'', ''Eastern Standard Time'',     NULL, 1),
 (''AER-ATL'', ''AER'', N''Hartsfield-Jackson Atlanta International Airport'', N''Atlanta'',           ''GA'', ''Eastern Standard Time'',     NULL, 1),
 (''AER-MIA'', ''AER'', N''Miami International Airport'',                      N''Miami'',             ''FL'', ''Eastern Standard Time'',     NULL, 1),
 (''AER-MCO'', ''AER'', N''Orlando International Airport'',                    N''Orlando'',           ''FL'', ''Eastern Standard Time'',     NULL, 1),
 (''AER-ORD'', ''AER'', N''Chicago O''''Hare International Airport'',            N''Chicago'',           ''IL'', ''Central Standard Time'',     NULL, 1),
 (''AER-DFW'', ''AER'', N''Dallas Fort Worth International Airport'',          N''Dallas-Fort Worth'', ''TX'', ''Central Standard Time'',     NULL, 1),
 (''AER-DEN'', ''AER'', N''Denver International Airport'',                     N''Denver'',            ''CO'', ''Mountain Standard Time'',    NULL, 1),
 (''AER-PHX'', ''AER'', N''Phoenix Sky Harbor International Airport'',         N''Phoenix'',           ''AZ'', ''US Mountain Standard Time'', NULL, 1),
 (''AER-LAS'', ''AER'', N''Harry Reid International Airport'',                 N''Las Vegas'',         ''NV'', ''Pacific Standard Time'',     NULL, 1),
 (''AER-LAX'', ''AER'', N''Los Angeles International Airport'',                N''Los Angeles'',       ''CA'', ''Pacific Standard Time'',     NULL, 1),
 (''AER-SEA'', ''AER'', N''Seattle-Tacoma International Airport'',             N''Seattle'',           ''WA'', ''Pacific Standard Time'',     NULL, 1),
 (''AER-HNL'', ''AER'', N''Daniel K. Inouye International Airport'',           N''Honolulu'',          ''HI'', ''Hawaiian Standard Time'',    NULL, 1),
 (''OFI-NYC'', ''OFI'', N''Oficina de ventas Nueva York (centro)'',            N''New York'',          ''NY'', ''Eastern Standard Time'',     NULL, 1),
 (''OFI-CHI'', ''OFI'', N''Oficina de ventas Chicago (centro)'',               N''Chicago'',           ''IL'', ''Central Standard Time'',     NULL, 1),
 (''OFI-MIA'', ''OFI'', N''Oficina de ventas Miami (centro)'',                 N''Miami'',             ''FL'', ''Eastern Standard Time'',     NULL, 1),
 (''OFI-HQ'',  ''OFI'', N''Sede corporativa'',                                 N''Dallas'',            ''TX'', ''Central Standard Time'',     NULL, 0),
 (''WEB-SITIO'',''WEB'', N''Sitio web de ventas'',                             NULL, NULL, NULL, ''https://www.aerolinea-ejemplo.test'', 1),
 (''WEB-APP'', ''WEB'', N''Aplicación móvil'',                                 NULL, NULL, NULL, ''https://app.aerolinea-ejemplo.test'', 1)
) AS v (cod, tipo, nombre, ciudad, estado, zona, url, vende)
WHERE NOT EXISTS (SELECT 1 FROM ref.localizacion AS l WHERE l.codigo_localizacion = v.cod);

INSERT ref.aeropuerto (id_localizacion, codigo_iata, codigo_icao, latitud, longitud, es_base_operaciones)
SELECT l.id_localizacion, v.iata, v.icao, v.lat, v.lon, v.base
FROM (VALUES (''JFK'', ''KJFK'', 40.641300,  -73.778100, 1), (''BOS'', ''KBOS'', 42.365600,  -71.009600, 0),
             (''ATL'', ''KATL'', 33.640700,  -84.427700, 0), (''MIA'', ''KMIA'', 25.795900,  -80.287000, 0),
             (''MCO'', ''KMCO'', 28.431200,  -81.308100, 0), (''ORD'', ''KORD'', 41.974200,  -87.907300, 1),
             (''DFW'', ''KDFW'', 32.899800,  -97.040300, 0), (''DEN'', ''KDEN'', 39.856100, -104.673700, 0),
             (''PHX'', ''KPHX'', 33.434200, -112.011600, 0), (''LAS'', ''KLAS'', 36.084000, -115.153700, 0),
             (''LAX'', ''KLAX'', 33.941600, -118.408500, 1), (''SEA'', ''KSEA'', 47.450200, -122.308800, 0),
             (''HNL'', ''PHNL'', 21.324500, -157.925100, 0)) AS v (iata, icao, lat, lon, base)
JOIN ref.localizacion AS l ON l.codigo_localizacion = CONCAT(''AER-'', v.iata)
WHERE NOT EXISTS (SELECT 1 FROM ref.aeropuerto AS a WHERE a.codigo_iata = v.iata);';

-- E. 09_datos_referencia, lote 4
EXEC sys.sp_executesql N'INSERT ref.modelo_avion (fabricante, modelo, alcance_millas, velocidad_crucero_mph)
SELECT v.f, v.m, v.a, v.s
FROM (VALUES (N''Airbus'', N''A321neo'', 4000, 540), (N''Airbus'', N''A320neo'', 3900, 540),
             (N''Boeing'', N''737-800'', 3300, 530), (N''Embraer'', N''E175'', 2500, 515)) AS v (f, m, a, s)
WHERE NOT EXISTS (SELECT 1 FROM ref.modelo_avion AS x WHERE x.fabricante = v.f AND x.modelo = v.m);

INSERT ops.configuracion_asientos (codigo_configuracion, id_modelo, descripcion)
SELECT v.c, m.id_modelo, v.d
FROM (VALUES (''A21N-20V168E'', N''A321neo'', N''20 VIP (2-2) + 168 económica (3-3)''),
             (''A20N-12V150E'', N''A320neo'', N''12 VIP (2-2) + 150 económica (3-3)''),
             (''B738-16V144E'', N''737-800'', N''16 VIP (2-2) + 144 económica (3-3)''),
             (''E175-12V64E'',  N''E175'',    N''12 VIP (1-2) + 64 económica (2-2)'')) AS v (c, modelo, d)
JOIN ref.modelo_avion AS m ON m.modelo = v.modelo
WHERE NOT EXISTS (SELECT 1 FROM ops.configuracion_asientos AS x WHERE x.codigo_configuracion = v.c);

DECLARE @definicion TABLE (codigo_configuracion VARCHAR(20), codigo_cabina CHAR(3), fila_desde TINYINT, fila_hasta TINYINT,
                           letras VARCHAR(8), ventanas VARCHAR(8), pasillos VARCHAR(8), filas_salida VARCHAR(20));
INSERT @definicion VALUES
 (''A21N-20V168E'', ''VIP'',  1,  5, ''ACDF'',   ''AF'', ''CD'', ''''),
 (''A21N-20V168E'', ''ECO'', 10, 38, ''ABCDEF'', ''AF'', ''CD'', ''|12|25|''),
 (''A20N-12V150E'', ''VIP'',  1,  3, ''ACDF'',   ''AF'', ''CD'', ''''),
 (''A20N-12V150E'', ''ECO'', 10, 35, ''ABCDEF'', ''AF'', ''CD'', ''|12|14|''),
 (''B738-16V144E'', ''VIP'',  1,  4, ''ACDF'',   ''AF'', ''CD'', ''''),
 (''B738-16V144E'', ''ECO'', 10, 34, ''ABCDEF'', ''AF'', ''CD'', ''|15|16|''),
 (''E175-12V64E'',  ''VIP'',  1,  4, ''ACD'',    ''AD'', ''AC'', ''''),
 (''E175-12V64E'',  ''ECO'', 10, 26, ''ABCD'',   ''AD'', ''BC'', ''|12|'');

WITH numeros AS (SELECT TOP (60) CAST(ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS TINYINT) AS n FROM sys.all_columns),
     asientos AS (
        SELECT c.id_configuracion, d.codigo_cabina, f.n AS fila, SUBSTRING(d.letras, k.n, 1) AS letra, d.ventanas, d.pasillos, d.filas_salida
        FROM @definicion AS d
        JOIN ops.configuracion_asientos AS c ON c.codigo_configuracion = d.codigo_configuracion
        JOIN numeros AS f ON f.n BETWEEN d.fila_desde AND d.fila_hasta AND f.n <> 13
        JOIN numeros AS k ON k.n <= LEN(d.letras))
INSERT ops.asiento_configuracion (id_configuracion, codigo_asiento, fila, letra, codigo_cabina, es_ventana, es_pasillo, es_salida_emergencia)
SELECT a.id_configuracion, CONCAT(a.fila, a.letra), a.fila, a.letra, a.codigo_cabina,
       CASE WHEN CHARINDEX(a.letra, a.ventanas) > 0 THEN 1 ELSE 0 END,
       CASE WHEN CHARINDEX(a.letra, a.pasillos) > 0 THEN 1 ELSE 0 END,
       CASE WHEN CHARINDEX(CONCAT(''|'', a.fila, ''|''), a.filas_salida) > 0 THEN 1 ELSE 0 END
FROM asientos AS a
WHERE NOT EXISTS (SELECT 1 FROM ops.asiento_configuracion AS s
                  WHERE s.id_configuracion = a.id_configuracion AND s.codigo_asiento = CONCAT(a.fila, a.letra));

INSERT ops.avion (matricula, numero_serie, id_configuracion, fecha_fabricacion, fecha_incorporacion, estado_operativo, id_aeropuerto_base)
SELECT v.mat, v.msn, c.id_configuracion, v.fab, v.inc, v.estado, a.id_localizacion
FROM (VALUES
 (''N321XA'', ''MSN-A21N-0101'', ''A21N-20V168E'', ''20220315'', ''20260601'', ''ACTIVO'', ''JFK''),
 (''N322XA'', ''MSN-A21N-0102'', ''A21N-20V168E'', ''20220610'', ''20260601'', ''ACTIVO'', ''JFK''),
 (''N323XA'', ''MSN-A21N-0103'', ''A21N-20V168E'', ''20230120'', ''20260615'', ''ACTIVO'', ''LAX''),
 (''N324XA'', ''MSN-A21N-0104'', ''A21N-20V168E'', ''20230505'', ''20260615'', ''ACTIVO'', ''JFK''),
 (''N325XA'', ''MSN-A21N-0105'', ''A21N-20V168E'', ''20240212'', ''20260701'', ''ACTIVO'', ''LAX''),
 (''N201XA'', ''MSN-A20N-0201'', ''A20N-12V150E'', ''20210908'', ''20260601'', ''ACTIVO'', ''JFK''),
 (''N202XA'', ''MSN-A20N-0202'', ''A20N-12V150E'', ''20211122'', ''20260601'', ''ACTIVO'', ''JFK''),
 (''N203XA'', ''MSN-A20N-0203'', ''A20N-12V150E'', ''20220704'', ''20260615'', ''ACTIVO'', ''JFK''),
 (''N204XA'', ''MSN-A20N-0204'', ''A20N-12V150E'', ''20230830'', ''20260701'', ''ACTIVO'', ''ORD''),
 (''N801XA'', ''MSN-B738-0801'', ''B738-16V144E'', ''20160412'', ''20260601'', ''ACTIVO'', ''ORD''),
 (''N802XA'', ''MSN-B738-0802'', ''B738-16V144E'', ''20170219'', ''20260601'', ''ACTIVO'', ''ORD''),
 (''N803XA'', ''MSN-B738-0803'', ''B738-16V144E'', ''20180611'', ''20260615'', ''ACTIVO'', ''ORD''),
 (''N804XA'', ''MSN-B738-0804'', ''B738-16V144E'', ''20181025'', ''20260701'', ''ACTIVO'', ''ORD''),
 (''N805XA'', ''MSN-B738-0805'', ''B738-16V144E'', ''20150930'', ''20260701'', ''MANTENIMIENTO'', ''ORD''),
 (''N175XA'', ''MSN-E175-1751'', ''E175-12V64E'',  ''20190514'', ''20260601'', ''ACTIVO'', ''JFK''),
 (''N176XA'', ''MSN-E175-1752'', ''E175-12V64E'',  ''20191203'', ''20260615'', ''ACTIVO'', ''JFK''),
 (''N177XA'', ''MSN-E175-1753'', ''E175-12V64E'',  ''20200716'', ''20260701'', ''ACTIVO'', ''ORD'')
) AS v (mat, msn, cfg, fab, inc, estado, base)
JOIN ops.configuracion_asientos AS c ON c.codigo_configuracion = v.cfg
JOIN ref.aeropuerto AS a ON a.codigo_iata = v.base
WHERE NOT EXISTS (SELECT 1 FROM ops.avion AS x WHERE x.matricula = v.mat);';

-- E. 09_datos_referencia, lote 5
EXEC sys.sp_executesql N'INSERT ops.ruta (id_aeropuerto_origen, id_aeropuerto_destino, distancia_millas, activa, fecha_inicio_operacion)
SELECT o.id_localizacion, d.id_localizacion,
       CAST(ROUND(geography::Point(o.latitud, o.longitud, 4326).STDistance(geography::Point(d.latitud, d.longitud, 4326)) / 1609.344, 0) AS SMALLINT),
       v.activa, CASE WHEN v.activa = 1 THEN CAST(''20260901'' AS DATE) END
FROM (VALUES (''JFK'',''LAX'',1), (''LAX'',''JFK'',1), (''JFK'',''MIA'',1), (''MIA'',''JFK'',1), (''BOS'',''MCO'',1), (''MCO'',''BOS'',1),
             (''JFK'',''ORD'',1), (''ORD'',''JFK'',1), (''ORD'',''DFW'',1), (''DFW'',''ORD'',1), (''ATL'',''DEN'',1), (''DEN'',''ATL'',1),
             (''ATL'',''MIA'',1), (''MIA'',''ATL'',1), (''DFW'',''PHX'',1), (''PHX'',''DFW'',1), (''DEN'',''SEA'',1), (''SEA'',''DEN'',1),
             (''LAX'',''HNL'',1), (''HNL'',''LAX'',1), (''JFK'',''LAS'',1), (''LAS'',''JFK'',1),
             (''BOS'',''ORD'',0), (''ORD'',''BOS'',0)) AS v (o, d, activa)       
JOIN ref.aeropuerto AS o ON o.codigo_iata = v.o
JOIN ref.aeropuerto AS d ON d.codigo_iata = v.d
WHERE NOT EXISTS (SELECT 1 FROM ops.ruta AS r WHERE r.id_aeropuerto_origen = o.id_localizacion AND r.id_aeropuerto_destino = d.id_localizacion);

DECLARE @programa TABLE (numero SMALLINT, o CHAR(3), d CHAR(3), hora TIME(0), duracion SMALLINT, desde DATE, hasta DATE NULL, dias VARCHAR(14));
INSERT @programa VALUES
 (101, ''JFK'',''LAX'',''07:00'',370,''20260901'',NULL,''D''), (102, ''LAX'',''JFK'',''13:00'',315,''20260901'',NULL,''D''),
 (112, ''JFK'',''LAX'',''08:30'',370,''20260901'',NULL,''D''), (111, ''LAX'',''JFK'',''22:30'',315,''20260901'',NULL,''D''),
 (201, ''JFK'',''MIA'',''06:30'',170,''20260901'',NULL,''D''), (202, ''MIA'',''JFK'',''10:30'',165,''20260901'',NULL,''D''),
 (203, ''JFK'',''MIA'',''15:00'',170,''20260901'',NULL,''D''), (204, ''MIA'',''JFK'',''19:00'',165,''20260901'',NULL,''D''),
 (301, ''BOS'',''MCO'',''07:15'',180,''20260901'',NULL,''1,4,5,6,7''), (302, ''MCO'',''BOS'',''11:45'',165,''20260901'',NULL,''1,4,5,6,7''),
 (401, ''JFK'',''ORD'',''07:00'',130,''20260901'',NULL,''D''), (402, ''ORD'',''JFK'',''10:15'',115,''20260901'',NULL,''D''),
 (403, ''JFK'',''ORD'',''14:30'',130,''20260901'',NULL,''D''), (404, ''ORD'',''JFK'',''18:00'',115,''20260901'',NULL,''D''),
 (501, ''ORD'',''DFW'',''08:00'',135,''20260901'',NULL,''D''), (502, ''DFW'',''ORD'',''12:00'',125,''20260901'',NULL,''D''),
 (601, ''ATL'',''DEN'',''09:00'',195,''20260901'',NULL,''D''), (602, ''DEN'',''ATL'',''13:30'',170,''20260901'',NULL,''D''),
 (701, ''ATL'',''MIA'',''07:30'',105,''20260901'',NULL,''D''), (702, ''MIA'',''ATL'',''10:30'',105,''20260901'',NULL,''D''),
 (703, ''ATL'',''MIA'',''16:00'',105,''20260901'',''20261130'',''D''), (704, ''MIA'',''ATL'',''19:15'',105,''20260901'',''20261130'',''D''),
 (703, ''ATL'',''MIA'',''16:30'',105,''20261201'',NULL,''D''), (704, ''MIA'',''ATL'',''19:45'',105,''20261201'',NULL,''D''),
 (801, ''DFW'',''PHX'',''09:30'',145,''20260901'',NULL,''D''), (802, ''PHX'',''DFW'',''13:30'',130,''20260901'',NULL,''D''),
 (901, ''DEN'',''SEA'',''08:15'',170,''20260901'',NULL,''D''), (902, ''SEA'',''DEN'',''12:45'',150,''20260901'',NULL,''D''),
 (1001,''LAX'',''HNL'',''08:00'',380,''20260901'',NULL,''D''), (1002,''HNL'',''LAX'',''13:00'',325,''20260901'',NULL,''D''),
 (1101,''JFK'',''LAS'',''09:00'',340,''20260901'',NULL,''D''), (1102,''LAS'',''JFK'',''14:30'',290,''20260901'',NULL,''D'');

INSERT ops.programacion (numero_vuelo, id_ruta, hora_salida_local, duracion_programada_min, vigente_desde, vigente_hasta)
SELECT p.numero, r.id_ruta, p.hora, p.duracion, p.desde, p.hasta
FROM @programa AS p
JOIN ref.aeropuerto AS o ON o.codigo_iata = p.o
JOIN ref.aeropuerto AS d ON d.codigo_iata = p.d
JOIN ops.ruta AS r ON r.id_aeropuerto_origen = o.id_localizacion AND r.id_aeropuerto_destino = d.id_localizacion
WHERE NOT EXISTS (SELECT 1 FROM ops.programacion AS x WHERE x.numero_vuelo = p.numero AND x.vigente_desde = p.desde);

WITH dias AS (SELECT CAST(n AS TINYINT) AS dia FROM (VALUES (1),(2),(3),(4),(5),(6),(7)) AS v (n))
INSERT ops.programacion_dia (id_programacion, dia_semana)
SELECT x.id_programacion, dias.dia
FROM @programa AS p
JOIN ops.programacion AS x ON x.numero_vuelo = p.numero AND x.vigente_desde = p.desde
JOIN dias ON p.dias = ''D'' OR CHARINDEX(CONCAT('','', dias.dia, '',''), CONCAT('','', p.dias, '','')) > 0
WHERE NOT EXISTS (SELECT 1 FROM ops.programacion_dia AS pd WHERE pd.id_programacion = x.id_programacion AND pd.dia_semana = dias.dia);';

-- E. 09_datos_referencia, lote 6
EXEC sys.sp_executesql N'DECLARE @factor TABLE (o CHAR(3), d CHAR(3), f2 DECIMAL(5,3), f3 DECIMAL(5,3) NULL);
INSERT @factor VALUES
 (''JFK'',''LAX'',1.080,1.150), (''LAX'',''JFK'',1.080,1.150), (''LAX'',''HNL'',1.080,1.150), (''HNL'',''LAX'',1.080,1.150),
 (''ATL'',''MIA'',0.950,NULL),  (''MIA'',''ATL'',0.950,NULL);

WITH base AS (
    SELECT r.id_ruta, ao.codigo_iata AS o, ad.codigo_iata AS d,
           CAST(ROUND(49 + 0.105 * r.distancia_millas, 0) - 0.01 AS DECIMAL(10,2)) AS eco_v1
    FROM ops.ruta AS r
    JOIN ref.aeropuerto AS ao ON ao.id_localizacion = r.id_aeropuerto_origen
    JOIN ref.aeropuerto AS ad ON ad.id_localizacion = r.id_aeropuerto_destino
    WHERE r.activa = 1
), versiones AS (
    SELECT b.id_ruta, c.cabina, v.version,
           CASE v.version WHEN 1 THEN ''20260701'' WHEN 2 THEN ''20260916'' ELSE ''20261020'' END AS desde,
           CASE WHEN v.version = 1 THEN CAST(''20260915'' AS DATE)
                WHEN v.version = 2 AND f.f3 IS NOT NULL THEN CAST(''20261019'' AS DATE) END AS hasta,
           CASE c.cabina WHEN ''ECO'' THEN b.eco_v1 ELSE CAST(ROUND(b.eco_v1 * 2.75, 0) - 0.01 AS DECIMAL(10,2)) END AS p1,
           CASE v.version WHEN 1 THEN 1.000
                          WHEN 2 THEN ISNULL(f.f2, CASE c.cabina WHEN ''ECO'' THEN 1.080 ELSE 1.050 END)
                          ELSE f.f3 END AS factor
    FROM base AS b
    CROSS JOIN (VALUES (''ECO''), (''VIP'')) AS c (cabina)
    CROSS JOIN (VALUES (1), (2), (3)) AS v (version)
    LEFT JOIN @factor AS f ON f.o = b.o AND f.d = b.d
    WHERE v.version < 3 OR f.f3 IS NOT NULL
)
INSERT ven.tarifa (id_ruta, codigo_cabina, precio_base_usd, vigente_desde, vigente_hasta)
SELECT v.id_ruta, v.cabina,
       CASE WHEN v.version = 1 THEN v.p1 ELSE CAST(ROUND(v.p1 * v.factor, 0) - 0.01 AS DECIMAL(10,2)) END,
       v.desde, v.hasta
FROM versiones AS v
WHERE NOT EXISTS (SELECT 1 FROM ven.tarifa AS t WHERE t.id_ruta = v.id_ruta AND t.codigo_cabina = v.cabina AND t.vigente_desde = v.desde)
ORDER BY v.id_ruta, v.cabina, v.version;';

-- E. 09_datos_referencia, lote 7
EXEC sys.sp_executesql N'INSERT ven.descuento (codigo_descuento, descripcion, porcentaje, vigente_desde, vigente_hasta, solo_clientes_registrados, codigo_cabina, dias_anticipacion_min)
SELECT v.c, v.d, v.p, v.desde, v.hasta, v.reg, v.cab, v.ant
FROM (VALUES
 (''LANZAMIENTO20'', N''Promoción de lanzamiento en cabina económica'',            20.00, ''20260701'', ''20260731'', 0, ''ECO'', NULL),
 (''CLIENTE10'',     N''Beneficio para clientes registrados'',                       10.00, ''20260701'', ''20261231'', 1, NULL,  NULL),
 (''ANTICIPA15'',    N''Compra anticipada (30 días o más) en económica'',            15.00, ''20260701'', ''20261231'', 0, ''ECO'', 30),
 (''VIPPLUS5'',      N''Beneficio VIP para clientes registrados'',                    5.00, ''20260801'', ''20261231'', 1, ''VIP'', NULL),
 (''OTONO12'',       N''Campaña de otoño'',                                          12.00, ''20260920'', ''20261010'', 0, NULL,  NULL),
 (''INVIERNO25'',    N''Campaña de invierno (aún no vigente en los datos)'',         25.00, ''20261201'', ''20270131'', 0, NULL,  NULL)
) AS v (c, d, p, desde, hasta, reg, cab, ant)
WHERE NOT EXISTS (SELECT 1 FROM ven.descuento AS x WHERE x.codigo_descuento = v.c);

INSERT ven.politica_cancelacion (codigo_cabina, horas_antes_min, porcentaje_reembolso)
SELECT v.c, v.h, v.p
FROM (VALUES (''ECO'', 0, 0.00), (''ECO'', 72, 50.00), (''ECO'', 336, 80.00),
             (''VIP'', 0, 30.00), (''VIP'', 24, 70.00), (''VIP'', 168, 90.00)) AS v (c, h, p)
WHERE NOT EXISTS (SELECT 1 FROM ven.politica_cancelacion AS x WHERE x.codigo_cabina = v.c AND x.horas_antes_min = v.h);';

-- E. 09_datos_referencia, lote 8
EXEC sys.sp_executesql N'INSERT rh.departamento (codigo_departamento, nombre)
SELECT v.c, v.n
FROM (VALUES (''OPS'', N''Operaciones de vuelo''), (''CAB'', N''Servicio a bordo''), (''COM'', N''Comercial y ventas''),
             (''MNT'', N''Mantenimiento''), (''ADM'', N''Administración y finanzas''), (''TEC'', N''Tecnología'')) AS v (c, n)
WHERE NOT EXISTS (SELECT 1 FROM rh.departamento AS d WHERE d.codigo_departamento = v.c);

INSERT rh.cargo (codigo_cargo, nombre, codigo_departamento, categoria_tripulacion)
SELECT v.c, v.n, v.d, v.t
FROM (VALUES (''GERENTE'', N''Gerente'', ''ADM'', NULL), (''PILOTO_CAP'', N''Capitán'', ''OPS'', ''TECNICA''),
             (''PILOTO_FO'', N''Primer oficial'', ''OPS'', ''TECNICA''), (''TCP_JEFE'', N''Jefe de cabina'', ''CAB'', ''CABINA''),
             (''TCP'', N''Auxiliar de vuelo'', ''CAB'', ''CABINA''), (''AGENTE_VTA'', N''Agente de ventas'', ''COM'', NULL),
             (''SUP_VTA'', N''Supervisor de ventas'', ''COM'', NULL), (''PLANIF'', N''Planificador de operaciones'', ''OPS'', NULL),
             (''TEC_MNT'', N''Técnico de mantenimiento'', ''MNT'', NULL), (''ANALISTA'', N''Analista comercial'', ''COM'', NULL),
             (''DBA'', N''Administrador de base de datos'', ''TEC'', NULL)) AS v (c, n, d, t)
WHERE NOT EXISTS (SELECT 1 FROM rh.cargo AS x WHERE x.codigo_cargo = v.c);

IF NOT EXISTS (SELECT 1 FROM rh.empleado)
BEGIN
    DECLARE @nombres TABLE (k INT PRIMARY KEY, nombre NVARCHAR(30));
    INSERT @nombres VALUES (0,N''James''),(1,N''María''),(2,N''Robert''),(3,N''Patricia''),(4,N''John''),(5,N''Jennifer''),(6,N''Michael''),
        (7,N''Linda''),(8,N''David''),(9,N''Elizabeth''),(10,N''William''),(11,N''Barbara''),(12,N''Richard''),(13,N''Susan''),(14,N''José''),
        (15,N''Jessica''),(16,N''Thomas''),(17,N''Sarah''),(18,N''Carlos''),(19,N''Ana''),(20,N''Luis''),(21,N''Carmen''),(22,N''Juan''),
        (23,N''Sofía''),(24,N''Miguel''),(25,N''Lucía''),(26,N''Daniel''),(27,N''Valentina''),(28,N''Emily''),(29,N''Andrew''),(30,N''Olivia''),
        (31,N''Ethan''),(32,N''Grace''),(33,N''Noah''),(34,N''Chloe''),(35,N''Kevin''),(36,N''Isabella''),(37,N''Brian''),(38,N''Ming''),(39,N''Priya'');
    DECLARE @apellidos TABLE (k INT PRIMARY KEY, apellido NVARCHAR(30));
    INSERT @apellidos VALUES (0,N''Smith''),(1,N''Johnson''),(2,N''Williams''),(3,N''Brown''),(4,N''Jones''),(5,N''García''),(6,N''Miller''),
        (7,N''Davis''),(8,N''Rodríguez''),(9,N''Martínez''),(10,N''Hernández''),(11,N''López''),(12,N''González''),(13,N''Wilson''),
        (14,N''Anderson''),(15,N''Thomas''),(16,N''Taylor''),(17,N''Moore''),(18,N''Jackson''),(19,N''Martin''),(20,N''Lee''),(21,N''Pérez''),
        (22,N''Thompson''),(23,N''White''),(24,N''Harris''),(25,N''Sánchez''),(26,N''Clark''),(27,N''Ramírez''),(28,N''Lewis''),
        (29,N''Robinson''),(30,N''Walker''),(31,N''Young''),(32,N''Allen''),(33,N''King''),(34,N''Wright''),(35,N''Scott''),(36,N''Torres''),
        (37,N''Nguyen''),(38,N''Hill''),(39,N''Flores'');

    DECLARE @puntos TABLE (orden INT PRIMARY KEY, id_localizacion INT);
    INSERT @puntos SELECT ROW_NUMBER() OVER (ORDER BY codigo_localizacion), id_localizacion
    FROM ref.localizacion WHERE tipo_localizacion IN (''AER'', ''OFI'') AND vende_tiquetes = 1;
    DECLARE @bases TABLE (orden INT PRIMARY KEY, id_localizacion INT);
    INSERT @bases SELECT v.o, l.id_localizacion
    FROM (VALUES (0,''AER-JFK''),(1,''AER-ORD''),(2,''AER-LAX''),(3,''AER-ATL''),(4,''AER-DFW''),(5,''AER-DEN'')) AS v (o, c)
    JOIN ref.localizacion AS l ON l.codigo_localizacion = v.c;
    DECLARE @hq INT = (SELECT id_localizacion FROM ref.localizacion WHERE codigo_localizacion = ''OFI-HQ'');

    WITH n AS (SELECT TOP (353) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS i FROM sys.all_columns),
    plan_cargo AS (
        SELECT i,
               CASE WHEN i <= 4 THEN ''GERENTE'' WHEN i <= 56 THEN ''PILOTO_CAP'' WHEN i <= 108 THEN ''PILOTO_FO''
                    WHEN i <= 160 THEN ''TCP_JEFE'' WHEN i <= 300 THEN ''TCP'' WHEN i <= 332 THEN ''AGENTE_VTA''
                    WHEN i <= 335 THEN ''SUP_VTA'' WHEN i <= 339 THEN ''PLANIF'' WHEN i <= 349 THEN ''TEC_MNT''
                    WHEN i <= 352 THEN ''ANALISTA'' ELSE ''DBA'' END AS cargo
        FROM n)
    INSERT rh.empleado (numero_empleado, nombres, apellidos, fecha_nacimiento, email_corporativo, telefono,
                        fecha_contratacion, fecha_terminacion, codigo_cargo, id_localizacion_base, salario_anual_usd)
    SELECT CONCAT(''E'', RIGHT(CONCAT(''00000'', p.i), 5)),
           nm.nombre, ap.apellido,
           DATEADD(DAY, -(9500 + (p.i * 137) % 9000 + CASE WHEN p.cargo LIKE ''PILOTO%'' OR p.cargo = ''GERENTE'' THEN 2500 ELSE 0 END), CAST(''20260101'' AS DATE)),
           CONCAT(''e'', RIGHT(CONCAT(''00000'', p.i), 5), ''@aerolinea-ejemplo.test''),
           CONCAT(''+1-202-555-01'', RIGHT(CONCAT(''0'', p.i % 100), 2)),
           DATEADD(DAY, (p.i * 13) % 120, CAST(''20260301'' AS DATE)),
           CASE WHEN p.i IN (330, 332) THEN CAST(''20260831'' AS DATE) END,      
           p.cargo,
           CASE WHEN p.cargo = ''AGENTE_VTA'' THEN (SELECT id_localizacion FROM @puntos WHERE orden = (p.i - 301) / 2 + 1)
                WHEN p.cargo IN (''PILOTO_CAP'', ''PILOTO_FO'', ''TCP_JEFE'', ''TCP'', ''TEC_MNT'') THEN (SELECT id_localizacion FROM @bases WHERE orden = p.i % 6)
                WHEN p.cargo = ''SUP_VTA'' THEN (SELECT id_localizacion FROM ref.localizacion
                                               WHERE codigo_localizacion = CASE p.i WHEN 333 THEN ''OFI-NYC'' WHEN 334 THEN ''OFI-CHI'' ELSE ''OFI-MIA'' END)
                ELSE @hq END,
           CASE p.cargo WHEN ''GERENTE'' THEN 180000 WHEN ''PILOTO_CAP'' THEN 210000 WHEN ''PILOTO_FO'' THEN 120000
                        WHEN ''TCP_JEFE'' THEN 62000 WHEN ''TCP'' THEN 48000 WHEN ''AGENTE_VTA'' THEN 42000
                        WHEN ''SUP_VTA'' THEN 58000 WHEN ''PLANIF'' THEN 75000 WHEN ''TEC_MNT'' THEN 70000
                        WHEN ''ANALISTA'' THEN 80000 ELSE 115000 END + (p.i % 7) * 1000
    FROM plan_cargo AS p
    JOIN @nombres   AS nm ON nm.k = (p.i * 7) % 40
    JOIN @apellidos AS ap ON ap.k = (p.i * 11 + p.i / 40) % 40
    ORDER BY p.i;

    UPDATE e SET id_supervisor = CASE
        WHEN e.numero_empleado = ''E00001'' THEN NULL
        WHEN e.codigo_cargo IN (''GERENTE'', ''SUP_VTA'', ''ANALISTA'', ''DBA'') THEN (SELECT id_empleado FROM rh.empleado WHERE numero_empleado = CASE WHEN e.codigo_cargo = ''GERENTE'' THEN ''E00001'' ELSE ''E00003'' END)
        WHEN e.codigo_cargo IN (''PILOTO_CAP'', ''PILOTO_FO'', ''TCP_JEFE'', ''TCP'', ''PLANIF'', ''TEC_MNT'') THEN (SELECT id_empleado FROM rh.empleado WHERE numero_empleado = ''E00002'')
        WHEN e.codigo_cargo = ''AGENTE_VTA'' THEN (SELECT id_empleado FROM rh.empleado WHERE numero_empleado = CONCAT(''E00'', 333 + (CAST(RIGHT(e.numero_empleado, 3) AS INT) % 3)))
        END
    FROM rh.empleado AS e;
END;';

-- E. 09_datos_referencia, lote 9
EXEC sys.sp_executesql N'IF NOT EXISTS (SELECT 1 FROM adm.registro_despliegue WHERE script = ''09_datos_referencia'')
    INSERT adm.registro_despliegue (script, descripcion) VALUES (''09_datos_referencia'', N''Catálogos, red, flota, programación, tarifas y personal'');';

-- F. CARGA TRANSACCIONAL SINTÉTICA MEDIANTE PROCEDIMIENTOS DEL MODELO

-- F. Carga SQL autónoma
EXEC sys.sp_executesql N'SET NOCOUNT ON;
DECLARE @corte DATETIME2(0)=''2026-11-01T00:00:00'';
INSERT ref.parametro(clave,valor,tipo_dato,descripcion)
VALUES(''FECHA_CORTE_DATOS'',''2026-11-01T00:00:00'',''DATETIME'',N''Corte fijo de la muestra SQL'');

DECLARE @mapa TABLE(n INT PRIMARY KEY,id_persona INT NOT NULL);
DECLARE @n INT=1,@persona INT,@nombre NVARCHAR(60),@email VARCHAR(120),@doc VARCHAR(20),@viajero CHAR(10);
WHILE @n<=80
BEGIN
 SET @nombre=CONCAT(N''Persona sintética '',@n);
 SET @email=CONCAT(''persona'',@n,''@example.com'');
 SET @doc=CONCAT(''DEMO'',RIGHT(CONCAT(''000000'',@n),6));
 SET @persona=NULL;
 EXEC ven.usp_registrar_persona @nombres=@nombre,@apellidos=N''Muestra SQL'',
  @fecha_nacimiento=''1990-05-15'',@genero=''X'',@email_contacto=@email,
  @codigo_pais_nacionalidad=''US'',@tipo_documento=''PASAPORTE'',
  @numero_documento=@doc,@codigo_pais_documento=''US'',@id_persona=@persona OUTPUT;
 INSERT @mapa VALUES(@n,@persona);
 IF @n<=40 OR @n>=78
 BEGIN
  SET @viajero=CONCAT(''VF'',RIGHT(CONCAT(''00000000'',@n),8));
  INSERT ven.cliente(id_persona,numero_viajero,email_acceso,fecha_registro_utc,nivel_lealtad)
  VALUES(@persona,@viajero,@email,''2026-07-01T00:00:00'',''BASICO'');
 END;
 SET @n+=1;
END;
ALTER SEQUENCE ven.seq_numero_viajero RESTART WITH 1000;

DECLARE @plan TABLE(n INT PRIMARY KEY,numero SMALLINT,fecha DATE,tiquetes INT,demora INT,cancelar BIT,id_vuelo INT NULL);
INSERT @plan(n,numero,fecha,tiquetes,demora,cancelar) VALUES
(1,201,''20260907'',60,0,0),(2,401,''20260908'',45,25,0),
(3,701,''20260909'',30,55,0),(4,201,''20260910'',16,5,0),
(5,401,''20261005'',68,18,0),(6,701,''20261006'',35,0,0),
(7,201,''20261007'',20,35,0),(8,401,''20261008'',50,0,1),
(9,701,''20261101'',26,0,0),(10,201,''20261102'',18,0,0),
(11,401,''20261103'',12,0,0),(12,701,''20261104'',8,0,0);
DECLARE @avion SMALLINT=(SELECT id_avion FROM ops.avion WHERE matricula=''N175XA'');
DECLARE @cfg SMALLINT=(SELECT id_configuracion FROM ops.avion WHERE id_avion=@avion);
DECLARE @capitan INT=(SELECT MIN(id_empleado) FROM rh.empleado WHERE codigo_cargo=''PILOTO_CAP'');
DECLARE @oficial INT=(SELECT MIN(id_empleado) FROM rh.empleado WHERE codigo_cargo=''PILOTO_FO'');
DECLARE @jefe INT=(SELECT MIN(id_empleado) FROM rh.empleado WHERE codigo_cargo=''TCP_JEFE'');
DECLARE @aux INT=(SELECT MIN(id_empleado) FROM rh.empleado WHERE codigo_cargo=''TCP'');
DECLARE @web INT=(SELECT id_localizacion FROM ref.localizacion WHERE tipo_localizacion=''WEB'' AND codigo_localizacion=''WEB-OFICIAL'');
IF @web IS NULL SELECT @web=MIN(id_localizacion) FROM ref.localizacion WHERE tipo_localizacion=''WEB'';
DECLARE @oficina INT=(SELECT id_localizacion FROM ref.localizacion WHERE codigo_localizacion=''OFI-NYC'');
DECLARE @vendedor INT=(SELECT MIN(id_empleado) FROM rh.empleado WHERE codigo_cargo=''AGENTE_VTA'' AND id_localizacion_base=@oficina);
IF @avion IS NULL OR @capitan IS NULL OR @oficial IS NULL OR @jefe IS NULL OR @aux IS NULL OR @web IS NULL OR @oficina IS NULL OR @vendedor IS NULL
 THROW 51983,N''Faltan referencias requeridas por la muestra SQL.'',1;

DECLARE @i INT=1,@pno SMALLINT,@fecha DATE,@num INT,@demora INT,@cancelar BIT,
 @prog INT,@salida DATETIMEOFFSET(0),@llegada DATETIMEOFFSET(0),@salidaLocal DATETIME2(0),
 @hora TIME(0),@dur INT,@zo VARCHAR(50),@zd VARCHAR(50),@vuelo INT,
 @j INT,@cab CHAR(3),@pasajero INT,@comprador INT,@loc INT,@vend INT,
 @venta DATETIME2(0),@momentoPago DATETIME2(0),@momentoCancel DATETIME2(0),
 @idCompra INT,@idTiquete INT,@precio DECIMAL(10,2),@mitad DECIMAL(10,2),@resto DECIMAL(10,2),
 @desc VARCHAR(20),@metodo VARCHAR(12),@ultimos4 CHAR(4),@marca VARCHAR(12),@asiento VARCHAR(4),@ord INT,@abordado BIT,
 @realSalida DATETIMEOFFSET(0),@realLlegada DATETIMEOFFSET(0),@ref VARCHAR(30);
WHILE @i<=12
BEGIN
 SELECT @pno=numero,@fecha=fecha,@num=tiquetes,@demora=demora,@cancelar=cancelar FROM @plan WHERE n=@i;
 SELECT @prog=p.id_programacion,@hora=p.hora_salida_local,@dur=p.duracion_programada_min,
 @zo=lo.zona_horaria,@zd=ld.zona_horaria
 FROM ops.programacion p JOIN ops.ruta r ON r.id_ruta=p.id_ruta
 JOIN ref.localizacion lo ON lo.id_localizacion=r.id_aeropuerto_origen
 JOIN ref.localizacion ld ON ld.id_localizacion=r.id_aeropuerto_destino
 WHERE p.numero_vuelo=@pno AND @fecha BETWEEN p.vigente_desde AND ISNULL(p.vigente_hasta,''99991231'');
 IF NOT EXISTS(SELECT 1 FROM ops.programacion_dia WHERE id_programacion=@prog
  AND dia_semana=DATEDIFF(DAY,CONVERT(DATE,''19000101''),@fecha)%7+1)
  THROW 51984,N''Fecha de muestra incompatible con programación semanal.'',1;
 SET @salidaLocal=DATETIME2FROMPARTS(YEAR(@fecha),MONTH(@fecha),DAY(@fecha),DATEPART(HOUR,@hora),DATEPART(MINUTE,@hora),0,0,0);
 SET @salida=@salidaLocal AT TIME ZONE @zo;
 SET @llegada=DATEADD(MINUTE,@dur,@salida) AT TIME ZONE @zd;
 INSERT ops.vuelo(id_programacion,salida_programada,llegada_programada)
 VALUES(@prog,@salida,@llegada);
 SET @vuelo=CAST(SCOPE_IDENTITY() AS INT);
 UPDATE @plan SET id_vuelo=@vuelo WHERE n=@i;
 EXEC ops.usp_asignar_avion @id_vuelo=@vuelo,@id_avion=@avion;
 INSERT ops.asignacion_tripulacion(id_vuelo,id_empleado,rol_vuelo)
 VALUES(@vuelo,@capitan,''CAPITAN''),(@vuelo,@oficial,''PRIMER_OFICIAL''),
 (@vuelo,@jefe,''JEFE_CABINA''),(@vuelo,@aux,''AUXILIAR_VUELO'');

 SET @j=1;
 WHILE @j<=@num
 BEGIN
  SET @cab=CASE WHEN @j<=8 THEN ''VIP'' ELSE ''ECO'' END;
  SELECT @pasajero=id_persona FROM @mapa WHERE n=(@j+@i-2)%70+1;
  SET @comprador=@pasajero;
  IF @j%4=0 SELECT @comprador=id_persona FROM @mapa WHERE n=1;
  SET @loc=CASE WHEN @j%3=0 THEN @oficina ELSE @web END;
  SET @vend=CASE WHEN @j%3=0 THEN @vendedor ELSE NULL END;
  IF @i<=8
   SET @venta=DATEADD(DAY,-CASE WHEN @j%3=0 THEN 40 WHEN @j%3=1 THEN 15 ELSE 5 END,CONVERT(DATETIME2(0),SWITCHOFFSET(@salida,''+00:00'')));
  ELSE SET @venta=DATEADD(MINUTE,@j,''2026-10-31T08:00:00'');
  SET @desc=NULL;
  IF @cab=''ECO'' AND DATEDIFF(DAY,CAST(@venta AS DATE),@fecha)>=30 SET @desc=''ANTICIPA15'';
  ELSE IF @j%4=0 AND EXISTS(SELECT 1 FROM ven.cliente WHERE id_persona=@comprador AND fecha_registro_utc<=@venta) SET @desc=''CLIENTE10'';
  ELSE IF CAST(@venta AS DATE) BETWEEN ''20260920'' AND ''20261010'' AND @j%5=0 SET @desc=''OTONO12'';
  SET @ord=CASE WHEN @cab=''VIP'' THEN @j ELSE @j-8 END;
  SET @asiento=NULL;
  SELECT @asiento=codigo_asiento FROM (
   SELECT codigo_asiento,ROW_NUMBER() OVER(ORDER BY fila,letra) AS rn
   FROM ops.asiento_configuracion WHERE id_configuracion=@cfg AND codigo_cabina=@cab
  ) s WHERE rn=@ord;
  IF @asiento IS NULL THROW 51985,N''La muestra supera la capacidad de asientos.'',1;
  SET @idCompra=NULL;SET @idTiquete=NULL;SET @precio=NULL;
  EXEC ven.usp_emitir_tiquete @id_vuelo=@vuelo,@codigo_cabina=@cab,
   @id_persona_pasajero=@pasajero,@id_persona_comprador=@comprador,
   @id_localizacion_venta=@loc,@id_empleado_vendedor=@vend,
   @codigo_descuento=@desc,@codigo_asiento=@asiento,@fecha_venta_utc=@venta,
   @id_compra=@idCompra OUTPUT,@id_tiquete=@idTiquete OUTPUT,@precio_final_usd=@precio OUTPUT;
  SET @momentoPago=DATEADD(MINUTE,10,@venta);
  SET @metodo=CASE WHEN @loc=@oficina THEN ''EFECTIVO'' ELSE ''TC'' END;
  SET @ultimos4=CASE WHEN @metodo=''TC'' THEN ''1234'' ELSE NULL END;
  SET @marca=CASE WHEN @metodo=''TC'' THEN ''VISA'' ELSE NULL END;
  SET @mitad=ROUND(@precio/2,2);SET @resto=@precio-@mitad;
  SET @ref=CONCAT(''DEMO-'',@i,''-'',@j);
  IF @i<=8 OR @j%7<>0
  BEGIN
   IF @i>=9 AND @j%9=0
    EXEC ven.usp_registrar_pago @id_tiquete=@idTiquete,@codigo_metodo=@metodo,
     @monto_usd=@mitad,@id_localizacion_cobro=@loc,@ultimos4_tarjeta=@ultimos4,@marca_tarjeta=@marca,@resultado=''PENDIENTE'',
     @referencia_autorizacion=@ref,@fecha_pago_utc=@momentoPago;
   ELSE IF @j%3=0 OR (@i>=9 AND @j%5=0)
   BEGIN
    EXEC ven.usp_registrar_pago @id_tiquete=@idTiquete,@codigo_metodo=@metodo,
     @monto_usd=@mitad,@id_localizacion_cobro=@loc,@ultimos4_tarjeta=@ultimos4,@marca_tarjeta=@marca,@fecha_pago_utc=@momentoPago;
    IF @i<=8 OR @j%5<>0
    BEGIN
     SET @momentoPago=DATEADD(MINUTE,20,@venta);
     EXEC ven.usp_registrar_pago @id_tiquete=@idTiquete,@codigo_metodo=@metodo,
      @monto_usd=@resto,@id_localizacion_cobro=@loc,@ultimos4_tarjeta=@ultimos4,@marca_tarjeta=@marca,@fecha_pago_utc=@momentoPago;
    END;
   END
   ELSE
    EXEC ven.usp_registrar_pago @id_tiquete=@idTiquete,@codigo_metodo=@metodo,
     @monto_usd=@precio,@id_localizacion_cobro=@loc,@ultimos4_tarjeta=@ultimos4,@marca_tarjeta=@marca,@fecha_pago_utc=@momentoPago;
  END;
  IF @j%17=0 AND @cancelar=0
  BEGIN
   SET @momentoCancel=DATEADD(HOUR,2,@venta);
   EXEC ven.usp_cancelar_tiquete @id_tiquete=@idTiquete,@codigo_motivo=''VOLUNTARIA'',@fecha_cancelacion_utc=@momentoCancel;
  END;
  SET @j+=1;
 END;

 IF @cancelar=1
 BEGIN
  SET @realSalida=DATEADD(HOUR,-2,@salida);
  EXEC ops.usp_cambiar_estado_vuelo @id_vuelo=@vuelo,@nuevo_estado=''CANCELADO'',
   @momento=@realSalida,@motivo_cancelacion=N''Cancelación sintética de demostración'';
 END
 ELSE IF @i<=8
 BEGIN
  SET @realSalida=DATEADD(MINUTE,@demora,@salida);
  SET @realLlegada=DATEADD(MINUTE,@dur,@realSalida) AT TIME ZONE @zd;
  IF @demora>=15
   EXEC ops.usp_cambiar_estado_vuelo @id_vuelo=@vuelo,@nuevo_estado=''DEMORADO'',@salida_estimada=@realSalida;
  EXEC ops.usp_cambiar_estado_vuelo @id_vuelo=@vuelo,@nuevo_estado=''EN_VUELO'',@momento=@realSalida;
  DECLARE cur_abordaje CURSOR LOCAL FAST_FORWARD FOR
   SELECT id_tiquete FROM ven.tiquete WHERE id_vuelo=@vuelo AND codigo_estado=''EMITIDO'' ORDER BY id_tiquete;
  OPEN cur_abordaje;
  FETCH NEXT FROM cur_abordaje INTO @idTiquete;
  WHILE @@FETCH_STATUS=0
  BEGIN
   SET @abordado=CASE WHEN @idTiquete%13=0 THEN 0 ELSE 1 END;
   EXEC ven.usp_registrar_abordaje @id_tiquete=@idTiquete,@presentado=@abordado;
   FETCH NEXT FROM cur_abordaje INTO @idTiquete;
  END;
  CLOSE cur_abordaje;DEALLOCATE cur_abordaje;
  EXEC ops.usp_cambiar_estado_vuelo @id_vuelo=@vuelo,@nuevo_estado=''ATERRIZADO'',@momento=@realLlegada;
 END;
 SET @i+=1;
END;
INSERT adm.registro_despliegue(script,descripcion)
VALUES(''FINAL_SQL_AUTOCONTENIDO'',N''Muestra SQL de 12 vuelos, 80 personas y 388 tiquetes'');';

-- G. Q01 - Ocupación por vuelo operado
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q01 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

WITH por_vuelo AS (
    SELECT v.id_vuelo, v.codigo_vuelo, v.ruta, v.fecha_salida_local, v.matricula, v.modelo,
           SUM(o.capacidad)        AS asientos_ofrecidos,
           SUM(o.plazas_ocupadas)  AS plazas_vendidas,
           SUM(o.usados)           AS pasajeros_volados,
           SUM(o.no_presentados)   AS no_presentados
    FROM rpt.v_vuelo AS v
    JOIN rpt.v_ocupacion_vuelo_cabina AS o ON o.id_vuelo = v.id_vuelo
    WHERE v.codigo_estado = ''ATERRIZADO''
      AND v.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY v.id_vuelo, v.codigo_vuelo, v.ruta, v.fecha_salida_local, v.matricula, v.modelo
)
SELECT id_vuelo, codigo_vuelo, ruta, fecha_salida_local, matricula, modelo,
       asientos_ofrecidos, plazas_vendidas, pasajeros_volados, no_presentados,
       CAST(pasajeros_volados * 1.0 / asientos_ofrecidos AS DECIMAL(7,4)) AS factor_ocupacion,
       RANK() OVER (PARTITION BY ruta ORDER BY pasajeros_volados * 1.0 / asientos_ofrecidos DESC) AS rango_en_ruta
FROM por_vuelo
ORDER BY ruta, fecha_salida_local, codigo_vuelo;
END;';

-- G. Q02 - Ocupación por ruta y cabina (con total por cabina)
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q02 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   
DECLARE @min_vuelos INT = 1;               

SELECT CASE WHEN GROUPING(o.ruta) = 1 THEN ''TOTAL'' ELSE o.ruta END       AS ruta,
       o.codigo_cabina,
       COUNT(*)                                                           AS vuelos,
       SUM(o.capacidad)                                                   AS asientos_ofrecidos,
       SUM(o.usados)                                                      AS pasajeros_volados,
       CAST(SUM(o.usados) * 1.0 / SUM(o.capacidad) AS DECIMAL(7,4))       AS factor_ponderado,
       CAST(AVG(o.usados * 1.0 / o.capacidad) AS DECIMAL(7,4))            AS promedio_simple_factores,
       CAST(MIN(o.usados * 1.0 / o.capacidad) AS DECIMAL(7,4))            AS factor_minimo,
       CAST(MAX(o.usados * 1.0 / o.capacidad) AS DECIMAL(7,4))            AS factor_maximo,
       SUM(CASE WHEN o.plazas_ocupadas = o.capacidad THEN 1 ELSE 0 END)   AS vuelos_agotados_al_cierre
FROM rpt.v_ocupacion_vuelo_cabina AS o
WHERE o.estado_vuelo = ''ATERRIZADO''
  AND o.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
GROUP BY GROUPING SETS ((o.ruta, o.codigo_cabina), (o.codigo_cabina))
HAVING COUNT(*) >= @min_vuelos
ORDER BY o.codigo_cabina, GROUPING(o.ruta), factor_ponderado DESC;
END;';

-- G. Q03 - Ventas, cobros y reembolsos por mes
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q03 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-07-01'';   
DECLARE @fecha_hasta DATE = ''2026-12-31'';   

WITH ventas AS (
    SELECT DATEFROMPARTS(YEAR(creado_utc), MONTH(creado_utc), 1) AS mes,
           COUNT(*)                                                         AS tiquetes_vendidos,
           SUM(precio_final_usd)                                            AS ventas_brutas_usd,
           SUM(CASE WHEN codigo_estado <> ''CANCELADO'' THEN precio_final_usd ELSE 0 END) AS ventas_vigentes_usd
    FROM ven.tiquete
    WHERE CAST(creado_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY DATEFROMPARTS(YEAR(creado_utc), MONTH(creado_utc), 1)
), cobros AS (
    SELECT DATEFROMPARTS(YEAR(fecha_resolucion_utc), MONTH(fecha_resolucion_utc), 1) AS mes,
           COUNT(*) AS pagos_confirmados, SUM(monto_usd) AS cobros_usd
    FROM ven.pago
    WHERE codigo_estado = ''CONFIRMADO'' AND CAST(fecha_resolucion_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY DATEFROMPARTS(YEAR(fecha_resolucion_utc), MONTH(fecha_resolucion_utc), 1)
), reembolsos AS (
    SELECT DATEFROMPARTS(YEAR(fecha_reembolso_utc), MONTH(fecha_reembolso_utc), 1) AS mes,
           SUM(monto_usd) AS reembolsos_usd
    FROM ven.reembolso
    WHERE CAST(fecha_reembolso_utc AS DATE) BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY DATEFROMPARTS(YEAR(fecha_reembolso_utc), MONTH(fecha_reembolso_utc), 1)
), meses AS (
    SELECT mes FROM ventas UNION SELECT mes FROM cobros UNION SELECT mes FROM reembolsos
)
SELECT m.mes,
       ISNULL(v.tiquetes_vendidos, 0)                          AS tiquetes_vendidos,
       ISNULL(v.ventas_brutas_usd, 0)                          AS ventas_brutas_usd,
       ISNULL(v.ventas_vigentes_usd, 0)                        AS ventas_vigentes_usd,
       ISNULL(c.pagos_confirmados, 0)                          AS pagos_confirmados,
       ISNULL(c.cobros_usd, 0)                                 AS cobros_usd,
       ISNULL(r.reembolsos_usd, 0)                             AS reembolsos_usd,
       ISNULL(c.cobros_usd, 0) - ISNULL(r.reembolsos_usd, 0)   AS cobro_neto_usd
FROM meses AS m
LEFT JOIN ventas     AS v ON v.mes = m.mes
LEFT JOIN cobros     AS c ON c.mes = m.mes
LEFT JOIN reembolsos AS r ON r.mes = m.mes
ORDER BY m.mes;
END;';

-- G. Q04 - Saldos pendientes de reservas a la fecha de corte
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q04 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_corte DATETIME2(0) = (SELECT CAST(valor AS DATETIME2(0)) FROM ref.parametro WHERE clave = ''FECHA_CORTE_DATOS'');

WITH reservas AS (
    SELECT f.id_tiquete, f.precio_final_usd, f.cobrado_usd, f.saldo_pendiente_usd, f.pendiente_confirmacion_usd,
           DATEDIFF(HOUR, @fecha_corte, t.fecha_limite_pago_utc) AS horas_al_vencimiento
    FROM rpt.v_tiquete_financiero AS f
    JOIN ven.tiquete AS t ON t.id_tiquete = f.id_tiquete
    WHERE f.codigo_estado = ''RESERVADO''
)
SELECT CASE WHEN cobrado_usd = 0 AND pendiente_confirmacion_usd = 0 THEN ''1. Sin pagos''
            WHEN cobrado_usd = 0 THEN ''2. Pago en espera de confirmación''
            ELSE ''3. Pago parcial'' END                                  AS situacion,
       CASE WHEN horas_al_vencimiento < 24 THEN ''a. vence en menos de 24 h''
            WHEN horas_al_vencimiento < 48 THEN ''b. vence en 24-48 h''
            ELSE ''c. vence en 48 h o más'' END                           AS plazo,
       COUNT(*)                                                         AS tiquetes,
       SUM(precio_final_usd)                                            AS valor_reservado_usd,
       SUM(cobrado_usd)                                                 AS abonado_usd,
       SUM(saldo_pendiente_usd)                                         AS saldo_pendiente_usd
FROM reservas
GROUP BY CASE WHEN cobrado_usd = 0 AND pendiente_confirmacion_usd = 0 THEN ''1. Sin pagos''
              WHEN cobrado_usd = 0 THEN ''2. Pago en espera de confirmación''
              ELSE ''3. Pago parcial'' END,
         CASE WHEN horas_al_vencimiento < 24 THEN ''a. vence en menos de 24 h''
              WHEN horas_al_vencimiento < 48 THEN ''b. vence en 24-48 h''
              ELSE ''c. vence en 48 h o más'' END
ORDER BY situacion, plazo;
END;';

-- G. Q05 - Cancelaciones con reembolso: motivo, regla y cabina
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q05 AS
BEGIN
SET NOCOUNT ON;
WITH cancelados AS (
    SELECT f.id_tiquete, f.codigo_cabina, t.codigo_motivo_cancelacion, f.cobrado_usd, f.reembolsado_usd,
           f.penalidad_retenida_usd, p.regla_aplicada, p.porcentaje_reembolso
    FROM rpt.v_tiquete_financiero AS f
    JOIN ven.tiquete AS t ON t.id_tiquete = f.id_tiquete
    CROSS APPLY ven.fn_politica_reembolso(t.id_tiquete, t.codigo_motivo_cancelacion, t.fecha_cancelacion_utc) AS p
    WHERE f.codigo_estado = ''CANCELADO''
)
SELECT codigo_motivo_cancelacion                                       AS motivo,
       regla_aplicada                                                  AS regla,
       codigo_cabina,
       COUNT(*)                                                        AS tiquetes,
       SUM(CASE WHEN cobrado_usd = 0 THEN 1 ELSE 0 END)                AS sin_cobro,
       CAST(AVG(porcentaje_reembolso) AS DECIMAL(5,1))                 AS porcentaje_politica_medio,
       SUM(cobrado_usd)                                                AS cobrado_usd,
       SUM(reembolsado_usd)                                            AS reembolsado_usd,
       SUM(penalidad_retenida_usd)                                     AS penalidad_retenida_usd,
       CAST(SUM(reembolsado_usd) / NULLIF(SUM(cobrado_usd), 0) AS DECIMAL(7,4)) AS tasa_reembolso
FROM cancelados
GROUP BY codigo_motivo_cancelacion, regla_aplicada, codigo_cabina
ORDER BY motivo, regla, codigo_cabina;
END;';

-- G. Q06 - Precio medio y descuento efectivo por ruta y cabina
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q06 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-07-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

SELECT v.ruta,
       v.codigo_cabina,
       COUNT(*)                                                                          AS tiquetes,
       CAST(AVG(v.precio_base_usd) AS DECIMAL(10,2))                                     AS precio_base_medio_usd,
       CAST(AVG(v.precio_final_usd) AS DECIMAL(10,2))                                    AS precio_final_medio_usd,
       CAST(SUM(v.monto_descuento_usd) / NULLIF(SUM(v.precio_base_usd), 0) AS DECIMAL(7,4)) AS tasa_descuento_efectiva,
       CAST(SUM(CASE WHEN v.porcentaje_descuento > 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS penetracion_descuentos,
       MIN(v.precio_final_usd)                                                           AS precio_final_minimo_usd,
       MAX(v.precio_final_usd)                                                           AS precio_final_maximo_usd
FROM rpt.v_venta AS v
WHERE v.fecha_venta BETWEEN @fecha_desde AND @fecha_hasta
  AND NOT (v.codigo_estado = ''CANCELADO'' AND v.codigo_motivo_cancelacion = ''VENCIMIENTO'')
GROUP BY v.ruta, v.codigo_cabina
ORDER BY v.codigo_cabina, precio_final_medio_usd DESC;
END;';

-- G. Q07 - Ventas por canal y punto de venta
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q07 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-07-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

SELECT v.canal,
       v.tipo_localizacion,
       v.codigo_localizacion,
       COUNT(DISTINCT v.id_compra)                                                    AS compras,
       COUNT(*)                                                                       AS tiquetes,
       SUM(v.precio_final_usd)                                                        AS ventas_usd,
       CAST(SUM(v.precio_final_usd) * 1.0 / SUM(SUM(v.precio_final_usd)) OVER () AS DECIMAL(7,4)) AS participacion_total,
       CAST(SUM(v.precio_final_usd) * 1.0 / SUM(SUM(v.precio_final_usd)) OVER (PARTITION BY v.canal) AS DECIMAL(7,4)) AS participacion_en_canal
FROM rpt.v_venta AS v
WHERE v.fecha_venta BETWEEN @fecha_desde AND @fecha_hasta
  AND v.codigo_estado <> ''CANCELADO''
GROUP BY v.canal, v.tipo_localizacion, v.codigo_localizacion
ORDER BY v.canal, ventas_usd DESC;
END;';

-- G. Q08 - Compradores y pasajeros registrados frente a no registrados
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q08 AS
BEGIN
SET NOCOUNT ON;
SELECT CASE WHEN v.comprador_registrado = 1 THEN ''Registrado'' ELSE ''No registrado'' END     AS comprador,
       COUNT(DISTINCT v.id_compra)                                                           AS compras,
       COUNT(DISTINCT v.id_persona_comprador)                                                AS compradores_distintos,
       COUNT(*)                                                                              AS tiquetes,
       CAST(COUNT(*) * 1.0 / COUNT(DISTINCT v.id_compra) AS DECIMAL(6,2))                    AS tiquetes_por_compra,
       SUM(CASE WHEN v.pasajero_registrado = 1 THEN 1 ELSE 0 END)                            AS pasajeros_registrados,
       SUM(v.precio_final_usd)                                                               AS ventas_brutas_usd,
       CAST(AVG(v.precio_final_usd) AS DECIMAL(10,2))                                        AS precio_medio_usd,
       CAST(SUM(CASE WHEN v.codigo_estado = ''CANCELADO'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS tasa_cancelacion,
       CAST(SUM(CASE WHEN v.canal = ''WEB'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS proporcion_web
FROM rpt.v_venta AS v
GROUP BY CASE WHEN v.comprador_registrado = 1 THEN ''Registrado'' ELSE ''No registrado'' END
ORDER BY comprador DESC;
END;';

-- G. Q09 - Tasa de cancelación por ruta y motivo
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q09 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

SELECT v.ruta,
       COUNT(*)                                                                                   AS tiquetes_vendidos,
       SUM(CASE WHEN v.codigo_motivo_cancelacion = ''VOLUNTARIA'' THEN 1 ELSE 0 END)                AS cancel_voluntarias,
       SUM(CASE WHEN v.codigo_motivo_cancelacion = ''VUELO_CANCELADO'' THEN 1 ELSE 0 END)           AS cancel_por_vuelo,
       SUM(CASE WHEN v.codigo_motivo_cancelacion = ''VENCIMIENTO'' THEN 1 ELSE 0 END)               AS cancel_por_vencimiento,
       CAST(SUM(CASE WHEN v.codigo_motivo_cancelacion = ''VOLUNTARIA'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4))      AS tasa_voluntaria,
       CAST(SUM(CASE WHEN v.codigo_motivo_cancelacion = ''VUELO_CANCELADO'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS tasa_por_vuelo,
       CAST(SUM(CASE WHEN v.codigo_estado = ''CANCELADO'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4))                   AS tasa_total
FROM rpt.v_venta AS v
WHERE v.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
GROUP BY v.ruta
ORDER BY tasa_total DESC;
END;';

-- G. Q10 - Utilización de la flota
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q10 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

WITH uso AS (
    SELECT u.id_avion, COUNT(*) AS dias_activos, SUM(u.vuelos) AS vuelos,
           SUM(u.minutos_bloque_programados) AS minutos_programados, SUM(u.minutos_bloque_reales) AS minutos_reales
    FROM rpt.v_utilizacion_avion_dia AS u
    WHERE u.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY u.id_avion
)
SELECT a.matricula,
       m.modelo,
       a.estado_operativo,
       ISNULL(u.dias_activos, 0)                                                     AS dias_activos,
       ISNULL(u.vuelos, 0)                                                           AS vuelos,
       CAST(ISNULL(u.minutos_programados, 0) / 60.0 AS DECIMAL(9,1))                 AS horas_bloque_programadas,
       CAST(ISNULL(u.minutos_reales, 0) / 60.0 AS DECIMAL(9,1))                      AS horas_bloque_reales,
       CAST(ISNULL(u.minutos_programados, 0) / 60.0 / (DATEDIFF(DAY, @fecha_desde, @fecha_hasta) + 1) AS DECIMAL(5,2)) AS horas_promedio_por_dia,
       RANK() OVER (ORDER BY ISNULL(u.minutos_programados, 0) DESC)                  AS rango_utilizacion
FROM ops.avion AS a
JOIN ops.configuracion_asientos AS c ON c.id_configuracion = a.id_configuracion
JOIN ref.modelo_avion AS m ON m.id_modelo = c.id_modelo
LEFT JOIN uso AS u ON u.id_avion = a.id_avion
ORDER BY rango_utilizacion, a.matricula;
END;';

-- G. Q11 - Distribución de la demanda por día de la semana y franja horaria
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q11 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

WITH base AS (
    SELECT v.dia_semana_iso,
           CASE WHEN v.hora_salida_local < 9 THEN ''1. Madrugada-mañana (<09h)''
                WHEN v.hora_salida_local < 13 THEN ''2. Media mañana (09-13h)''
                WHEN v.hora_salida_local < 18 THEN ''3. Tarde (13-18h)''
                ELSE ''4. Noche (>=18h)'' END AS franja,
           o.capacidad, o.usados
    FROM rpt.v_vuelo AS v
    JOIN rpt.v_ocupacion_vuelo_cabina AS o ON o.id_vuelo = v.id_vuelo
    WHERE v.codigo_estado = ''ATERRIZADO'' AND v.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
)
SELECT dia_semana_iso,
       CHOOSE(dia_semana_iso, ''lunes'', ''martes'', ''miércoles'', ''jueves'', ''viernes'', ''sábado'', ''domingo'') AS dia,
       franja,
       SUM(usados)                                                   AS pasajeros_volados,
       SUM(capacidad)                                                AS asientos_ofrecidos,
       CAST(SUM(usados) * 1.0 / SUM(capacidad) AS DECIMAL(7,4))      AS factor_ocupacion
FROM base
GROUP BY dia_semana_iso, franja
ORDER BY dia_semana_iso, franja;
END;';

-- G. Q12 - Anticipación de la compra y precio pagado
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q12 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

WITH base AS (
    SELECT CASE WHEN dias_anticipacion < 7 THEN ''1. 0-6 días''
                WHEN dias_anticipacion < 14 THEN ''2. 7-13 días''
                WHEN dias_anticipacion < 30 THEN ''3. 14-29 días''
                WHEN dias_anticipacion < 60 THEN ''4. 30-59 días''
                ELSE ''5. 60 días o más'' END AS tramo,
           codigo_cabina, precio_final_usd, porcentaje_descuento
    FROM rpt.v_venta
    WHERE fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
)
SELECT tramo,
       COUNT(*)                                                                         AS tiquetes,
       CAST(COUNT(*) * 1.0 / SUM(COUNT(*)) OVER () AS DECIMAL(7,4))                     AS participacion,
       CAST(AVG(CASE WHEN codigo_cabina = ''ECO'' THEN precio_final_usd END) AS DECIMAL(10,2)) AS precio_medio_eco_usd,
       CAST(AVG(CASE WHEN codigo_cabina = ''VIP'' THEN precio_final_usd END) AS DECIMAL(10,2)) AS precio_medio_vip_usd,
       CAST(SUM(CASE WHEN porcentaje_descuento > 0 THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS penetracion_descuentos
FROM base
GROUP BY tramo
ORDER BY tramo;
END;';

-- G. Q13 - Clientes registrados de mayor valor
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q13 AS
BEGIN
SET NOCOUNT ON;
DECLARE @top INT = 10;   

WITH por_cliente AS (
    SELECT c.id_persona_comprador AS id_persona,
           COUNT(DISTINCT c.id_compra) AS compras,
           COUNT(*)                    AS tiquetes,
           SUM(f.cobro_neto_usd)       AS cobro_neto_usd
    FROM ven.compra AS c
    JOIN ven.cliente AS cl ON cl.id_persona = c.id_persona_comprador AND cl.fecha_registro_utc <= c.fecha_compra_utc
    JOIN rpt.v_tiquete_financiero AS f ON f.id_compra = c.id_compra
    GROUP BY c.id_persona_comprador
)
SELECT TOP (@top)
       DENSE_RANK() OVER (ORDER BY p.cobro_neto_usd DESC) AS rango,
       cl.numero_viajero,
       cl.nivel_lealtad,
       p.compras,
       p.tiquetes,
       p.cobro_neto_usd,
       CAST(p.cobro_neto_usd / p.tiquetes AS DECIMAL(10,2)) AS cobro_neto_por_tiquete_usd
FROM por_cliente AS p
JOIN ven.cliente AS cl ON cl.id_persona = p.id_persona
ORDER BY rango, cl.numero_viajero;
END;';

-- G. Q14 - Registros sin actividad (anti-joins)
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q14 AS
BEGIN
SET NOCOUNT ON;
SELECT ''Clientes registrados sin compras'' AS categoria, COUNT(*) AS cantidad
FROM ven.cliente AS cl
LEFT JOIN ven.compra AS c ON c.id_persona_comprador = cl.id_persona
WHERE c.id_compra IS NULL
UNION ALL
SELECT ''Rutas sin programación (en evaluación)'', COUNT(*)
FROM ops.ruta AS r
WHERE NOT EXISTS (SELECT 1 FROM ops.programacion AS p WHERE p.id_ruta = r.id_ruta)
UNION ALL
SELECT ''Aviones sin vuelos asignados'', COUNT(*)
FROM ops.avion AS a
LEFT JOIN ops.vuelo AS v ON v.id_avion = a.id_avion
WHERE v.id_vuelo IS NULL
UNION ALL
SELECT ''Descuentos nunca aplicados'', COUNT(*)
FROM ven.descuento AS d
WHERE NOT EXISTS (SELECT 1 FROM ven.tiquete AS t WHERE t.id_descuento = d.id_descuento)
UNION ALL
SELECT ''Empleados de cabina o vuelo sin asignaciones'', COUNT(*)
FROM rh.empleado AS e
JOIN rh.cargo AS c ON c.codigo_cargo = e.codigo_cargo AND c.categoria_tripulacion IS NOT NULL
WHERE NOT EXISTS (SELECT 1 FROM ops.asignacion_tripulacion AS a WHERE a.id_empleado = e.id_empleado)
ORDER BY 1;
END;';

-- G. Q15 - Puntualidad y cancelaciones operativas por ruta
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q15 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-09-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-31'';   

WITH base AS (
    SELECT v.ruta, v.codigo_estado, v.demora_llegada_min,
           PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY v.demora_llegada_min) OVER (PARTITION BY v.ruta) AS p90_demora
    FROM rpt.v_vuelo AS v
    WHERE v.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
      AND v.codigo_estado IN (''ATERRIZADO'', ''CANCELADO'')
)
SELECT ruta,
       SUM(CASE WHEN codigo_estado = ''ATERRIZADO'' THEN 1 ELSE 0 END)                         AS vuelos_operados,
       SUM(CASE WHEN codigo_estado = ''CANCELADO'' THEN 1 ELSE 0 END)                          AS vuelos_cancelados,
       CAST(SUM(CASE WHEN codigo_estado = ''ATERRIZADO'' AND demora_llegada_min < 15 THEN 1 ELSE 0 END) * 1.0
            / NULLIF(SUM(CASE WHEN codigo_estado = ''ATERRIZADO'' THEN 1 ELSE 0 END), 0) AS DECIMAL(7,4)) AS puntualidad,
       CAST(AVG(CASE WHEN codigo_estado = ''ATERRIZADO'' THEN demora_llegada_min * 1.0 END) AS DECIMAL(7,1)) AS demora_media_llegada_min,
       CAST(MAX(p90_demora) AS DECIMAL(7,1))                                                AS p90_demora_llegada_min,
       CAST(SUM(CASE WHEN codigo_estado = ''CANCELADO'' THEN 1 ELSE 0 END) * 1.0 / COUNT(*) AS DECIMAL(7,4)) AS tasa_cancelacion
FROM base
GROUP BY ruta
ORDER BY puntualidad;
END;';

-- G. Q16 - Disponibilidad de los próximos vuelos
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q16 AS
BEGIN
SET NOCOUNT ON;
DECLARE @dias INT = 3;                  
DECLARE @origen CHAR(3) = NULL;         
DECLARE @fecha_corte DATETIME2(0) = (SELECT CAST(valor AS DATETIME2(0)) FROM ref.parametro WHERE clave = ''FECHA_CORTE_DATOS'');

SELECT v.codigo_vuelo, v.ruta, v.salida_programada, o.codigo_cabina, o.estado_vuelo,
       o.capacidad, o.plazas_ocupadas, o.plazas_disponibles, o.factor_ocupacion_vendido,
       tf.precio_base_usd AS tarifa_vigente_usd
FROM rpt.v_ocupacion_vuelo_cabina AS o
JOIN rpt.v_vuelo AS v ON v.id_vuelo = o.id_vuelo
OUTER APPLY (SELECT TOP (1) t.precio_base_usd FROM ven.tarifa AS t
             WHERE t.id_ruta = v.id_ruta AND t.codigo_cabina = o.codigo_cabina
               AND CAST(@fecha_corte AS DATE) BETWEEN t.vigente_desde AND ISNULL(t.vigente_hasta, ''99991231'')) AS tf
WHERE o.estado_vuelo IN (''PROGRAMADO'', ''DEMORADO'')
  AND v.salida_programada_utc >= @fecha_corte
  AND v.salida_programada_utc <  DATEADD(DAY, @dias, @fecha_corte)
  AND (@origen IS NULL OR v.origen = @origen)
ORDER BY v.salida_programada_utc, v.codigo_vuelo, o.codigo_cabina;
END;';

-- G. Q17 - Evolución mensual de las ventas (variación y acumulado)
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q17 AS
BEGIN
SET NOCOUNT ON;
WITH mensual AS (
    SELECT DATEFROMPARTS(YEAR(fecha_venta), MONTH(fecha_venta), 1) AS mes, codigo_cabina,
           COUNT(*) AS tiquetes, SUM(precio_final_usd) AS ventas_usd
    FROM rpt.v_venta
    WHERE codigo_estado <> ''CANCELADO''
    GROUP BY DATEFROMPARTS(YEAR(fecha_venta), MONTH(fecha_venta), 1), codigo_cabina
)
SELECT mes, codigo_cabina, tiquetes, ventas_usd,
       LAG(ventas_usd) OVER (PARTITION BY codigo_cabina ORDER BY mes)                         AS ventas_mes_anterior_usd,
       CAST((ventas_usd - LAG(ventas_usd) OVER (PARTITION BY codigo_cabina ORDER BY mes))
            / NULLIF(LAG(ventas_usd) OVER (PARTITION BY codigo_cabina ORDER BY mes), 0) AS DECIMAL(9,4)) AS variacion,
       SUM(ventas_usd) OVER (PARTITION BY codigo_cabina ORDER BY mes ROWS UNBOUNDED PRECEDING)   AS ventas_acumuladas_usd
FROM mensual
ORDER BY codigo_cabina, mes;
END;';

-- G. Q18 - Carga de vuelo de la tripulación en 672 horas consecutivas
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q18 AS
BEGIN
SET NOCOUNT ON;
DECLARE @fecha_desde DATE = ''2026-10-01'';   
DECLARE @fecha_hasta DATE = ''2026-10-28'';   

WITH por_tripulante AS (
    SELECT t.rol_vuelo, t.id_empleado, COUNT(*) AS vuelos, SUM(t.duracion_programada_min) / 60.0 AS horas
    FROM rpt.v_tripulacion_vuelo AS t
    WHERE t.estado_vuelo <> ''CANCELADO'' AND t.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
    GROUP BY t.rol_vuelo, t.id_empleado
)
SELECT rol_vuelo,
       COUNT(*)                                                         AS tripulantes,
       SUM(vuelos)                                                      AS asignaciones,
       CAST(MIN(horas) AS DECIMAL(7,1))                                 AS horas_minimas,
       CAST(AVG(horas) AS DECIMAL(7,1))                                 AS horas_promedio,
       CAST(MAX(horas) AS DECIMAL(7,1))                                 AS horas_maximas,
       SUM(CASE WHEN rol_vuelo IN (''CAPITAN'', ''PRIMER_OFICIAL'') AND horas > 100 THEN 1 ELSE 0 END) AS pilotos_sobre_100h,
       (SELECT COUNT(*) FROM ops.vuelo AS v
        WHERE v.codigo_estado IN (''EN_VUELO'', ''ATERRIZADO'') AND v.fecha_salida_local BETWEEN @fecha_desde AND @fecha_hasta
          AND (SELECT COUNT(*) FROM ops.asignacion_tripulacion AS a
               WHERE a.id_vuelo = v.id_vuelo AND a.rol_vuelo IN (''CAPITAN'', ''PRIMER_OFICIAL'')) < 2) AS vuelos_operados_sin_pilotos
FROM por_tripulante
GROUP BY rol_vuelo
ORDER BY rol_vuelo;
END;';

-- G. Q19 - Controles de integridad y conciliación
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q19 AS
BEGIN
SET NOCOUNT ON;
SELECT ''Inventario distinto de tiquetes que ocupan plaza'' AS control,
       COUNT(*) AS filas_con_diferencia, CAST(NULL AS DECIMAL(14,2)) AS diferencia_usd
FROM rpt.v_conciliacion_inventario WHERE diferencia <> 0
UNION ALL
SELECT ''Plazas ocupadas por encima de la capacidad'', COUNT(*), NULL
FROM ops.vuelo_cabina WHERE plazas_ocupadas > capacidad
UNION ALL
SELECT ''Asientos duplicados en tiquetes activos'', COUNT(*), NULL
FROM (SELECT t.id_vuelo, t.codigo_asiento FROM ven.tiquete AS t
      JOIN ref.estado_tiquete AS e ON e.codigo_estado = t.codigo_estado AND e.ocupa_inventario = 1
      WHERE t.codigo_asiento IS NOT NULL
      GROUP BY t.id_vuelo, t.codigo_asiento HAVING COUNT(*) > 1) AS d
UNION ALL
SELECT ''Cobros confirmados mayores que el precio final'', COUNT(*), NULL
FROM rpt.v_tiquete_financiero WHERE cobrado_usd > precio_final_usd
UNION ALL
SELECT ''Reembolsos mayores que lo cobrado'', COUNT(*), NULL
FROM rpt.v_tiquete_financiero WHERE reembolsado_usd > cobrado_usd
UNION ALL
SELECT ''Tiquetes emitidos, usados o no presentados sin pago total'', COUNT(*), NULL
FROM rpt.v_tiquete_financiero WHERE codigo_estado IN (''EMITIDO'', ''USADO'', ''NO_PRESENTADO'') AND cobrado_usd <> precio_final_usd
UNION ALL
SELECT ''Tiquetes con precio base distinto de su tarifa'', COUNT(*), NULL
FROM ven.tiquete AS t JOIN ven.tarifa AS tf ON tf.id_tarifa = t.id_tarifa WHERE t.precio_base_usd <> tf.precio_base_usd
UNION ALL
SELECT ''Vuelos operados con reservas sin pagar'', COUNT(DISTINCT t.id_vuelo), NULL
FROM ven.tiquete AS t JOIN ops.vuelo AS v ON v.id_vuelo = t.id_vuelo
WHERE v.codigo_estado IN (''EN_VUELO'', ''ATERRIZADO'') AND t.codigo_estado = ''RESERVADO''
UNION ALL
SELECT ''Identidad de conciliación de caja (USD)'', CASE WHEN x.diferencia = 0 THEN 0 ELSE 1 END, x.diferencia
FROM (SELECT (SELECT SUM(monto_usd) FROM ven.pago WHERE codigo_estado = ''CONFIRMADO'')
           - (SELECT ISNULL(SUM(monto_usd), 0) FROM ven.reembolso)
           - (SELECT SUM(CASE WHEN codigo_estado IN (''EMITIDO'', ''USADO'', ''NO_PRESENTADO'') THEN precio_final_usd
                              WHEN codigo_estado = ''RESERVADO'' THEN cobrado_usd
                              ELSE penalidad_retenida_usd END)
              FROM rpt.v_tiquete_financiero) AS diferencia) AS x
ORDER BY control;
END;';

-- G. Q20 - Uso y costo de los descuentos
EXEC sys.sp_executesql N'CREATE OR ALTER PROCEDURE rpt.usp_q20 AS
BEGIN
SET NOCOUNT ON;
SELECT d.codigo_descuento,
       d.porcentaje,
       d.codigo_cabina,
       d.solo_clientes_registrados,
       COUNT(v.id_tiquete)                                                             AS tiquetes,
       ISNULL(SUM(v.monto_descuento_usd), 0)                                           AS costo_descuento_usd,
       CAST(SUM(v.monto_descuento_usd) / NULLIF(SUM(v.precio_base_usd), 0) AS DECIMAL(7,4)) AS costo_relativo,
       CAST(SUM(v.comprador_registrado) * 1.0 / NULLIF(COUNT(v.id_tiquete), 0) AS DECIMAL(7,4)) AS participacion_registrados
FROM ven.descuento AS d
LEFT JOIN rpt.v_venta AS v ON v.codigo_descuento = d.codigo_descuento AND v.codigo_estado <> ''CANCELADO''
GROUP BY d.codigo_descuento, d.porcentaje, d.codigo_cabina, d.solo_clientes_registrados
ORDER BY tiquetes DESC, d.codigo_descuento;
END;';

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
 IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
 THROW;
END CATCH;
-- H. CONSULTAS DE NEGOCIO: SOLO LECTURA, REEJECUTABLES

-- Q01 - Ocupación por vuelo operado
EXEC rpt.usp_q01;

-- Q02 - Ocupación por ruta y cabina (con total por cabina)
EXEC rpt.usp_q02;

-- Q03 - Ventas, cobros y reembolsos por mes
EXEC rpt.usp_q03;

-- Q04 - Saldos pendientes de reservas a la fecha de corte
EXEC rpt.usp_q04;

-- Q05 - Cancelaciones con reembolso: motivo, regla y cabina
EXEC rpt.usp_q05;

-- Q06 - Precio medio y descuento efectivo por ruta y cabina
EXEC rpt.usp_q06;

-- Q07 - Ventas por canal y punto de venta
EXEC rpt.usp_q07;

-- Q08 - Compradores y pasajeros registrados frente a no registrados
EXEC rpt.usp_q08;

-- Q09 - Tasa de cancelación por ruta y motivo
EXEC rpt.usp_q09;

-- Q10 - Utilización de la flota
EXEC rpt.usp_q10;

-- Q11 - Distribución de la demanda por día de la semana y franja horaria
EXEC rpt.usp_q11;

-- Q12 - Anticipación de la compra y precio pagado
EXEC rpt.usp_q12;

-- Q13 - Clientes registrados de mayor valor
EXEC rpt.usp_q13;

-- Q14 - Registros sin actividad (anti-joins)
EXEC rpt.usp_q14;

-- Q15 - Puntualidad y cancelaciones operativas por ruta
EXEC rpt.usp_q15;

-- Q16 - Disponibilidad de los próximos vuelos
EXEC rpt.usp_q16;

-- Q17 - Evolución mensual de las ventas (variación y acumulado)
EXEC rpt.usp_q17;

-- Q18 - Carga de vuelo de la tripulación en 672 horas consecutivas
EXEC rpt.usp_q18;

-- Q19 - Controles de integridad y conciliación
EXEC rpt.usp_q19;

-- Q20 - Uso y costo de los descuentos
EXEC rpt.usp_q20;

-- I. PROCEDIMIENTOS PARAMETRIZADOS DEL MODELO ORIGINAL
EXEC rpt.usp_ocupacion_por_ruta @fecha_desde='20260901',@fecha_hasta='20261031',@codigo_cabina='ECO';
EXEC rpt.usp_resumen_financiero @fecha_desde='20260701',@fecha_hasta='20261101';
-- J. DICCIONARIO FÍSICO Y CLAVES
SELECT s.name AS esquema,t.name AS tabla,c.column_id AS orden,c.name AS atributo,
 ty.name AS tipo,c.max_length AS bytes_maximos,c.[precision],c.[scale],c.is_nullable,
 c.is_identity,c.is_computed
FROM sys.tables t JOIN sys.schemas s ON s.schema_id=t.schema_id
JOIN sys.columns c ON c.object_id=t.object_id
JOIN sys.types ty ON ty.user_type_id=c.user_type_id
WHERE s.name IN ('ref','rh','ops','ven','aud','adm','tst')
ORDER BY s.name,t.name,c.column_id;
SELECT SCHEMA_NAME(t.schema_id) AS esquema,t.name AS tabla,k.name AS clave,k.type_desc
FROM sys.key_constraints k JOIN sys.tables t ON t.object_id=k.parent_object_id
WHERE SCHEMA_NAME(t.schema_id) IN ('ref','rh','ops','ven','aud','adm','tst')
ORDER BY esquema,tabla,clave;
-- K. RESUMEN DE LA MUESTRA
SELECT 'Vuelos' AS entidad,COUNT(*) AS filas FROM ops.vuelo
UNION ALL SELECT 'Personas',COUNT(*) FROM ven.persona
UNION ALL SELECT 'Clientes',COUNT(*) FROM ven.cliente
UNION ALL SELECT 'Compras',COUNT(*) FROM ven.compra
UNION ALL SELECT 'Tiquetes',COUNT(*) FROM ven.tiquete
UNION ALL SELECT 'Pagos',COUNT(*) FROM ven.pago
UNION ALL SELECT 'Reembolsos',COUNT(*) FROM ven.reembolso;
-- L. CONCLUSIONES
-- La separación Persona/Cliente y Compra/Tiquete permite compradores invitados
-- y compradores distintos del pasajero, preservando identidad y trazabilidad.
-- Ruta/Programacion/Programacion_dia/Vuelo evita mezclar patrón y ejecución.
-- Estados y transiciones distinguen reserva, emisión pagada, uso y cancelación.
-- Cobros, reembolsos y precio vendido son magnitudes diferentes.
-- Los reportes apoyan decisiones comerciales y operativas sobre datos ficticios.
-- No se atribuye causalidad a promociones ni se estima utilidad sin costos.
