-- REPORTES Q01-Q20. SOLO LECTURA. BASE: bd-aerolinea-final.
-- Cada llamada puede guardarse en una pestaña independiente.

-- Q01 Ocupación por vuelo operado
EXEC rpt.usp_q01;

-- Q02 Ocupación por ruta y cabina (con total por cabina)
EXEC rpt.usp_q02;

-- Q03 Ventas, cobros y reembolsos por mes
EXEC rpt.usp_q03;

-- Q04 Saldos pendientes de reservas a la fecha de corte
EXEC rpt.usp_q04;

-- Q05 Cancelaciones con reembolso: motivo, regla y cabina
EXEC rpt.usp_q05;

-- Q06 Precio medio y descuento efectivo por ruta y cabina
EXEC rpt.usp_q06;

-- Q07 Ventas por canal y punto de venta
EXEC rpt.usp_q07;

-- Q08 Compradores y pasajeros registrados frente a no registrados
EXEC rpt.usp_q08;

-- Q09 Tasa de cancelación por ruta y motivo
EXEC rpt.usp_q09;

-- Q10 Utilización de la flota
EXEC rpt.usp_q10;

-- Q11 Distribución de la demanda por día de la semana y franja horaria
EXEC rpt.usp_q11;

-- Q12 Anticipación de la compra y precio pagado
EXEC rpt.usp_q12;

-- Q13 Clientes registrados de mayor valor
EXEC rpt.usp_q13;

-- Q14 Registros sin actividad (anti-joins)
EXEC rpt.usp_q14;

-- Q15 Puntualidad y cancelaciones operativas por ruta
EXEC rpt.usp_q15;

-- Q16 Disponibilidad de los próximos vuelos
EXEC rpt.usp_q16;

-- Q17 Evolución mensual de las ventas (variación y acumulado)
EXEC rpt.usp_q17;

-- Q18 Carga de vuelo de la tripulación en 672 horas consecutivas
EXEC rpt.usp_q18;

-- Q19 Controles de integridad y conciliación
EXEC rpt.usp_q19;

-- Q20 Uso y costo de los descuentos
EXEC rpt.usp_q20;
