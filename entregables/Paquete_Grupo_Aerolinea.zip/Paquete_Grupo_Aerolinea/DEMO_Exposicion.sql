-- DEMOSTRACIÓN DE LECTURA - bd-aerolinea-final
-- La instalación debe estar completada. Ejecutar cada reporte por separado.
-- Integridad: resultado comprobado, nueve controles con cero incidencias.
EXEC rpt.usp_q19;

-- Ocupación volada por ruta y cabina; un factor 0.75 significa 75%.
EXEC rpt.usp_q02;

-- Reservas con saldo y plazo al vencimiento.
EXEC rpt.usp_q04;

-- Ventas por canal, excluyendo tiquetes cancelados.
EXEC rpt.usp_q07;

-- Procedimiento original con parámetros.
EXEC rpt.usp_ocupacion_por_ruta
    @fecha_desde='20260901',
    @fecha_hasta='20261031',
    @codigo_cabina='ECO';
